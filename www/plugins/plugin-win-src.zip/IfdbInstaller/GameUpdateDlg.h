// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// GameUpdateDlg.h : Declaration of the CGameUpdateDlg

#pragma once

#include "resource.h"       // main symbols
#include <atlhost.h>


// CGameUpdateDlg

class CGameUpdateDlg : 
        public CAxDialogImpl<CGameUpdateDlg>
{
public:
        CGameUpdateDlg()
        {
        }

        ~CGameUpdateDlg()
        {
        }

        enum { IDD = IDD_GAMEUPDATEDLG };

BEGIN_MSG_MAP(CGameUpdateDlg)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        COMMAND_HANDLER(IDNO, BN_CLICKED, OnBnClickedNo)
        COMMAND_HANDLER(IDYES, BN_CLICKED, OnBnClickedYes)
        CHAIN_MSG_MAP(CAxDialogImpl<CGameUpdateDlg>)
END_MSG_MAP()

// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

        LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
        {
                CAxDialogImpl<CGameUpdateDlg>::OnInitDialog(uMsg, wParam, lParam, bHandled);
                return 1;  // Let the system set the focus
        }

        LRESULT OnBnClickedYes(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
        {
                EndDialog(wID);
                return 0;
        }

        LRESULT OnBnClickedNo(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
        {
                EndDialog(wID);
                return 0;
        }
};
