// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// MainDlg.cpp : Implementation of CMainDlg

#include "stdafx.h"
#include "MainDlg.h"
#include ".\maindlg.h"



LRESULT CMainDlg::OnBnClickedRbInstallit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    info->installTerp = TRUE;
    UpdateUrls();
    return 0;
}

LRESULT CMainDlg::OnBnClickedRbAlreadygotit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    info->installTerp = FALSE;
    UpdateUrls();
    return 0;
}


LRESULT CMainDlg::OnCtlColorDlg(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
    // white background
    ::SetTextColor((HDC)wParam, RGB(0x00,0x00,0x00));
    return (LRESULT)bkg_brush_;
}

LRESULT CMainDlg::OnCtlColorStatic(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
{
    // black text, except for the warning, which is red; draw transparently
    HDC hdc = (HDC)wParam;
    HWND ctl = (HWND)lParam;
    if (ctl == GetDlgItem(IDC_ST_WARN))
        ::SetTextColor(hdc, RGB(0xD0, 0x00, 0x00));
    else
        ::SetTextColor(hdc, RGB(0x00,0x00,0x00));
    ::SetBkMode((HDC)wParam, TRANSPARENT);
    return (LRESULT)bkg_brush_;
}


LRESULT CMainDlg::OnBnClickedBtnUpdate(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    // check for updates
    if (updater->CheckUpdate())
    {
        // we need to update - close the main dialog with a 'cancel'
        // status, since we need to terminate the main program in
        // order to allow the updater to overwrite our program files
        EndDialog(IDCANCEL);
    }

    // handled
    return 0;
}
