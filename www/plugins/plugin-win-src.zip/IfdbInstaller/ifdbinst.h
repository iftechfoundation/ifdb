// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details


#ifndef _IFDBINST_H_
#define _IFDBINST_H_

#include <atlhost.h>
#include <atlcoll.h>

// Download information on a file.  This is the decoded form of the XML
// information the server sends us to tell us what to download.
struct dlfile
{
    dlfile()
    {
        // by default, wait for any "run" action to finish before we
        // continue with the main install
        runDetached = false;
    }

    // source URL
    CAtlString url;

    // compression information
    CAtlString compr;
    CAtlString comprName;
    CAtlString comprPri;

    // installation action ("save" or "run")
    CAtlString action;

    // error message to display if the "run" action fails
    CAtlString runErrMsg;

    // If "run", are we running detached?  (I.e., the meta installer won't
    // wait for the program to finish.  This applies to the installer
    // updater itself, which needs the meta installer to terminate before
    // it can carry out its work, since it might need to overwrite the
    // meta installer itself.)
    bool runDetached;

    // command-line parameters for "run" mode
    CAtlString runParams;

    // description for display in the UI
    CAtlString desc;
};

// download information for an interpreter
struct dlterp
{
    // the interpreter download
    dlfile dl;

    // additional identification information on the interpreter
    CAtlString name;
    CAtlString vsn;
    CAtlString regKey;

    // registry key setup for the interpreter
    CAtlString runGame;
    CAtlString runGameRestore;

    // the <filetypekey> list
    CAtlList<CAtlString> filetypes;

    // the root name of the executable, and the MD5 hash of the file;
    // we use this to verify the installation if we find the terp
    // based on the file-type association keys
    CAtlString exename;
    CAtlString exeMD5;
};

// Download information for the whole game.  This consists of a game
// file, possibly an interpreter, and possibly extra files.
struct dlinfo
{
    // selected IF Archive mirror
    CAtlString archiveMirror;

    // information on the game
    CAtlString tuid;
    CAtlString title;
    CAtlString author;
    CAtlString gameVsn;

    // the game's format information
    CAtlString fmtID;
    CAtlString fmtName;

    // Do we need to download the game? (we don't if it's already installed)
    int needGame;

    // Do we need an update to the game? (this is true if the game is already
    // installed, but a different version is on the server)
    int gameUpdate;

    // Do we actually want to install the game?  This will be set to
    // false if the user explicitly declines to install an update.
    int installGame;

    // the local file containing the game
    CAtlString localGameFile;

    // download information for the game file
    dlfile game;

    // Is an interpreter download (new install or update) needed?  This
    // is set to true if an interpreter is needed for the game AND the
    // user doesn't already have the latest version installed.  (So the
    // game might still need an interpreter even if this is false - this
    // just indicates whether or not we need to install one.)
    int needTerp;

    // Is a terp update available?  This is true if the user has the
    // correct interpreter installed, but there's a newer version available
    // for download.
    int terpUpdate;

    // is the installed terp version known?
    int terpVersionKnown;

    // The list of interpreters for the game's format.  The first in the
    // list is the "recommended" interpreter.
    CAtlList<dlterp> terps;

    // List position of the selected interpreter.  If the user already
    // has an interpreter installed, this is the first in the list that
    // we found, so it's the one that we'll update if an update is needed.
    // If no interpreter is installed, this is the one the user has selected
    // for installation.  By default, we'll select the first in the list
    // we get from the server, since the list is in recommendation order.
    POSITION selectedTerp;

    // Do we want to install or update the interpreter?  This is only
    // meaningful if needTerp is true, and indicates whether or not the
    // user has opted to do the install.  If this is false, it means
    // that the user has an existing interpreter already and wants to
    // keep it rather than installing a new one.
    int installTerp;

    // The local path to the interpreter executable, as specified by the
    // user.  This is applicable only when the user already has an
    // interpreter installed, but it's a version we can't detect; this
    // is used to store the user's entry for the interpreter location.
    CAtlString terpExe;
};

// are auto-updates enabled?
bool AutoUpdatesEnabled();


#endif /* _IFDBINST_H_ */
