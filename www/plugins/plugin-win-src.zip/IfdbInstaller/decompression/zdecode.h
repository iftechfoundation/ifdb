#include <string.h>
#include <stdlib.h>
#include <memory.h>
#include <stdio.h>
#include <fcntl.h>
#include <io.h>

typedef unsigned char zd_uchar;
typedef unsigned short zd_uint16;
typedef unsigned int zd_uint32;

/*
 *   .Z stream decoder
 */
class ZDecoder
{
public:
    ZDecoder();
    ~ZDecoder();

    /* 
     *   Open a stream and test to see if it looks like a .Z stream.  If the
     *   stream has the correct signature and header parameters, we'll set up
     *   to decode the stream and return true.  If it's not a .Z stream at
     *   all, or it has parameters that we can't handle (too large a maximum
     *   symbol size, wrong block mode), we'll rewind the stream to the
     *   starting position (if the stream is capable of this operation) and
     *   return false.  We rewind the stream in case of error so that the
     *   caller can try re-opening the stream with other decoder types - this
     *   makes it easier to use this class in multi-type decoders by letting
     *   the caller try each decoder until finding one that works.  
     */
    int open(class ZIStream *instr);

    /*
     *   Decode the input stream, writing the decoded data to the output
     *   stream.
     */
    int decode(class ZIStream *outstr);

protected:
    /* the open input stream */
    ZIStream *instr_;

    /* header value for maximum bit size */
    zd_uchar hdr_max_bits_;
};

/*
 *   Basic stream class for the .Z decoder.  This is a generic byte-oriented
 *   input/output stream.  The .Z decoder uses any given stream only for
 *   input OR input, never both.  
 */
class ZIStream
{
public:
    virtual size_t read_bytes(zd_uchar *buf, size_t len) = 0;
    virtual size_t write_bytes(zd_uchar *buf, size_t len) = 0;
    virtual int flush() = 0;
    virtual int close() = 0;
    virtual long getpos() = 0;
    virtual int setpos(long pos) = 0;
};

/*
 *   Simple in-memory implementation of ZIStream writer.  This captures the
 *   output to a single large memory buffer.  
 */
class OutMemZStream: public ZIStream
{
    const static size_t chunksize = 16384;
    struct buflink
    {
        buflink() : nxt(0) { }
        buflink *nxt;
        char buf[chunksize];
    };
    
public:
    OutMemZStream()
    {
        head_ = tail_ = 0;
        nbytes_ = 0;
        p_ = 0;
        buf_ = 0;
    }

    ~OutMemZStream()
    {
        buflink *b, *nxt;
        
        /* delete our buffers */
        for (b = head_ ; b != 0 ; b = nxt)
        {
            nxt = b->nxt;
            delete b;
        }

        head_ = tail_ = 0;
        p_ = 0;

        /* delete our main buffer */
        if (buf_ != 0)
            delete [] buf_;

        nbytes_ = 0;
    }

    /* get our result buffer (not valid until the stream has been closed) */
    char *getbuf() const { return buf_; }

    /* 
     *   Take ownership of our result buffer - this removes the buffer from
     *   the stream object, so that the stream won't delete the buffer when
     *   the stream is deleted.  The caller is responsible for deleting the
     *   buffer by using the standard C++ "delete []" operator.  
     */
    char *takebuf()
    {
        char *ret = buf_;
        buf_ = 0;
        return ret;
    }

    /* get the buffer size */
    size_t getbuflen() const { return nbytes_; }

    size_t write_bytes(zd_uchar *buf, size_t len)
    {
        size_t outcnt = 0;
        
        /* keep going until we've written the whole request */
        while (len != 0)
        {
            /* if the current chunk is full, add a new chunk */
            if ((p_ == 0 || p_ - tail_->buf >= chunksize) && !add_chunk())
                return outcnt;

            /* add as much as we can from this request to the current chunk */
            size_t copylen = len;
            size_t rem = (chunksize - (p_ - tail_->buf));
            if (copylen > rem)
                copylen = rem;

            /* copy this chunk */
            memcpy(p_, buf, copylen);

            /* advance the pointers and counters */
            len -= copylen;
            outcnt += copylen;
            nbytes_ += copylen;
            p_ += copylen;
            buf += copylen;
        }

        /* return the number of bytes we managed to write */
        return outcnt;
    }

    /* we don't have any underlying stream object, so flushing is trivial */
    int flush() { return 1; }

    /* on close, convert our chunk list into a single large buffer */
    int close()
    {
        buflink *b, *nxt;
        char *dst;
        
        /* allocate the buffer */
        buf_ = new char[nbytes_ == 0 ? 1 : nbytes_];
        if (buf_ == 0)
            return 0;

        /* copy the chunk buffers */
        for (b = head_, dst = buf_ ; b != 0 ; b = nxt)
        {
            /* 
             *   figure the length of this chunk: all buffers but the last
             *   one are completely full 
             */
            size_t blen = (b->nxt == 0 ? p_ - b->buf : chunksize);

            /* copy this chunk */
            memcpy(dst, b->buf, blen);

            /* advance our write pointer */
            dst += blen;

            /* get the next buffer */
            nxt = b->nxt;

            /* free this one */
            delete b;
        }

        /* we've now deleted our chunk list */
        head_ = tail_ = 0;
        p_ = 0;

        /* success */
        return 1;
    }

    /* we don't read */
    size_t read_bytes(zd_uchar *, size_t) { return 0; }

    /* we don't seek */
    long getpos() { return -1; }
    int setpos(long pos) { return 0; }

protected:
    int add_chunk()
    {
        /* allocate a new chunk */
        buflink *buf = new buflink;
        if (buf == 0)
            return 0;

        /* link it at the tail of the list */
        if (tail_ != 0)
            tail_->nxt = buf;
        else
            head_ = buf;
        tail_ = buf;

        /* move the write head to the start of the chunk buffer */
        p_ = buf->buf;

        /* success */
        return 1;
    }

    buflink *head_, *tail_;
    size_t nbytes_;
    char *p_;
    char *buf_;
};

/*
 *   Simple stdio implementation of ZIStream.
 */
class StdioZStream: public ZIStream
{
public:
    StdioZStream()
    {
        fp_ = 0;
    }

    ~StdioZStream()
    {
        close();
    }

    int open(FILE *fp)
    {
        close();

        if (_setmode(fileno(fp), O_BINARY) == -1)
            return 0;

        fp_ = fp;
        return 1;
    }

    int open_read(const char *fname)
    {
        close();
        return ((fp_ = fopen(fname, "rb")) != 0);
    }

    int open_write(const char *fname)
    {
        close();
        return ((fp_ = fopen(fname, "wb")) != 0);
    }

    size_t read_bytes(zd_uchar *buf, size_t len)
    {
        return fread((char *)buf, 1, len, fp_);
    }

    size_t write_bytes(zd_uchar *buf, size_t len)
    {
        return fwrite((char *)buf, 1, len, fp_);
    }

    int flush()
    {
        int ret = 1;
        if (fp_ != 0)
            ret = (fflush(fp_) != EOF);
        return ret;
    }

    int close()
    {
        int ret = 1;
        if (fp_ != 0)
        {
            ret = (fclose(fp_) != EOF);
            fp_ = 0;
        }
        return ret;
    }

    long getpos() { return ftell(fp_); }
    int setpos(long pos) { return fseek(fp_, pos, SEEK_SET) != EOF; }

protected:
    FILE *fp_;
};
