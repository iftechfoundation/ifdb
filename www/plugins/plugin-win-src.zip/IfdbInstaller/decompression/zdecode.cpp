#include "zdecode.h"

#define HDRSIZE             3
#define SIG_MAGIC1          0x1F
#define SIG_MAGIC2          0x9D
#define HDRMASK_BITS        0x1F
#define HDRMASK_BLOCKMODE   0x80
#define INIT_BITS           9
#define INIT_HEAD           257
#define SYM_CLEARTAB        256

class ZStreamInBuffer
{
public:
    ZStreamInBuffer()
    {
        str_ = 0;
        buf_ = 0;
        bufsiz_ = 0;
        p_ = 0;
        eof_ = 0;
        val_ = 0;
        bits_avail_ = 0;
        buflen_ = 0;
    }

    ~ZStreamInBuffer()
    {
        free_mem();
    }

    int open(ZIStream *str, size_t bufsiz)
    {
        close();
        str_ = str;
        bufsiz_ = bufsiz;
        buf_ = p_ = new zd_uchar[bufsiz];
        return (buf_ != 0);
    }

    int close()
    {
        int ret = 1;
        if (str_ != 0)
            ret = str_->close();

        free_mem();
        return ret;
    }

    int read_byte(zd_uchar *b)
    {
        if (p_ >= buf_ + buflen_)
        {
            if (str_ == 0)
                return 0;

            p_ = buf_;
            buflen_ = str_->read_bytes(buf_, bufsiz_);
            if (buflen_ == 0)
                return 0;
        }
        *b = *p_++;
        return 1;
    }

    zd_uint32 read_bits(int bits)
    {
        /* read more bytes as needed until we have enough bits available */
        while (bits > bits_avail_)
        {
            /* read another 8 bits */
            zd_uchar b = 0;
            if (!read_byte(&b))
            {
                /* there are no more bits to read - pad with 1's */
                b = 0xFF;
                eof_ = 1;
            }

            /* add the new bytes to the high end of the bit buffer */
            val_ |= ((zd_uint32)b) << bits_avail_;
            bits_avail_ += 8;
        }

        /* pull out the low-order 'bits' bits */
        zd_uint32 ret = val_ & ((1 << bits) - 1);
        val_ >>= bits;
        bits_avail_ -= bits;

        return ret;
    }

    int eof() const { return eof_; }

protected:
    void free_mem()
    {
        if (buf_ != 0)
        {
            delete [] buf_;
            buf_ = 0;
        }
    }

    ZIStream *str_;
    zd_uchar *buf_;
    zd_uchar *p_;
    size_t bufsiz_;
    size_t buflen_;
    int bits_avail_;
    int eof_;
    zd_uint32 val_;
};

class ZStreamOutBuffer
{
public:
    ZStreamOutBuffer()
    {
        str_ = 0;
        p_ = buf_ = 0;
        bufsiz_ = 0;
    }

    int open(ZIStream *str, size_t bufsiz)
    {
        close();
        str_ = str;
        bufsiz_ = bufsiz;
        buf_ = p_ = new zd_uchar[bufsiz];
        return (buf_ != 0);
    }

    ~ZStreamOutBuffer()
    {
        flush();
    }

    int close()
    {
        int ret = 1;
        if (str_ != 0)
        {
            ret = flush() && str_->close();
            str_ = 0;
        }
        free_mem();
        return ret;
    }

    int write_byte(zd_uchar b)
    {
        if (p_ >= buf_ + bufsiz_ && !send_buf())
            return 0;

        *p_++ = b;
        return 1;
    }

    int flush()
    {
        return (str_ != 0 && send_buf() && str_->flush());
    }

protected:
    void free_mem()
    {
        if (buf_ != 0)
        {
            delete [] buf_;
            buf_ = 0;
        }
    }

    int send_buf()
    {
        if (p_ != buf_)
        {
            if (str_ == 0)
                return 0;

            size_t len = p_ - buf_;
            if (str_->write_bytes(buf_, len) != len)
                return 0;
        }
        p_ = buf_;
        return 1;
    }

    ZIStream *str_;
    zd_uchar *buf_;
    zd_uchar *p_;
    size_t bufsiz_;
};

ZDecoder::ZDecoder()
{
    hdr_max_bits_ = 0;
}

ZDecoder::~ZDecoder()
{
}

int ZDecoder::open(ZIStream *instr)
{
    /* read the signature */
    zd_uchar buf[HDRSIZE];
    long pos = instr->getpos();
    int ret = (instr->read_bytes(buf, HDRSIZE) == HDRSIZE
               && buf[0] == SIG_MAGIC1 && buf[1] == SIG_MAGIC2);

    /* read the header parameter flags */
    zd_uchar hdr = buf[2];
    hdr_max_bits_ = hdr & HDRMASK_BITS;

    /* 
     *   validate the header flags - we only handle block mode and only bit
     *   sizes 9-16
     */
    if (!(hdr & HDRMASK_BLOCKMODE)
        || hdr_max_bits_ < 9
        || hdr_max_bits_ > 16)
        ret = 0;

    /* 
     *   if it's not a .Z stream after all, rewind it in case the caller
     *   wants to try submitting the stream to another decoder
     */
    if (!ret)
        instr->setpos(pos);

    /* if successful, remember the stream */
    if (ret)
        instr_ = instr;

    /* return the result */
    return ret;
}

int ZDecoder::decode(ZIStream *outstr)
{
    zd_uint16 *parents;
    zd_uchar *suffixes;
    zd_uchar *stack;
    int ret = 1;

    /* set up the streams */
    ZStreamInBuffer inbuf;
    ZStreamOutBuffer outbuf;
    if (!inbuf.open(instr_, 16384) || !outbuf.open(outstr, 16384))
        return 0;

    /* allocate our decoding buffers */
    zd_uint32 itemcnt = (1 << hdr_max_bits_);
    parents = new zd_uint16[itemcnt];
    suffixes = new zd_uchar[itemcnt];
    stack = new zd_uchar[itemcnt];

    /* make sure we got all the buffer space we need */
    if (parents == 0 || suffixes == 0 || stack == 0)
    {
        if (parents != 0)
            delete [] parents;
        if (suffixes != 0)
            delete [] suffixes;
        if (stack != 0)
            delete [] stack;
        return 0;
    }

    /* clear some sensitive bits in the buffers */
    parents[256] = 0;
    suffixes[256] = 0;

    /* read the stream */
    int bitcnt = INIT_BITS;
    zd_uint32 head = INIT_HEAD;
    int need_suffix = 0;
    int keep_bits = 0;
    for (;;)
    {
        zd_uint32 sym = inbuf.read_bits(bitcnt);
        if (inbuf.eof())
            break;
        if (sym >= head)
        {
            ret = 0;
            break;
        }
        if (keep_bits < bitcnt)
            keep_bits = bitcnt * 8;
        keep_bits -= bitcnt;

        if (sym == SYM_CLEARTAB)
        {
            for ( ; keep_bits > 0 ; keep_bits--)
                inbuf.read_bits(1);
            bitcnt = 9;
            head = 257;
            need_suffix = 0;
            continue;
        }

        zd_uint32 cur = sym;
        int i = 0;
        while (cur >= 256)
        {
            stack[i++] = suffixes[cur];
            cur = parents[cur];
        }
        stack[i++] = (zd_uchar)cur;

        if (need_suffix)
        {
            suffixes[head - 1] = (zd_uchar)cur;
            if (sym == head - 1)
                stack[0] = (zd_uchar)cur;
        }
        while (i > 0)
            outbuf.write_byte((stack[--i]));

        if (head < itemcnt)
        {
            need_suffix = 1;
            parents[head++] = (zd_uint16)sym;
            if (head > ((zd_uint32)1 << bitcnt))
            {
                if (bitcnt < hdr_max_bits_)
                {
                    bitcnt++;
                    keep_bits = bitcnt * 8;
                }
            }
        }
        else
            need_suffix = 0;
    }

    /* flush the output buffer */
    ret &= outbuf.flush();

    /* free buffers */
    delete [] parents;
    delete [] suffixes;
    delete [] stack;

    /* return the result */
    return ret;
}

#ifdef TESTMAIN
void main()
{
    int err = 2;
    StdioZStream instr, outstr;
    ZDecoder d;

    if (!instr.open(stdin) || !outstr.open(stdout))
        fprintf(stderr, "unable to set up stdin/stdout streams\n");
    else if (!d.open(&instr))
        fprintf(stderr, "not a .Z stream\n");
    else if (!d.decode(&outstr))
        fprintf(stderr, "error decoding stream\n");
    else if (!outstr.close())
        fprintf(stderr, "error flushing stream\n");
    else
        err = 0;

    exit(err);
}
#endif
