// DecompressLibrary.h  Version 1.0
//
// Authors:  Marius Ciorecan (cmaryus@yahoo.com)
//
//
// Version 1.0   - Using XUnzip and gzip classes to make a general class that could decompress a zip, gz, tar.gz
// //
///////////////////////////////////////////////////////////////////////////////
//
// Marius Ciorecan comments:
// --------------------------
// The class uses the code from :
//      - XUnzip library written by Hans Dietrich (hdietrich2@hotmail.com) for decompression of zip files.
//      - CGzip library written by Jonathan de Halleux (dehalleux@pelikhan.com)
//  All other source files from this library contain the original source code, see there the copyright
//  The class uses also the specifications for the TAR format, in order to extract data from a tar file.

#pragma once

#include "xunzip.h"
namespace zlib { class CGZip; };

enum EArchiveType
{
    UNKNOWN_ARCHIVE = 0,
    ZIP_ARCHIVE,
    GZIP_ARCHIVE,
    TAR_GZIP_ARCHIVE,
    Z_ARCHIVE,
    TAR_Z_ARCHIVE
};

class CDecompressClass
{
public:
    CDecompressClass(void);
    ~CDecompressClass(void);

    /***********************************************************************
    Open a compressed file.
    Parameters
        pszCompressedFile - name of the file
    Return values:
        TRUE  - file opened successfully
        FALSE - file could not be opened (use GetErrorText() to
                retrieve the specific error message)
    Note:
        The archive file must be stored in one of these formats:
        - .zip
        - .gz
        - .tar.gz
        - .tgz

        The actual filename extension isn't important; we detect the
        format based on signatures and headers within the file.
    ***********************************************************************/
    BOOL    OpenArchive(IN const char* pszArchiveFile);

    /***********************************************************************
    Closes the archive, destroys all the internal objects
    ***********************************************************************/
    void    CloseArchive();

    /***********************************************************************
    Get number of files in the archive
    Return values:
        Number of files in the archive.
        -1 if there are errors.
    ***********************************************************************/
    int     GetCompressedFilesCount();

    /***********************************************************************
    Get a buffer that contain the file in archive at a specific position
    Params:
        nFileIndex - file position in archive
        pszFileBuffer - buffer containg the file data
        nFileSize - file size
        fIsFile - TRUE if this is a regular file, FALSE otherwise
                  (directory, link, etc)
        szFileName - name of the file
        pszImpliedFilename - this is the name we use for wrapper formats
                  like .gz and .Z that just store a single compressed
                  data stream with no internal metadata; for these there's
                  no stored filename, so we'll let the caller tell us what
                  to use.  The usual convention is to name this type of
                  compressed file by appending the format suffix (.gz, .Z,
                  etc) to the original filename; so the caller can usually
                  just work backwards to get the original filename by
                  stripping off the last suffix.  But we don't care what's
                  passed here; the only thing we do with it is copy it back
                  when asked to retrieve the single file from one of these
                  metadata-free wrapper formats.
    Return values:
        TRUE - file found and buffer filled correctly
        FALSE - some error (use GetErrorText() to find the error)
    Note:
        All data buffers will be allocated/deleted internally in this class,
        they should not be changed from outside !
    ***********************************************************************/
    BOOL    GetArchiveFile(IN int nFileIndex, 
                           OUT char** pszFileBuffer, 
                           OUT int& nFileSize,
                           OUT BOOL& fIsFile,
                           OUT char *pszFileName,
                           IN size_t szFileNameSize,
                           IN const char *pszImpliedFilename);


    /***********************************************************************
    Get last error if there were any problems
    ***********************************************************************/
    const char *GetErrorText();

private:
    // check to see if m_pFileBuffer contains a tar file
    int OpenCheckTar(EArchiveType typ);

    // gzip object
    // we will use this if it's a gzip file
    class zlib::CGZip *m_GZIP;
    
    // (for .zip we will use the unzip API's from Mark Adler library)
    HZIP            m_hZIP;

    // for a .Z file
    class ZDecoder *m_Z;
    
    // name of the archive
    char           *m_szArchiveName;

    // buffer with all data from the archive file
    char*           m_pFileBuffer;
    size_t          m_nBufferLen;

    // last error
    char           *m_szLastError;

public:
    // type of the archive
    EArchiveType    m_nArchiveType;
};
