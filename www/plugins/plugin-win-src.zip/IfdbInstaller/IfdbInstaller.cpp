// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// IfdbInstaller.cpp : Implementation of WinMain

#include "stdafx.h"
#include "resource.h"
#include <atlcoll.h>
#include <ctype.h>
#include <shlobj.h>
#include <shellapi.h>
#include "MainDlg.h"
#include "PlayerDlg.h"
#include "UpdateDlg.h"
#include "ifdbinst.h"
#include "ProgressDialog.h"
#include "GameUpdateDlg.h"
#include "decompression/DecompressClass.h"
#include "md5.h"

static const TCHAR msgbox_title[] = _T("IFDB Installer");

// some registration names
static const TCHAR CTL_WIN_CLS[] = _T("ifdb.tads.org/windows/ctlwin");

// WM_COPYDATA message prefix for ID query messages
static const TCHAR QUERY_MSG[] = _T("[ifdb.tads.org/msg/QueryID]");


// safe strcpy - limits the copy to the buffer size, and always null-terminates
static void safe_strcpy(char *dst, size_t dstsiz, const char *src)
{
    size_t copylen = strlen(src);
    if (dstsiz == 0)
        return;
    if (copylen > dstsiz - 1)
        copylen = dstsiz - 1;
    memcpy(dst, src, copylen);
    dst[copylen] = '\0';
}

// interpreter registry key information structure
struct terpKeys
{
    CAtlString vsn;
    CAtlString ignoreVsn;
    CAtlString runGame;
    CAtlString runGameRestore;
};

// WriteTerpKey flags
const DWORD WTK_VERSION       = 0x0001;
const DWORD WTK_IGNOREVERSION = 0x0002;
const DWORD WTK_RUNGAME       = 0x0004;

// AutoUpdate registry key path
static LPCTSTR autoUpdateKey = _T("Software\\IFDB.tads.org\\")
                               _T("MetaInstaller\\AutoUpdate");

// persistent cleanup list registry key path
static LPCTSTR cleanupKey = _T("Software\\IFDB.tads.org\\")
                            _T("MetaInstaller\\Cleanup List");

// are auto-updates enabled?
bool AutoUpdatesEnabled()
{
    CRegKey k;

    // auto-updates are enabled by default
    DWORD enabled = 1;

    // check the registry for the preference setting
    if (k.Open(HKEY_CURRENT_USER, autoUpdateKey, KEY_READ) == ERROR_SUCCESS)
    {
        if (k.QueryDWORDValue(_T("Enable"), enabled) != ERROR_SUCCESS)
            enabled = 1;

        k.Close();
    }

    // return what we found
    return (enabled != 0);
}

// turn auto-updates on or off
void EnableAutoUpdates(bool enabled)
{
    CRegKey k;

    // create the AutoUpdate registry key, and set the Enabled value
    if (k.Create(HKEY_CURRENT_USER, autoUpdateKey, REG_NONE,
                 REG_OPTION_NON_VOLATILE, KEY_WRITE, 0, 0)
        == ERROR_SUCCESS)
    {
        // set the value
        k.SetDWORDValue(_T("Enable"), enabled ? 1 : 0);

        // done with the key
        k.Close();
    }
}

// create a directory, including all intermediate parent folders
static bool create_dir(LPCTSTR dir)
{
    TCHAR parent[MAX_PATH];
    LPCTSTR p;
    
    // work through the path to make sure all parent directories exist
    for (p = dir ; *p != '\0' ; ++p)
    {
        // if we're at a path separator, and this isn't the root directory,
        // check to make sure this parent exists
        if (*p == '\\' && p > dir && *(p-1) != ':' && *(p-1) != '\\')
        {
            // pull out the parent path
            memcpy(parent, dir, p - dir);
            parent[p - dir] = '\0';

            // make sure this isn't a root share - that is, a path of
            // of the form "\\share" - if it starts with a \\, we need
            // at least one more \ later on...
            if (parent[0] == '\\' && parent[1] == '\\')
            {
                for (p = parent + 3 ; *p != '\\' && *p != '\0' ; ++p) ;
                if (*p == '\0')
                    continue;
            }

            // if the current path doesn't exist, create it
            if (GetFileAttributes(parent) == INVALID_FILE_ATTRIBUTES
                && !CreateDirectory(parent, 0))
                return FALSE;
        }
    }

    // we've created all parent paths, so create the final path
    return (GetFileAttributes(dir) != INVALID_FILE_ATTRIBUTES
            || CreateDirectory(dir, 0));
}

// recursively remove a directory and its contents
static bool remove_dir_recurse(LPCTSTR dir)
{
    TCHAR pat[MAX_PATH];
    bool ok = true;
    
    // scan the directory's contents to remove its children
    WIN32_FIND_DATA fd;
    PathCombine(pat, dir, "*");
    HANDLE hf = FindFirstFile(pat, &fd);
    if (hf != 0)
    {
        do
        {
            // skip '.' and '..', for obvious reasons
            if (fd.cFileName[0] == '.'
                && (fd.cFileName[1] == '\0'
                    || (fd.cFileName[1] == '.'
                        && fd.cFileName[2] == '\0')))
                continue;

            // get the full path for this item
            TCHAR fname[MAX_PATH];
            PathCombine(fname, dir, fd.cFileName);

            // if this is a directory, recursively remove it; otherwise
            // just delete the file
            DWORD attr = GetFileAttributes(fname);
            if (attr != INVALID_FILE_ATTRIBUTES)
            {
                bool curok;
                
                if ((attr & FILE_ATTRIBUTE_DIRECTORY) != 0)
                    curok = remove_dir_recurse(fname);
                else
                    curok = (DeleteFile(fname) != 0);

                if (!curok)
                    ok = false;
            }
        }
        while (FindNextFile(hf, &fd));

        // end the search
        FindClose(hf);
    }

    // the directory should be empty now, so delete it
    if (!RemoveDirectory(dir))
        ok = false;

    // return the status indication
    return ok;
}

// Delete a file or directory.  If the object is a directory, we'll remove
// the directory and recursively delete all of its contents.
static bool delete_file_or_dir(LPCTSTR objname)
{
    // check the file type, so we can do the appropriate type of deletion
    DWORD attrs = GetFileAttributes(objname);
    if (attrs != INVALID_FILE_ATTRIBUTES)
    {
        if ((attrs & FILE_ATTRIBUTE_DIRECTORY) != 0)
            return remove_dir_recurse(objname);
        else
            return (DeleteFile(objname) != 0);
    }

    // the file doesn't exist, so we can't delete it
    return false;
}

// Transfer a list of files to the persistent cleanup list.  We'll
// delete the files from the given list as we add them to the
// persistent list, so that the caller will know not to delete
// them during the current run.
static void AddPersistentCleanup(CAtlList<CAtlString> &lst)
{
    // open/create the Cleanup List key
    CRegKey k;
    if (k.Create(HKEY_CURRENT_USER, cleanupKey, REG_NONE,
                 REG_OPTION_NON_VOLATILE, KEY_WRITE, 0, 0)
        == ERROR_SUCCESS)
    {
        int i, hi;
        
        // get the high-water mark for existing values, if any
        // (the values are numbered 1, 2, ...)
        for (hi = 0, i = 0 ; ; ++i)
        {
            TCHAR name[128];
            DWORD nameLen = 128;
            
            // get the next value
            if (RegEnumValue(k, i, name, &nameLen, 0, 0, 0, 0)
                == ERROR_SUCCESS)
            {
                // check for a new high-water mark
                int cur = atoi(name);
                if (cur > hi)
                    hi = cur;
            }
            else
            {
                // no more values - stop looking
                break;
            }
        }
        
        // now add the values from the list
        for (i = hi + 1 ; lst.GetCount() != 0 ; ++i)
        {
            // set up the name
            TCHAR name[32];
            itoa(i, name, 10);
            
            // get this item, and add a value for it
            CAtlString cur = lst.GetTail();
            k.SetStringValue(name, cur);
            
            // remove this item from the list - we don't want to
            // delete it on our way out on this run
            lst.RemoveTail();
        }
        
        // done with the key
        k.Close();
    }
}

// apply the persistent cleanup list from past runs
static void DoPersistentCleanup()
{
    // open the main cleanup key
    CRegKey k;
    if (k.Open(HKEY_CURRENT_USER, cleanupKey, KEY_READ | KEY_WRITE)
        == ERROR_SUCCESS)
    {
        // enumerate the values
        for (int i = 0 ; ; ++i)
        {
            TCHAR name[128];
            DWORD nameLen = 128;
            TCHAR val[MAX_PATH];
            DWORD valLen = MAX_PATH;
            DWORD typ;
            
            // get the next value
            if (RegEnumValue(
                k, i, name, &nameLen, 0, &typ,
                (LPBYTE)val, &valLen) == ERROR_SUCCESS)
            {
                // delete this file, if it's a filename
                if (typ == REG_SZ)
                    delete_file_or_dir(val);
                
                // remove this value - it's served its purpose
                k.DeleteValue(name);
            }
            else
            {
                // no more values
                break;
            }
        }
        
        // done with the key
        k.Close();
    }
}

// Fix a filename by changing any characters that are invalid in
// the local file system to underscores.  If keep_path is true,
// we'll keep backslashes, and convert forward slashes to backslashes;
// otherwise we'll treat all slashes as invalid characters.
static void fix_filename(char *fname, int keep_path)
{
    char inval_sub = '_';
    char slash_sub = (keep_path ? '\\' : inval_sub);

    // scan the filename
    for (char *p = fname ; *p != '\0' ; ++p)
    {
        // change any unix-style slashes to backslashes
        if (*p == '/' || *p == '\\')
            *p = slash_sub;
        else if (strchr(":*?\"<>|", *p) != 0 || *p < ' ')
            *p = inval_sub;
    }
}

// given a URL, get the base filename (i.e., the last piece of the path),
// fixed up to local file system naming conventions (i.e., with any invalid
// characters replaced with something valid)
static void get_url_base_name(CAtlString &basename, LPCTSTR url)
{
    TCHAR buf[MAX_PATH];
    
    // find the last '/' in the url; failing that, find the last colon
    LPCTSTR sep = strrchr(url, '/');
    if (sep == 0)
        sep = strrchr(url, ':');

    // copy the part from just after the last separator (or, if there are
    // no separators, use the whole URL string)
    safe_strcpy(buf, MAX_PATH, sep != 0 ? sep + 1 : url);

    // fix it to local naming standards
    fix_filename(buf, FALSE);

    // return the name
    basename = buf;
}

// quote a chunk of XML content text
static void QuoteXML(CAtlString &qval, LPCTSTR val)
{
    LPCTSTR p, start;
    for (p = start = val ; *p != '\0' ; ++p)
    {
        LPCTSTR entity;
        
        switch (*p)
        {
        case '<':
            entity = "&lt;";
            goto markup;
            
        case '>':
            entity = "&gt;";
            goto markup;
            
        case '&':
            entity = "&amp;";
            goto markup;
            
        markup:
            // add the unquoted part up to here
            if (p != start)
                qval += CAtlString(start, (int)(p - start));
            
            // add the entity
            qval += entity;
            
            // the next chunk starts at the next character
            start = p + 1;
            break;
            
        default:
            // keep everything else as it is
            break;
        }
    }
    
    // add the final chunk
    if (start != p)
        qval += start;
}

// Given a parent path and a download descriptor, determine the name of
// the local file from the download.  If the download file is compressed,
// this uses the name of the primary file in the compressed archive as
// the local filename; otherwise it uses the root filename from the
// download URL.
static void GetLocalFilePath(CAtlString &fname, LPCTSTR dir, dlfile &f)
{
    TCHAR buf[MAX_PATH];

    // the file we use depends on the compression status
    if (f.compr != "" && f.comprPri !="")
    {
        // it's compressed - use the compressed primary file as the
        // local file
        PathCombine(buf, dir, f.comprPri);
    }
    else
    {
        // look for the file itself - convert the URL to local file
        // system notation, then find the root name from the URL
        CAtlString lclfname;
        get_url_base_name(lclfname, f.url);

        // build the full path to this file
        PathCombine(buf, dir, lclfname);
    }

    // return the result
    fname = buf;
}

// Instructions request.  This sends the initial request for
// the XML instructions packet for the game to the IFDB server.
class InstructionsRequest: public NetworkRequest
{
public:
    InstructionsRequest(LPCTSTR id, LPCTSTR osid, LPCTSTR mirrorID)
    {
        // remember the ID of the game we're downloading
        this->id = id;
        this->osid = osid;
        this->mirrorID = mirrorID;
    }

    // TUID of the game we're downloading
    CAtlString id;

    // ID of our operating system
    CAtlString osid;

    // mirror ID
    CAtlString mirrorID;

    // XML result string
    CAtlString xml;

    LPCTSTR GetInitMsg() const
    { 
        return _T("Retrieving the game's information from IFDB..."); 
    }
    void GetProgressMsg(
        CAtlString &msg,
        unsigned __int64 bytes_so_far, unsigned __int64 file_size,
        LPCTSTR url) const
    {
        msg = GetInitMsg();
    }

    void DoRequest(HWND dlg)
    {
        // set up the request URL
        CAtlString url = _T("http://ifdb.tads.org/dladviser?xml");
        url += _T("&id=") + id + _T("&os=Windows.") + osid;
        if (mirrorID != "")
            url += _T("&mirror=") + mirrorID;

        // perform the download
        success = DownloadFile(dlg, &xml, 0, url);
    }
};

// Download item
struct dlitem
{
    dlitem() { }

    void init(dlfile &dl, LPCTSTR outdir)
    {
        TCHAR fn[MAX_PATH];

        // save the settings
        this->dl = dl;
        this->outdir = outdir;

        // get the root filename from the URL, in case we want to base the
        // local copy's name on the root name
        CAtlString basename;
        get_url_base_name(basename, dl.url);

        // get the temporary directory, in case we need that
        TCHAR tmp[MAX_PATH];
        GetTempPath(MAX_PATH, tmp);

        // Generate the output filename:
        //
        // - If the file is compressed, we're actually interested in
        // the contents of the compressed archive, so we only need the
        // downloaded file itself long enough to unpack it.  So, save
        // it as a temp file.
        //
        // - If there's no output directory specified, the whole
        // download is temporary, meaning that we're going to execute
        // it or otherwise process it in the course of the install.
        // In this case, we want to preserve the original name (in
        // particular the extension, so that we get the right shell
        // file-type association).  To do this, create a whole temp
        // folder just for this download, to guarantee that there
        // won't be a name collision.
        if (this->outdir == "")
        {
            // The whole download is temporary - create a temporary
            // directory to hold the file, and name the file according
            // to the base name from the URL.
            //
            // Note that Windows actually creates an empty file for us,
            // so we can't use the returned name as the directory name
            // (we'd be unable to create it, since it's already in use
            // as a regular file's name).  We don't want to just delete
            // that sentinel file, though, since its presence ensures
            // uniqueness with respect to other temp files that we or
            // other apps create.  So what we'll do is call our directory
            // <tmpname>.dir - we can be reasonably certain this will
            // be safe against collisions beacuse of the sentinel file.

            // set up the temp file, and log it for cleanup
            TCHAR newdir[MAX_PATH];
            GetTempFileName(tmp, _T("ifd"), 0, newdir);
            tmpfiles.AddTail(newdir);

            // build our temp directory name, and log it for cleanup
            strcat(newdir, ".dir");
            tmpfiles.AddTail(newdir);

            // combine our temp directory name with the URL base filename
            PathCombine(fn, newdir, basename);
        }
        else if (dl.compr != "")
        {
            // it's compressed - download to a temp file
            GetTempFileName(tmp, _T("ifd"), 0, fn);

            // log it as a temp file for cleanup
            tmpfiles.AddTail(fn);
        }
        else
        {
            // An output directory was specified, so the downloaded file
            // is a keeper - the filename is simply the base name from
            // the URL, and the location is the given output directory.
            PathCombine(fn, outdir, basename);
        }

        // use the local name in fn
        localname = fn;

        // if this file isn't compressed, the primary file is the local file;
        // for a compressed file, we don't know yet where the primary file
        // will end up, since that's up to the unpacking algorithm
        if (dl.compr == "")
            localPrimary = fn;
    }

    ~dlitem()
    {
        // clean up our temp files
        for (POSITION pos = tmpfiles.GetHeadPosition() ; pos != 0 ;
             tmpfiles.GetNext(pos))
        {
            // Delete this file or directory.  If the deletion fails,
            // don't worry about it - we create our temporary files in
            // the standard Windows temp directory, so we can just punt
            // and assume that they'll get cleaned up later in the
            // course of routine housekeeping.
            delete_file_or_dir(tmpfiles.GetAt(pos));
        }
    }

    // the downloadable file description
    dlfile dl;

    // local file name
    CAtlString localname;

    // The final path to the primary local file.  For a compressed item,
    // this can only be set when the file is actually unpacked, since
    // the unpacker determines where the unpacked files will end up.
    // For uncompressed files, this is simply the local filename.
    CAtlString localPrimary;

    // output directory
    CAtlString outdir;

    // temporary files to clean up when we're done
    CAtlList<CAtlString> tmpfiles;
};

// Main download request
class MainDownloadRequest: public NetworkRequest
{
public:
    MainDownloadRequest(CAtlList<dlitem> *files)
    {
        this->files = files;
        number_of_files_ = files->GetCount();
    }

    LPCTSTR GetBaseMsg() const { return 0; }

    CAtlList<dlitem> *files;

    void DoRequest(HWND dlg)
    {
        CAtlString msg;

        // presume success
        bool ok = true;
        
        // iterate over the files
        for (POSITION pos = files->GetHeadPosition() ; pos != 0 ;
             files->GetNext(pos))
        {
            // get this item from the list
            dlitem &item = files->GetAt(pos);

            // make sure the output folder exists
            TCHAR dldir[MAX_PATH];
            safe_strcpy(dldir, sizeof(dldir), item.localname);
            PathRemoveFileSpec(dldir);
            if (GetFileAttributes(dldir) == INVALID_FILE_ATTRIBUTES
                && !create_dir(dldir))
            {
                msg.Format(
                    _T("An error occurred creating a folder for ")
                    _T("downloaded items. Check your disk for ")
                    _T("adequate space and permissions. (The ")
                    _T("error occurred creating \"%s\".)"),
                    dldir);
                errMsgBox(dlg, msg);
                ok = false;
                break;
            }

            // download this file
            ok = DownloadFile(dlg, 0, item.localname, item.dl.url);

            // if that failed, stop now
            if (!ok)
                break;

            // if it's a compressed file, unpack it; otherwise the primary
            // file is the downloaded file itself
            if (item.dl.compr != "")
                ok = UnpackArchive(dlg, item);

            // check for errors
            if (!ok)
                break;
        }

        // if the downloads failed, give up
        if (!ok)
        {
            success = false;
            return;
        }

        // We've downloaded everything successfully, so proceed to
        // running any installers we downloaded.  Remove the progress
        // bar at this point, since there's no basis for estimation
        // from here on.
        ShowProgressBar(dlg, FALSE);
        SetProgressMsg(dlg, "Downloads completed; preparing installation.");

        // run through the files looking for "run" actions
        for (POSITION pos = files->GetHeadPosition() ; pos != 0 ;
             files->GetNext(pos))
        {
            // get this item
            dlitem &item = files->GetAt(pos);

            // If the action on this download is "run", it means that this
            // is a SETUP program that we must execute in order to complete
            // the installation.
            if (item.dl.action == "run")
            {
                // update the status
                msg.Format("Running Setup for %s", item.dl.desc);
                SetProgressMsg(dlg, msg);
                
                // if we don't have a primary file, this is impossible
                if (item.localPrimary == "")
                {
                    msg.Format(
                        _T("One of the files in your download doesn't ")
                        _T("have all of the necessary information set ")
                        _T("in the IFDB records to complete the ")
                        _T("installation. You might still be able to ")
                        _T("perform the installation manually - go to ")
                        _T("the game's IFDB page and click \"Show Me ")
                        _T("How\" for instructions. (The file causing ")
                        _T("the error was \"%s\".)"),
                        item.dl.url);
                    errMsgBox(dlg, msg);
                    ok = false;
                    break;
                }

                // set up to run the primary file from the download
                SHELLEXECUTEINFO sx;
                memset(&sx, 0, sizeof(sx));
                sx.fMask = SEE_MASK_FLAG_DDEWAIT | SEE_MASK_NOCLOSEPROCESS;
                sx.cbSize = sizeof(sx);
                sx.lpVerb = "open";
                sx.lpFile = item.localPrimary;
                sx.nShow = SW_SHOWNORMAL;

                // add the parameters, if present
                if (item.dl.runParams != "")
                    sx.lpParameters = item.dl.runParams;

                // use the file's folder as the working directory
                TCHAR pwd[MAX_PATH];
                safe_strcpy(pwd, sizeof(pwd), sx.lpFile);
                PathRemoveFileSpec(pwd);
                sx.lpDirectory = pwd;

                // launch it
                if (!ShellExecuteEx(&sx) || (DWORD_PTR)sx.hInstApp <= 32)
                {
                    // didn't work - show the appropriate error message
                    if (item.dl.runErrMsg == "")
                    {
                        // use the default game-file message
                        msg.Format(
                            _T("An error occurred invoking a Setup program ")
                            _T("that's needed to complete the installation. ")
                            _T("You might still be able to ")
                            _T("perform the installation manually - go to ")
                            _T("the game's IFDB page and click \"Show Me ")
                            _T("How\" for instructions. (The file causing ")
                            _T("the error was \"%s\".)"),
                            item.dl.url);
                        errMsgBox(dlg, msg);
                    }
                    else
                    {
                        // there's a custom error message - use it
                        errMsgBox(dlg, item.dl.runErrMsg);
                    }

                    // indicate failure and stop
                    ok = false;
                    break;
                }

                // if we're not in detached mode, wait for the process
                // to finish
                if (sx.hProcess != 0 && !item.dl.runDetached)
                {
                    // let them know what's going on
                    msg.Format("Running Setup for %s\r\n\r\n"
                               "(waiting for the program to finish...)",
                               item.dl.desc);
                    SetProgressMsg(dlg, msg);

                    // wait for the process to terminate, or for the
                    // user to explicitly kill us with the Cancel button
                    HANDLE objs[2] = { sx.hProcess, cancelEvent_ };
                    switch (WaitForMultipleObjects(2, objs, FALSE, INFINITE))
                    {
                    case WAIT_OBJECT_0:
                        // the process exited - continue normally
                        break;

                    case WAIT_OBJECT_0 + 1:
                        // canceled - do not go on
                        ok = false;
                        break;
                    }
                }

                // close the process handle if we got one
                if (sx.hProcess != 0)
                    CloseHandle(sx.hProcess);

                // if we're running in detached mode, move any temp file
                // cleanup list for this item to the persistent list -
                // since we're leaving the program running after we
                // finish, we can't delete its temp files on our way
                // out the way we would for programs that we wait for
                if (item.dl.runDetached)
                    AddPersistentCleanup(item.tmpfiles);
            }

            // stop if anything went wrong on this round
            if (!ok)
                break;
        }

        // if all files downloaded successful, we were successful
        success = ok;
    }

    // unpack a compressed archive file
    bool UnpackArchive(HWND dlg, dlitem &item)
    {
        CAtlString msg;
        CAtlString expdir;

        // If we have an output directory in the item spec, it
        // means that we want to keep the results of the download
        // in that directory, so simply unpack into that directory.
        //
        // Otherwise, we only need the unpacked files temporarily.
        // Since a compressed file is always downloaded to the temp
        // directory, we can unpack under this same directory; but
        // in order to keep the unpacked files together, and to ensure
        // that we can use the names as they appear in the archive
        // without fear of colliding with anything already existing
        // in the temp directory, create a new subdirectory under
        // the temp folder containing the compressed download file.
        // Call this <tempname>.contents, where <tempname> is the name
        // of the temporary archive file itself.
        if (item.outdir != "")
        {
            // we actually want to keep the unpacked files - put them
            // directly in the output directory
            expdir = item.outdir;
            
            // make sure the output directory exists
            if (GetFileAttributes(expdir) == INVALID_FILE_ATTRIBUTES
                && !create_dir(expdir))
            {
                msg.Format(
                    _T("An error occurred creating a folder for ")
                    _T("downloaded items. Check your disk for ")
                    _T("adequate space and permissions. (The ")
                    _T("error occurred creating \"%s\".)"),
                    expdir);
                char errmsg[256];
                FormatMessage(0, 0, GetLastError(), 0, errmsg, 256, 0);
                errMsgBox(dlg, msg);
                return false;
            }
        }
        else
        {
            // The unpacked files will be temporary; create a new
            // temp dir called "<tempname>.contents".  It's reasonably
            // safe to assume that this name won't collide with anything,
            // since we're basing this on an already unique temp file
            // name in the standard temp directory.
            expdir = item.localname + ".contents";
            if (!create_dir(expdir))
            {
                errMsgBox(
                    dlg, _T("An error occurred creating a folder ")
                    _T("to store temporary files from the download. ")
                    _T("Check your disk for adequate space."));
                return false;
            }

            // log our temp directory for cleanup
            item.tmpfiles.AddTail(expdir);
        }
        
        // set up a decompressor for it
        CDecompressClass dc;
        if (!dc.OpenArchive(item.localname))
        {
            // failed to open the archive - there must be a problem
            // decompressing it
            dcErrMsgBox(dlg, dc, item);
            return false;
        }

        // Build the implied name for the contents of a non-naming archive
        // format - these are formats like .Z, .gz, and .hqx that just contain
        // a single compressed file data stream without any metadata.  In
        // these cases, the convention is to name the compressed file by
        // appending the compression suffix (.Z, .gz, etc) to the name of
        // the original file: so we can just work backwards by stripping off
        // the final suffix from the filename given in the URL.
        CAtlString urlBase;
        get_url_base_name(urlBase, item.dl.url);

        // keep the filename up to (but not including) the last '.'; if
        // there's no '.', just keep the whole name
        LPCTSTR dot = strrchr(urlBase, '.');
        CAtlString impliedName =
            (dot != 0 ? CAtlString(urlBase, (int)(dot - urlBase)) : urlBase);

        // If there's a designated "primary file" in the archive, build
        // the path to the extracted file.  If there's no designated primary,
        // but the archive only contains one file, use that single file as
        // the primary.  Otherwise there's no primary file.
        item.localPrimary = "";
        TCHAR pribase[MAX_PATH] = "";
        if (item.dl.comprPri != "")
        {
            // there's an explicit primary file, so use that
            safe_strcpy(pribase, MAX_PATH, item.dl.comprPri);
        }
        else if (dc.GetCompressedFilesCount() == 1)
        {
            // there's no explicit primary file, but there's only the one
            // file in the archive, so use it as implied primary
            char *contents;
            int siz;
            BOOL is_file;
            char fname[MAX_PATH];
            if (dc.GetArchiveFile(
                0, &contents, siz, is_file, fname, sizeof(fname), impliedName))
                safe_strcpy(pribase, MAX_PATH, fname);
        }

        // if we got a primary file, build the full path
        if (pribase[0] != '\0')
        {
            TCHAR pribuf[MAX_PATH];

            // fix up the primary filename to local standards
            fix_filename(pribase, TRUE);

            // combine it with the unpacking directory to get the full path
            PathCombine(pribuf, expdir, pribase);

            // store the final name back in the download item, so that we'll
            // be able to find this file later if necessary
            item.localPrimary = pribuf;
        }

        // presume success
        bool ok = true;

        // loop through the files and extract each one
        int cnt = dc.GetCompressedFilesCount();
        for (int i = 0 ; i < cnt ; ++i)
        {
            char *contents;
            int siz;
            BOOL is_file;
            char fname[MAX_PATH];
            size_t fname_len;
            TCHAR outfname[MAX_PATH];
            
            // get the file information
            if (!dc.GetArchiveFile(i, &contents, siz, is_file, 
                                   fname, sizeof(fname), impliedName))
            {
                // failed - flag an error and give up
                dcErrMsgBox(dlg, dc, item);
                ok = false;
                break;
            }

            // Fix any invalid characters in the filename; the various
            // archive formats that we handle can have relative path
            // names with '/' as the path separator, so keep the path,
            // changing slashes to backslashes.
            fix_filename(fname, TRUE);

            // build the full filename
            PathCombine(outfname, expdir, fname);

            // make sure that the parent directory for this file exists
            char parent[MAX_PATH];
            safe_strcpy(parent, MAX_PATH, outfname);
            PathRemoveFileSpec(parent);
            ok = create_dir(parent);

            // If the filename ends in '\' or '/', and the length is
            // zero, it's actually a directory.  Some zip programs seem
            // to create entries of this form without setting the
            // 'directory' bit in the file attributes.  This seems
            // like a bug in the zip program that created the archive,
            // in that you'd think the directory bit should be set for
            // a directory, but I'm not sure if it's actually a violation
            // of the zip.  But that's irrelevant given that there do
            // exist zip files in the wild with this type of entry.
            // It seems fairly unambiguous, so just handle it as though
            // it were a directory.
            if (is_file
                && siz == 0
                && (fname_len = strlen(fname)) != 0
                && (fname[fname_len - 1] == '\\'
                    || fname[fname_len - 1] == '/'))
                is_file = FALSE;
            
            // if it's a file, store it; otherwise, it's a directory,
            // so create the folder
            if (is_file)
            {
                // save the file
                HANDLE hf = CreateFile(
                    outfname, GENERIC_WRITE, 0, 0, CREATE_ALWAYS,
                    FILE_ATTRIBUTE_NORMAL, 0);
                
                if (hf != INVALID_HANDLE_VALUE)
                {
                    // write it
                    DWORD actual;
                    if (!WriteFile(hf, contents, siz, &actual, 0)
                        || actual != siz)
                        ok = false;
                    
                    // close the file
                    if (!CloseHandle(hf))
                        ok = false;
                }
                else
                    ok = false;
            }
            else
            {
                // create the directory
                if (!create_dir(outfname))
                    ok = false;
            }
            
            // check for errors
            if (!ok)
            {
                msg.Format(
                    _T("An error occurred saving the contents of a ")
                    _T("compressed downloaded file (%s; unpacking ")
                    _T("%s). Check that you have adequate disk ")
                    _T("space."),
                    item.dl.url, fname);
                errMsgBox(dlg, msg);
                break;
            }
        }

        // close the archive file
        dc.CloseArchive();

        // return the status indication
        return ok;
    }

    // show a decompression error
    void dcErrMsgBox(HWND dlg, class CDecompressClass &dc, dlitem &item)
    {
        CAtlString msg;
        
        msg.Format(
            _T("An error occurred unpacking the compressed ")
            _T("file %s: %s. This could be caused by a garbled ")
            _T("transmission during the download, so you might ")
            _T("want to try again. If the problem happens again, ")
            _T("it's probably due to either a corrupted file ")
            _T("on the server, or a problem in the Meta ")
            _T("installer itself."),
            item.dl.url, dc.GetErrorText());

        errMsgBox(dlg, msg);
    }

    // show an error message
    void errMsgBox(HWND dlg, LPCTSTR msg)
    {
        MessageBox(dlg, msg, msgbox_title, MB_OK | MB_ICONERROR);
    }
};

// The module attribute causes WinMain to be automatically implemented for you
[ module(EXE, uuid = "{8D9C0752-E4A4-4802-B2FF-8A0A023707F7}", 
         name = "IfdbInstaller", 
         helpstring = "IfdbInstaller 1.0 Type Library",
         resource_name = "IDR_IFDBINSTALLER") ]
class CIfdbInstallerModule
{
public:

    // simple XML parsing tag structure - we use this to represent a
    // value node at a particular path in an XML document
    struct xmltag
    {
        xmltag() : name(0) { }

        xmltag(LPCTSTR path, LPCTSTR name, LPCTSTR val)
            : path(path), val(val)
        {
            initName(name);
        }

        xmltag(const xmltag &t)
        {
            path = t.path;
            val = t.val;
            initName(t.name);
        }

        void initName(LPCTSTR name)
        {
            size_t plen = strlen(path), nlen = strlen(name);
            if (nlen < plen && strcmp(name, (LPCTSTR)path + plen - nlen) == 0)
                this->name = (LPCTSTR)path + plen - nlen;
            else
                this->name = "";
        }
            
        // the XMLPath style path ("a/b/c" for <a><b><c>xxx</c></b></a>)
        CAtlString path;

        // the base tag name
        LPCTSTR name;

        // the text value contained in the tag, with leading and trailing
        // whitespace trimmed off
        CAtlString val;
    };

    // XML tree node - we use this to build a simple XML parse tree
    struct xmlnode
    {
        xmlnode() { }
        xmlnode(LPCTSTR name, LPCTSTR val) : name(name), val(val) { }

        xmlnode(const xmlnode &x) : name(x.name), val(x.val) { }
        
        // the name of the node
        CAtlString name;

        // the text value within the node, if any
        CAtlString val;

        // the direct children
        CAtlList<xmlnode> children;

        // flatten my subtree into a path list
        void Flatten(LPCTSTR path, CAtlList<xmltag> &tags) const
        {
            CAtlString curPath;
            
            // build the full path to this element
            curPath = CAtlString(path) + "/" + name;

            // run through my children, recursively flattening each subtree
            for (POSITION pos = children.GetHeadPosition() ; pos != 0 ;
                 children.GetNext(pos))
                children.GetAt(pos).Flatten(curPath, tags);

            // add myself to the list
            tags.AddTail(xmltag(curPath, name, val));
        }

        // get the value of a tag identified by XMLPath notation
        LPCTSTR GetValue(LPCTSTR path) const
        {
            // find the node
            const xmlnode *n = Find(path);

            // return the value, or null if we didn't find the node
            return (n != 0 ? (LPCTSTR)n->val : 0);
        }

        // Find a tag via XMLPath notation.  The path is a child path -
        // it's relative to this tag (so it does NOT contain the name
        // of this tag as the leading element).  Use [n] to find the
        // nth matching child of a given element: a/b/c[3] matches
        // the third child named 'c' of a/b.
        const xmlnode *Find(LPCTSTR path) const
        {
            return ((xmlnode *)this)->Find(path);
        }
        xmlnode *Find(LPCTSTR path)
        {
            LPCTSTR p, start, endp;

            int idx = 0;
            bool foundIdx = false;

            // find the end of the current path element
            for (start = p = path, endp = 0 ; *p != '\0' && *p != '/' ; ++p)
            {
                // check for an index qualifier - [n]
                if (*p == '[' && !foundIdx)
                {
                    int acc = 0;
                    for (LPCTSTR q = p + 1 ; isdigit(*q) ; ++q)
                    {
                        acc *= 10;
                        acc += *q - '0';
                    }
                    if (*q == ']')
                    {
                        idx = acc;
                        foundIdx = true;
                        if (endp == 0)
                            endp = p;
                        p = q;
                    }
                }
            }
            
            // if we didn't find the end yet, the slash is the end
            if (endp == 0)
                endp = p;
            
            // note the name length
            size_t namelen = endp - start;

            // skip the slash if we found it
            if (*p == '/')
                ++p;
            
            // scan our children for matches
            for (POSITION pos = children.GetHeadPosition() ; pos != 0 ;
                 children.GetNext(pos))
            {
                // get this child
                xmlnode *chi = &children.GetAt(pos);
                
                // if its name matches, and it's the one at the
                // desired index, traverse into it
                if (strlen(chi->name) == namelen
                    && memcmp(chi->name, start, namelen) == 0
                    && idx-- == 0)
                {
                    // It's the one - recursively match it against the
                    // rest of the path.  If we're at the end of the
                    // path, this child is the match.
                    return (*p == '\0' ? chi : chi->Find(p));
                }
            }

            // we didn't find it
            return 0;
        }

        // get the nth child with the given name
        const xmlnode *GetChild(LPCTSTR name, int n) const
        {
            return ((xmlnode *)this)->GetChild(name, n);
        }
        xmlnode *GetChild(LPCTSTR name, int n)
        {
            // scan our child list for matches
            for (POSITION pos = children.GetHeadPosition() ; pos != 0 ;
                 children.GetNext(pos))
            {
                // if this child matches, count it; if n is zero, return it
                xmlnode *cur = &children.GetAt(pos);
                if (cur->name == name && n-- == 0)
                    return cur;
            }

            // didn't find it
            return 0;
        }

        // add a new tag via XMLPath notation
        xmlnode *Add(LPCTSTR parentPath, LPCTSTR name)
        {
            xmlnode *parent;
            
            // find the parent, and ask the parent to add the tag
            if ((parent = Find(parentPath)) == 0)
                return 0;
            else
                return parent->Add(name);
        }

        // add a new child tag
        xmlnode *Add(LPCTSTR name)
        {
            // add a child
            children.AddTail(xmlnode(name, ""));

            // return the child
            return &children.GetTail();
        }

        void ToString(CAtlString &str, CAtlString ns) const
        {
            // write out the processing tag
            str += "<?xml version=\"1.0\"?>\r\n";

            // write out the root tag with its namespace
            str += CAtlString("<") + name + " xmlns=\"" + ns + "\">\r\n";

            // write out my children
            for (POSITION pos = children.GetHeadPosition() ; pos != 0 ;
                 children.GetNext(pos))
                children.GetAt(pos).ToStringChi(str, "  ");

            // end the root tag
            str += CAtlString("</") + name + ">\r\n";
        }

        void ToStringChi(CAtlString &str, CAtlString indent = "") const
        {
            // if I have no contents of any kind, write a self-closing tag
            if (children.GetCount() == 0 && val == "")
            {
                str += indent + "<" + name + "/>\r\n";
                return;
            }
            
            // write my open tag
            str += indent + "<" + name + ">\r\n";
            
            // write my children
            for (POSITION pos = children.GetHeadPosition() ; pos != 0 ;
                 children.GetNext(pos))
                children.GetAt(pos).ToStringChi(str, indent + "  ");

            // write my text, quoting any entities within
            CAtlString qval;
            QuoteXML(qval, val);
            str += indent + "  " + qval + "\r\n";
            
            // write my close tag
            str += indent + "</" + name + ">\r\n";
        }
    };

    // control window class atom, handle, thread handle, and startup event
    ATOM ctlWinClass_;
    HWND ctlWin_;
    HANDLE ctlThread_;
    HANDLE ctlEvent_;

    // control window thread
    static DWORD CtlWinMain(void *ctx)
    {
        // 'ctx' is our 'self' object
        CIfdbInstallerModule *self = (CIfdbInstallerModule *)ctx;

        // create our window
                self->ctlWin_ = CreateWindow(
            CTL_WIN_CLS, "IFDB Installer",
            WS_POPUPWINDOW | WS_CAPTION,
            CW_USEDEFAULT, CW_USEDEFAULT, 100, 100,
            0, 0, _AtlBaseModule.GetResourceInstance(), self);

        // signal that the main window is up and running
        SetEvent(self->ctlEvent_);

        // run the message loop
        MSG msg;
        while (GetMessage(&msg, 0, 0, 0))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        // done
        return 0;
    }

    // control window procedure
    static LRESULT CALLBACK CtlWinProc(
        HWND hwnd, UINT msg, WPARAM wpar, LPARAM lpar)
    {
        CIfdbInstallerModule *self;
        
        // get our 'self' object, if applicable
        if (msg == WM_NCCREATE)
        {
            // retrieve the lParam from the window create structure
            CREATESTRUCT *ctx = (CREATESTRUCT *)lpar;
            self = (CIfdbInstallerModule *)ctx->lpCreateParams;

            // store it in our window
            SetWindowLong(hwnd, 0, (LONG)self);
        }
        else
        {
            // our 'self' should already be in our window object
            self = (CIfdbInstallerModule *)GetWindowLong(hwnd, 0);
        }

        // process the message
        switch (msg)
        {
        case WM_DESTROY:
            // when we're closed, quit our message loop
            PostQuitMessage(0);
            break;

        case WM_COPYDATA:
            // check for our private ID query
            {
                COPYDATASTRUCT *cds = (COPYDATASTRUCT *)lpar;
                if (cds->cbData > sizeof(QUERY_MSG)
                    && memcmp(cds->lpData, QUERY_MSG, sizeof(QUERY_MSG)) == 0)
                {
                    // it's our private query message - the message parameter
                    // (the part after the prefix) is the ID they're asking
                    // about; check to see if it matches our ID
                    char *qid = ((char *)cds->lpData) + sizeof(QUERY_MSG);
                    DWORD qid_len = cds->cbData - sizeof(QUERY_MSG);

                    // return true if it matches our ID, false if not
                    return (qid_len == strlen(self->id)
                            && memcmp(qid, self->id, qid_len) == 0);
                }
            }
            break;
        }

        // use the default handler for everything we don't otherwise handle
        return DefWindowProc(hwnd, msg, wpar, lpar);
    }

    // initialize the control window
    bool InitControlWin()
    {
        DWORD threadID;
        
        // set up the control event, so we know when the window is ready
        ctlEvent_ = CreateEvent(0, TRUE, FALSE, 0);

        // kick off the control window thread
        ctlThread_ = CreateThread(
            0, 0, (LPTHREAD_START_ROUTINE)&CtlWinMain, (void *)this,
            0, &threadID);

        // wait for the control event
        if (ctlThread_ == 0
            || WaitForSingleObject(ctlEvent_, 30000) != WAIT_OBJECT_0)
        {
            MessageBox(0, "An error occurred initializing the installer.",
                       msgbox_title, MB_OK | MB_ICONERROR);
            return false;
        }

        // success
        return true;
    }

    // find another instance that's already handling this same game
    struct WinEnumCtx
    {
        WinEnumCtx(CIfdbInstallerModule *self) : self(self), foundWin(0) { }
        CIfdbInstallerModule *self;
        HWND foundWin;
    };
    static BOOL CALLBACK FindOldInstance(HWND hwnd, LPARAM lpar)
    {
        // get the context
        WinEnumCtx *ctx = (WinEnumCtx *)lpar;

        // if this window is of our class, ask it about our ID
        if (GetClassLong(hwnd, GCW_ATOM) == ctx->self->ctlWinClass_)
        {
            // allocate space for the query message
            COPYDATASTRUCT cds;
            cds.dwData = 0;
            cds.cbData = sizeof(QUERY_MSG) + strlen(ctx->self->id);
            char *msg = new TCHAR[cds.cbData];
            cds.lpData = msg;
            
            // format the message
            memcpy(msg, QUERY_MSG, sizeof(QUERY_MSG));
            memcpy(msg + sizeof(QUERY_MSG), 
                   ctx->self->id, strlen(ctx->self->id));

            // send it
            LRESULT found = SendMessage(hwnd, WM_COPYDATA, 0, (LPARAM)&cds);

            // free the allocated space
            delete [] cds.lpData;

            // if the response was affirmative, return this window, and
            // stop looking
            if (found)
            {
                ctx->foundWin = hwnd;
                return FALSE;
            }
        }
            
        // continue the enumeration
        return TRUE;
    }
    static BOOL CALLBACK ActivateInstance(HWND hwnd, LPARAM lpar)
    {
        // get the context
        WinEnumCtx *ctx = (WinEnumCtx *)lpar;

        // if 'hwnd' is visible, and it's part of the same process as
        // the target window, activate it
                TCHAR buf[256];
                GetWindowText(hwnd, buf, sizeof(buf));
        if (IsWindowVisible(hwnd))
        {
            DWORD pid1, pid2;
            GetWindowThreadProcessId(hwnd, &pid1);
            GetWindowThreadProcessId(ctx->foundWin, &pid2);
            if (pid1 == pid2)
            {
                SetForegroundWindow(hwnd);
                return FALSE;
            }
        }

        // didn't find it - keep looking
        return TRUE;
    }

    // run the program
    HRESULT Run(int nShowCmd)
    {
        // register the control window class
        WNDCLASS wc;
        wc.style = 0;
        wc.lpfnWndProc = &CtlWinProc;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = sizeof(DWORD_PTR);
        wc.hInstance = _AtlBaseModule.GetResourceInstance();
        wc.hIcon = 0;
        wc.hCursor = 0;
        wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
        wc.lpszMenuName = 0;
        wc.lpszClassName = CTL_WIN_CLS;
        ctlWinClass_ = RegisterClass(&wc);

        // look for another instance that's already handling this same
        // download
        WinEnumCtx ctx(this);
        EnumWindows((WNDENUMPROC)&FindOldInstance, (LPARAM)&ctx);
        if (ctx.foundWin != 0)
        {
            // got it - bring it to the front and terminate, since we're
            // redundant
            EnumWindows((WNDENUMPROC)&ActivateInstance, (LPARAM)&ctx);
            return S_OK;
        }

        // set up the control window
        if (!InitControlWin())
            return E_FAIL;

        // run the install
        HRESULT ret = RunInstall();

        // close the control window
        SendMessage(ctlWin_, WM_CLOSE, 0, 0);

        // return the result
        return ret;
    }

    // run the install
    HRESULT RunInstall()
    {
        CMainDlg d;
        dlinfo info;
        LPCTSTR cname;
        int i;
        CAtlString oldMarkerFile;
        CAtlString newRunGameKey;

        // set up the common control library
        ::InitCommonControls();

        // handle any persistent cleanup list from past runs
        DoPersistentCleanup();

        // get our OS version
        CAtlString osid;
        if (!GetOSID(osid))
        {
            MessageBox(
                0,
                _T("The installer is unable to determine the specific ")
                _T("version of Windows you're using. You might need to ")
                _T("update your IFDB Installer to the latest version."), 
                msgbox_title, MB_OK | MB_ICONERROR);
                        return E_FAIL;
        }

        // request the installation instructions from IFDB
        InstructionsRequest ireq(id, osid, mirrorID);
        if (!DoNetworkRequest(0, ireq))
            return E_FAIL;
        
        // parse the XML; if it fails, or we get the wrong root node,
        // show an error and give up
        xmlnode tags;
        if (!ParseXML(tags, ireq.xml) || tags.name != "autoinstall")
        {
            MessageBox(
                0,
                _T("The IFDB server returned instructions that the ")
                _T("installer doesn't recognize. This could be caused ")
                _T("by a network transmission error, or by a problem ")
                _T("with the IFDB server."),
                msgbox_title, MB_OK | MB_ICONERROR);
            return E_FAIL;
        }

        // check for errors
        LPCTSTR errmsg = tags.GetValue(_T("error/message"));
        if (errmsg)
        {
            MessageBox(0, errmsg, msgbox_title, MB_OK | MB_ICONERROR);
            return E_FAIL;
        }

        // check for installer updates before we go any further
        if (NeedInstallerUpdate(tags, false))
            return S_OK;

        // get the IF Archive mirror
        info.archiveMirror = tags.GetValue(_T("ifarchivemirror"));

        // get the game description and download link
        info.tuid = tags.GetValue(_T("tuid"));
        info.title = tags.GetValue(_T("title"));
        info.author = tags.GetValue(_T("author"));
        info.gameVsn = tags.GetValue(_T("version"));
        info.game.url = tags.GetValue(_T("download/game/href"));
        info.fmtID = tags.GetValue(_T("download/game/format/id"));
        info.fmtName = tags.GetValue(_T("download/game/format/name"));
        info.game.compr = tags.GetValue(_T("download/game/compression/id"));
        info.game.comprPri = tags.GetValue(
            _T("download/game/compression/primaryfile"));
        info.game.comprName =  tags.GetValue(
            _T("download/game/compression/name"));
        LPCTSTR gametype = tags.GetValue(_T("download/game/type"));

        // presume that we'll need to download the game
        info.needGame = TRUE;
        info.installGame = TRUE;
        info.gameUpdate = FALSE;

        // if the game type is 'installer', we don't handle it
        if (gametype == 0
            || (strcmp(gametype, "storyfile") != 0
                && strcmp(gametype, "storyprogram") != 0))
        {
            MessageBox(
                0,
                _T("This game is available for donwload, but not in a ")
                _T("format that the Meta Installer can install. Please ")
                _T("go to the game's page on IFDB and click \"Show Me ")
                _T("How\" for instructions on installing the game ")
                _T("manually."),
                msgbox_title, MB_OK | MB_ICONINFORMATION);
            return E_FAIL;
        }

        // the 'action' for the game file is always 'save'
        info.game.action = "save";
        info.game.desc = info.title;

        // make sure the compression format is valid
        if (!ValidateCompression(info.game, TRUE))
            return E_FAIL;

        // load the interpreter tags
        xmlnode *terpTag = tags.Find(_T("download/game/format"));
        if (terpTag != 0)
        {
            for (i = 0 ; ; ++i)
            {
                // get this <interpreter> node
                xmlnode *inode;
                if ((inode = terpTag->GetChild(_T("interpreter"), i)) == 0)
                    break;

                // add the new terp entry
                info.terps.AddTail();
                dlterp &terp = info.terps.GetTail();
                
                // load the tags
                terp.name = inode->GetValue(_T("name"));
                terp.vsn = inode->GetValue(_T("version"));
                terp.regKey = inode->GetValue(_T("registry"));
                terp.runGame = inode->GetValue(_T("RunGame"));
                terp.runGameRestore = inode->GetValue(_T("RunGameRestore"));
                terp.dl.url = inode->GetValue(_T("href"));
                terp.dl.action = inode->GetValue(_T("action"));
                terp.dl.desc = terp.name;
                terp.dl.compr = inode->GetValue(_T("compression/id"));
                terp.dl.comprPri = inode->GetValue(
                    _T("compression/primaryfile"));
                terp.dl.comprName = inode->GetValue(_T("compression/name"));
                
                // apply the Archive mirror translation to the terp URL
                UrlToMirror(terp.dl.url, info);

                // get the legacyinstall sub-items
                xmlnode *lnode = inode->GetChild(_T("legacyinstall"), 0);
                if (lnode != 0)
                {
                    // get the executable information
                    terp.exename = lnode->GetValue(_T("exename"));
                    terp.exeMD5 = lnode->GetValue(_T("exeMD5"));

                    // load the filetypekey list
                    for (int j = 0 ; ; ++j)
                    {
                        // get the next filetypekey item
                        xmlnode *ftk = lnode->GetChild(_T("filetypekey"), j);
                        if (ftk == 0)
                            break;

                        // add it to the list
                        terp.filetypes.AddTail(ftk->val);
                    }
                }
            }
        }

        // presume we'll need to download an interpreter if there are any
        // in our list
        info.needTerp = (info.terps.GetCount() != 0);
        info.terpUpdate = false;
        info.terpVersionKnown = false;

        // flag that we haven't selected an interpreter yet
        info.selectedTerp = 0;

        // Check to see if we have any of these interpreters already
        // installed.  If so, we'll use the existing one rather than
        // installing a new one.
        int iTerp = 0;
        for (POSITION pos = info.terps.GetHeadPosition() ; pos != 0 ;
             info.terps.GetNext(pos), ++iTerp)
        {
            // try recognizing it
            if (RecognizeTerp(info, pos, newRunGameKey))
                break;
        }

        // if we haven't selected an interpreter, and we need one, choose
        // the first one in the list by default - the first terp in the
        // list from the server is the recommended one
        if (info.needTerp && info.selectedTerp == 0)
            info.selectedTerp = info.terps.GetHeadPosition();

        // validate compression for the selected interpreter
        if (info.needTerp
            && !ValidateCompression(
                info.terps.GetAt(info.selectedTerp).dl, TRUE))
            return E_FAIL;

        // Set up the game output directory.  Create this in
        // My Documents\IFDB Games\<title> (<tuid>).  To keep the
        // length reasonable, truncate title to an arbitrary length.

        // first get My Documents\IFDB Games
        TCHAR mydocs[MAX_PATH], mygames[MAX_PATH];
        SHGetSpecialFolderPath(0, mydocs, CSIDL_PERSONAL, TRUE);
        PathCombine(mygames, mydocs, "IFDB Games");

        // Figure the maximum length: Windows API limitations require
        // us to keep paths to MAX_PATH characters, so make sure we 
        // don't go over that limit; in any case, limit the title to 
        // an arbitrary maximum to keep it from getting too unwieldy.
        // Leave room for a little extra as well, in case we need
        // to add a numeric suffix for uniqueness.
        size_t maxlen = 36;
        size_t baselen = strlen(mygames);
        if (baselen + maxlen + 10 >= MAX_PATH)
        {
            if (baselen + 10 >= MAX_PATH)
                maxlen = 0;
            else
                maxlen = MAX_PATH - (baselen + maxlen + 10);
        }

        // truncate the title as needed
        TCHAR stitle[MAX_PATH];
        if (strlen(info.title) <= maxlen)
            safe_strcpy(stitle, sizeof(stitle), info.title);
        else
        {
            // it's too long - scan for the last non word character
            // before the cut-off point; if we can't find a word break,
            // just truncate at the cut-off point
            LPCTSTR p, sp;
            for (sp = p = (LPCTSTR)info.title + maxlen ;
                 p > info.title ; --p)
            {
                if (!(isalpha(*p) || isdigit(*p) || strchr("-'", *p) != 0))
                {
                    sp = p;
                    break;
                }
            }

            // copy up to the cut-off point
            memcpy(stitle, info.title, sp - info.title);
            stitle[sp - info.title] = '\0';
        }

        // make sure the title doesn't have any character that are invalid
        // in filenames
        fix_filename(stitle, FALSE);

        // build out the folder title: combine our short title with the
        // My Documents\IFDB Games parent folder
        TCHAR gamedir[MAX_PATH];
        PathCombine(gamedir, mygames, stitle);

        // Ensure uniqueness.  If we already have a folder with this
        // name, add a numeric suffix (2, 3, ...) until we have a
        // unique name.
        if (GetFileAttributes(gamedir) != INVALID_FILE_ATTRIBUTES)
        {
            // add suffixes until we get a unique name
            for (int i = 2 ; i < 1000 ; ++i)
            {
                CAtlString newdir;
                
                // build the name with the suffix
                newdir.Format("%s %d", gamedir, i);

                // if it's unique, take it
                if (GetFileAttributes(newdir) == INVALID_FILE_ATTRIBUTES)
                {
                    // save it and stop looking
                    safe_strcpy(gamedir, sizeof(gamedir), newdir);
                    break;
                }
            }
        }
        
        // figure the local game file based on the output path
        GetLocalFilePath(info.localGameFile, gamedir, info.game);

        // Check to see if the game is already installed.  We'll
        // consider it to be installed if we can find a directory
        // under IFDB Games containing our special marker file
        // AND the game file (i.e., the primary file from the download).
        CAtlString searchpat, markfile;
        searchpat.Format("%s\\*", mygames);
        markfile.Format("IFDB-%s.xml", info.tuid);
        WIN32_FIND_DATA finddata;
        HANDLE hfind = FindFirstFile(searchpat, &finddata);
        if (hfind != 0)
        {
            do
            {
                // if it's not a directory, or it's '.' or '..', skip it
                if ((finddata.dwFileAttributes
                     & FILE_ATTRIBUTE_DIRECTORY) == 0
                    || strcmp(finddata.cFileName, ".") == 0
                    || strcmp(finddata.cFileName, "..") == 0)
                    continue;

                // build this full directory path
                TCHAR curdir[MAX_PATH];
                PathCombine(curdir, mygames, finddata.cFileName);

                // get the name of the game file in this directory
                CAtlString lclgame;
                GetLocalFilePath(lclgame, curdir, info.game);

                // get the name of the marker file in this directory
                TCHAR lclmark[MAX_PATH];
                PathCombine(lclmark, curdir, markfile);

                // if the game file and marker file exist, this is it
                if (GetFileAttributes(lclgame) != INVALID_FILE_ATTRIBUTES
                    && GetFileAttributes(lclmark) != INVALID_FILE_ATTRIBUTES)
                {
                    // We found the game.  Look to see if there's version
                    // information in its marker file - if so, compare it
                    // to the version from the server.

                    // presume we won't want to update
                    bool updating = false;

                    // look for version information in the marker file
                    LPCTSTR vsn, ignoreVsn;
                    CAtlList<xmltag> mtags;
                    if (ParseXMLFile(mtags, lclmark))
                    {
                        vsn = GetPathValue(mtags, "/game/version", 0);
                        ignoreVsn = GetPathValue(
                            mtags, "/game/ignoreVersion", 0);
                    }

                    // If either the actual installed game version or the
                    // "ignore" version matches the current version, we
                    // don't need to update.  If neither matches, we do.
                    if ((vsn != 0 && info.gameVsn == vsn)
                        || (ignoreVsn != 0 && info.gameVsn == ignoreVsn))
                    {
                        // We have the right version, so there's no need
                        // to fetch the game.
                        info.needGame = FALSE;
                    }
                    else
                    {
                        // There's a newer version available.  Ask the user
                        // if they want the update.
                        CGameUpdateDlg gud;
                        int id = gud.DoModal(0, 0);

                        // flag that there's an update available
                        info.gameUpdate = TRUE;

                        // actually get the update only if they said Yes
                        updating = (id == IDYES);
                    }

                    // check to see if we're updating
                    if (updating)
                    {
                        // They want to fetch the update.  Keep all of
                        // the new-download information we set up before
                        // we knew we already had a copy - we'll just
                        // treat this as a brand new game, leaving the
                        // old copy intact in its current directory.
                        // The only extra work we need to do is to delete
                        // the old copy's marker file after we complete
                        // the new install - we do this so that the old
                        // copy won't show up as an active copy the next
                        // time we search for the TUID.  Don't actually
                        // delete it yet, in case the user cancels or
                        // the download fails; for now, just make a note
                        // of the file so that we can delete it later.
                        oldMarkerFile = lclmark;
                    }
                    else
                    {
                        // We either already have the current version,
                        // or the user isn't interested in updating.
                        // We don't need to download it.
                        info.installGame = FALSE;

                        // this is the actual location of the game
                        safe_strcpy(gamedir, sizeof(gamedir), curdir);
                        info.localGameFile = lclgame;
                    }

                    // we found the game, so no need to keep looking
                    break;
                }
            }
            while (FindNextFile(hfind, &finddata));

            // end the search
            FindClose(hfind);
        }

        // if a new interpreter or an update is needed, assume we'll want
        // to install it
        info.installTerp = info.needTerp;

        // if there's any download work, run the dialog
    run_main_dlg:
        if ((info.needGame && info.installGame) || info.needTerp)
        {
            // set up the updater object
            class MainDlgUpdater: public IIfdbUpdater
            {
            public:
                MainDlgUpdater(CIfdbInstallerModule *mod, const xmlnode &tags)
                    : mod(mod), tags(tags) { }
                CIfdbInstallerModule *mod;
                const xmlnode &tags;
                virtual bool CheckUpdate()
                {
                    // do an explicit update
                    return mod->NeedInstallerUpdate(tags, true);
                }
            };

            // run the dialog
            MainDlgUpdater updater(this, tags);
            MainDlgCtx dctx(&info, &updater);
            int id = d.DoModal(0, (LPARAM)&dctx);
            
            // if they canceled, terminate
            if (id != IDOK)
                return S_OK;
        }

        // if we need a terp, and the user said they already have one,
        // ask them where it is
        if (info.needTerp && !info.terpUpdate && !info.installTerp)
        {
            // run the find-player dialog
            CPlayerDlg pdlg;
            int id = pdlg.DoModal(0, (LPARAM)&info);

            // if they said 'back', go back to the main dialog
            if (id == IDC_BTN_BACK)
                goto run_main_dlg;

            // if they canceled, terminate
            if (id != IDOK)
                return S_OK;
        }

        // Get the selected interpreter, if any.  If there isn't a selection,
        // and we do need an interpreter, select the first by default.
        dlterp *selTerp = 0;
        if (info.selectedTerp != 0)
            selTerp = &info.terps.GetAt(info.selectedTerp);
        else if (info.needTerp)
            selTerp = &info.terps.GetHead();

        // set up the list of files to download
        CAtlList<dlitem> files;

        // if we need to download the game, add it to the list
        if (info.needGame && info.installGame)
            AddDlItem(files, info.game, gamedir);

        // check to see if we're installing an interpreter
        POSITION terpItemPos = 0;
        if (info.needTerp && info.installTerp)
        {
            LPCTSTR terpdir = 0;
            
            // If the action is "save", this isn't an installer - we'll
            // just download the actual interpreter program.  In this
            // case, we need an actual destination folder, not a temporary
            // folder.  Generate this as <Program Files>\IFDB\<terp name>.
            if (selTerp->dl.action == "save")
            {
                TCHAR terpname[64];
                
                // set up <program files>\IFDB
                CAtlString dir;
                GetProgramFilesDir(dir);

                // build a safe version of the terp name
                safe_strcpy(terpname, sizeof(terpname), selTerp->name);
                fix_filename(terpname, FALSE);

                // build out the full path: ...\ifdb\<terp name>
                dir += "\\ifdb\\";
                dir += terpname;

                // use this folder as the download destination
                terpdir = dir;
            }
            
            // add the interpreter to the list
            terpItemPos = AddDlItem(files, selTerp->dl, terpdir);

            // remind them to close any running interpreter instances
            if (info.terpUpdate)
            {
                CAtlString msg;
                msg.Format(
                    _T("Please make sure that any %s Player windows are ")
                    _T("closed, so that the installer for %s can update ")
                    _T("your Player."),
                    info.fmtName, selTerp->name);

                if (MessageBox(0, msg, msgbox_title,
                               MB_OKCANCEL | MB_ICONINFORMATION) == IDCANCEL)
                    return S_OK;
            }
        }

        // if there's any downloading work, run the main download request
        if (files.GetCount() != 0)
        {
            // run the dialog
            MainDownloadRequest mreq(&files);
            if (!DoNetworkRequest(0, mreq))
                return E_FAIL;
        }

        // if we installed a game, generate the marker file
        if (info.needGame)
        {
            CAtlString xml;
            
            // get the marker file name for the installed game
            TCHAR markpath[MAX_PATH];
            PathCombine(markpath, gamedir, markfile);

            // If we installed a brand new game, generate a brand new
            // marker file.
            //
            // If we installed an updated game, generate a brand new
            // marker file, and delete the old version's marker file -
            // deleting the old marker file will effective inactivate
            // the old copy, since we use the presence of the marker
            // file to find the active version.
            //
            // If we DECLINED an update, keep the existing marker
            // file, but add an <ignoreVersion> tag so that we know not
            // to prompt the user about it again until an even newer
            // version becomes available.
            if (!info.installGame)
            {
                xmlnode root;
#define GAME_NAMESPACE "http://ifdb.tads.org/metainstaller/windows/game"
                
                // We didn't install it, which means that we declined an
                // update.  (There's no way to get here if we declined
                // installing a brand new game - that simply cancels
                // the whole process long before we get here.)  In this
                // case, we want to keep the existing marker file, but
                // update its /game/ignoreVersion element so that we
                // know not to prompt again about it until an even newer
                // version becomes available.

                // read the current marker file
                if (ParseXMLFile(root, markpath))
                {
                    xmlnode *iv;
                    
                    // find the existing ignoreVersion tag; if it's not
                    // there, add a new one
                    if ((iv = root.Find("game/ignoreVersion")) != 0
                        || (iv = root.Add("game", "ignoreVersion")) != 0)
                    {
                        // set the value
                        iv->val = info.gameVsn;

                        // flatten the XML into text
                        root.ToString(xml, GAME_NAMESPACE);
                    }
                }
            }

            // if we haven't generated other XML yet, generate a brand
            // new XML file
            if (xml == "")
            {
                xml = "<?xml version=\"1.0\"?>\r\n"
                      "<game xmlns=\"" GAME_NAMESPACE "\">\r\n";
                
                AddXmlEle(xml, "tuid", info.tuid, "  ");
                AddXmlEle(xml, "title", info.title, "  ");
                AddXmlEle(xml, "author", info.author, "  ");
                AddXmlEle(xml, "version", info.gameVsn, "  ");
                xml += "</game>\r\n";
            }

            // write the marker file
            HANDLE hf = CreateFile(
                markpath, GENERIC_WRITE, 0, 0, CREATE_ALWAYS,
                FILE_ATTRIBUTE_HIDDEN, 0);
            if (hf != INVALID_HANDLE_VALUE)
            {
                // write it
                DWORD actual;
                WriteFile(hf, xml, xml.GetLength(), &actual, 0);
                
                // done with the file
                CloseHandle(hf);
            }

            // if we had an old marker file from a previous version,
            // delete it - this will effectively inactivate the old
            // version and make the new version active, since we only
            // find installed games via the presence of the marker file
            if (oldMarkerFile != "")
                DeleteFile(oldMarkerFile);
        }

        // If we installed an interpreter, and the interpreter install
        // action is "save", it means that the terp download had no
        // installer of its own; in this case, we need to manually set
        // the IFDB registry keys so that we'll remember the interpreter
        // being installed.  We don't need to do this if the download
        // came with an installer (indicated by a "run" action), since
        // in this case we require the installer to set the keys.  (And
        // we couldn't set them in this case if we wanted to, since the
        // keys are the only way we know where the installer ended up
        // putting the interpreter program file.)
        if (info.needTerp && info.installTerp && selTerp->dl.action == "save")
        {
            // update the keys - the executable file is the primary
            // file from the terp download
            WriteTerpKeys(selTerp, files.GetAt(terpItemPos).localPrimary,
                          WTK_VERSION | WTK_RUNGAME);
        }

        // If we installed an interpreter, check to see if we can
        // recognize it after the installation.  Older interpreters
        // don't always set the keys we need.  Failing to recognize it
        // isn't fatal, but if we recognize it based on its file-type
        // associations, then we can at least make a record of that
        // to make it easier for us to find next time.
        if (info.needTerp && info.installTerp)
            RecognizeTerp(info, info.selectedTerp, newRunGameKey);

        // If we *wanted* to install an interpreter (new or updated),
        // but we didn't, it means that the user elected to keep an
        // existing interpreter.
        if (info.needTerp && !info.installTerp)
        {
            // Okay, the user chose to keep an existing interpreter
            // rather than install a new/updated one.  There are two
            // possibilities for what's going on:
            //
            //  - We found an existing interpreter, and an update was
            //    available.  The user elected not to update.  In this
            //    case, we want to set the "ignore version" for the
            //    interpreter so that we won't prompt again until an
            //    even newer update is available.
            //
            //  - We couldn't find an existing interpreter at all.  This
            //    means that the user has a version that pre-dates the
            //    new registry keys, so we can't recognize it even though
            //    it's installed.  In this case, we require the user to
            //    point out manually where the interpreter's .exe file is.
            //    This lets us write out the recognition keys as though we
            //    had a conforming version, so that on future game downloads
            //    for the same format, we'll know that we already have this
            //    terp installed.
            if (info.terpUpdate)
            {
                // We're keeping an old version even though an update is
                // available: update the "ignore version" entry in the
                // registry so that we'll know not to bother the user 
                // again until an even newer version is available.  Don't
                // update any of the other keys, since this interpreter
                // already has the proper recognition codes installed:
                // updating the keys could actually be harmful, since the
                // command line syntax could be different for the newer
                // version.
                WriteTerpKeys(selTerp, 0, WTK_IGNOREVERSION);
            }
            else
            {
                // We have a pre-spec version installed, and the user has
                // manually told us where it's located.  In this case, we
                // need to write the full set of keys so that we'll be able
                // to recognize this interpreter on future runs.  The
                // executable path in this case is what the user manually
                // entered via the dialog.  Note that we update the
                // "ignore" version rather than the installed version,
                // since we can't actually tell what version is installed.
                // Setting the "ignore" version will at least let us
                // skip future prompts until an even newer version is
                // available.
                WriteTerpKeys(selTerp, info.terpExe,
                              WTK_IGNOREVERSION | WTK_RUNGAME);
            }
        }

        // If we kept or installed a pre-IFDB interpreter version 
        // (that is, a version that doesn't have the special new
        // IFDB registry keys), AND we recognized it based on
        // its HKCR\filetype\shell\open\command key, explicitly
        // copy the shell\open\command value into our RunGame
        // key.  This will ensure that we find the interpreter
        // on subsequent runs, and that we know how to invoke it.
        if (newRunGameKey != "")
        {
            // synthesize a terp struct with the new RunGame
            // key, and write it out
            dlterp t;
            t.regKey = selTerp->regKey;
            t.runGame = newRunGameKey;
            WriteTerpKeys(&t, info.terpExe, WTK_RUNGAME);
        }

        // we should be fully installed, so launch the game - set up
        // a shell-execute spec
        SHELLEXECUTEINFO sx;
        CAtlString cmd, tok;
        memset(&sx, 0, sizeof(sx));
        sx.fMask = SEE_MASK_FLAG_DDEWAIT;
        sx.cbSize = sizeof(sx);
        sx.lpVerb = "open";
        sx.nShow = SW_SHOWNORMAL;

        // use the game's folder as the working directory
        TCHAR pwd[MAX_PATH];
        safe_strcpy(pwd, sizeof(pwd), info.localGameFile);
        PathRemoveFileSpec(pwd);
        sx.lpDirectory = pwd;

        // IF we downloaded the game, open its folder.  We do this
        // mainly to let the user know where the game landed - since
        // we mkae up the location on our own, the user wouldn't
        // otherwise have an easy way of finding out where we put it.
        // Don't bother with this if we didn't download the game, though;
        // we used to do this, and users reported that it was a nuisance
        // to have the folder keep popping open.
        if (info.needGame)
        {
            sx.lpFile = gamedir;
            sx.lpParameters = 0;
            ShellExecuteEx(&sx);
        }

        // launch the game - if the game was downloaded as a story file,
        // open it with the interpreter program; if the game is an
        // executable, run it
        if (gametype != 0 && strcmp(gametype, "storyfile") == 0)
        {
            // For a "storyfile" download, we need to invoke the interpreter
            // on the game file.  To determine how to run the interpreter,
            // look up the intepreter's special RunGame registry key.
            terpKeys keys;
            dlterp &terp = info.terps.GetAt(info.selectedTerp);
            GetTerpKeys(terp, keys);

            // get the RunGame key; if it's not defined in the registry,
            // use the value from the XML, *if* we know where the
            // interpreter program is (if we don't, the XML key is
            // useless, since it necessarily depends on the interpreter
            // executable path)
            LPCTSTR runGame = (keys.runGame != "" ? (LPCTSTR)keys.runGame :
                               info.terpExe != "" ? (LPCTSTR)terp.runGame :
                               0);

            if (runGame != 0)
            {
                LPCTSTR params[2];

                // The interpreter has an explicit RunGame setting, so
                // execute the command line given there.  In the command
                // line template, "%0" stands for the interpreter executable
                // file path, if known; "%1" stands for the game file.
                params[0] = (info.terpExe != "" ? (LPCTSTR)info.terpExe : 0);
                params[1] = info.localGameFile;
                ExpandParams(cmd, runGame, 2, params);

                // Okay, we have the expanded command line.  The first token
                // is the name of the program, and the rest is the parameter
                // string.
                LPCTSTR p = cmd;
                NextToken(tok, p);
                sx.lpFile = tok;
                sx.lpParameters = p;
            }
            else
            {
                // the interpreter didn't set the RunGame key, so try
                // launching the game file itself - this will work as
                // long as the interpreter created a standard Windows
                // file type association for the game file's extension
                sx.lpFile = info.localGameFile;
            }
        }
        else if (gametype != 0 && strcmp(gametype, "storyprogram") == 0)
        {
            // for a "storyprogram" download, we simply execute the game
            sx.lpFile = info.localGameFile;
        }

        // launch the game
        if (!ShellExecuteEx(&sx) || (DWORD_PTR)sx.hInstApp <= 32)
        {
            MessageBox(0, _T("An error occurred starting the game. You ")
                       _T("might try running the game manually to see ")
                       _T("if there's an installation problem."),
                       msgbox_title, MB_OK | MB_ICONERROR);
            return E_FAIL;
        }

        // done
        return S_OK;
    }

    // Check to see if a given terp is installed.
    bool RecognizeTerp(dlinfo &info, POSITION pos, CAtlString &newRunGameKey)
    {
        // get this interpreter entry
        dlterp &t = info.terps.GetAt(pos);

        // presume we won't find a match on this round
        bool terpOK = false, vsnOK = false;

        // look up this interpreter's registry keys
        terpKeys keys;
        if (GetTerpKeys(t, keys))
        {
            // make sure that the interpreter program actually
            // exists - it might have been deleted or moved, in
            // which case we'll need to download it again (or at
            // least get the user to repair it)
            CAtlString runProg;
            LPCTSTR runCmdPtr = keys.runGame;
            if (NextToken(runProg, runCmdPtr)
                && ::GetFileAttributes(runProg) != INVALID_FILE_ATTRIBUTES)
            {
                // the interpreter file exists as advertised
                terpOK = true;
            }
            
            // Check to see if our installed version is up to date.
            // Consider it up to date if the actual installed version
            // is equal to or higher than the download version, OR
            // the "ignore version" is equal or higher.  The "ignore
            // version" is the last available version that the user
            // explicitly declined to download - we remember that
            // version so that we don't prompt again until an even
            // newer version becomes available.
            if (CompareVersions(keys.vsn, t.vsn) >= 0
                || CompareVersions(keys.ignoreVsn, t.vsn) >= 0)
            {
                // our version number is at least as high as the
                // available download's version - we have the
                // latest
                vsnOK = true;
            }

            // If we don't have any stored version information, but
            // we do have an MD5 for the interpreter .EXE, use that as
            // the basis for versioning.
            if (keys.vsn == "" && keys.ignoreVsn == ""
                && runProg != "" && t.exeMD5 != ""
                && MatchFileMD5(runProg, t.exeMD5))
            {
                // we have an MD5 match for the executable, so it's up to date
                vsnOK = true;
            }
            
            // if our installation is valid and up to date, we don't
            // need to install again
            if (terpOK && vsnOK)
            {
                // note that we don't need to install a terp
                info.needTerp = false;
                info.terpVersionKnown = true;
                
                // remember which interpreter to use to run the game
                info.selectedTerp = pos;
                
                // tell the caller we found an installed interpreter
                return true;
            }
            
            // if we have this interpreter installed, but it's
            // not up to date, make it the one to use, but offer
            // to fetch the update
            if (terpOK)
            {
                // make this the one to use
                info.selectedTerp = pos;
                
                // flag that this is an update rather than a new install
                info.terpUpdate = true;
                info.terpVersionKnown = true;
                
                // tell the caller we found one
                return true;
            }
        }
        
        // If we get this far, it means we didn't match the interpreter
        // on the special IFDB registry keys.  However, we might have
        // an older version installed that sets type association keys.
        // Check for that.
        for (POSITION fpos = t.filetypes.GetHeadPosition() ; fpos != 0 ;
             t.filetypes.GetNext(fpos))
        {
            // look up HKCR\filetype\shell\open\command
            CRegKey k;
            CAtlString keyPath;
            keyPath.Format("%s\\shell\\open\\command",
                           t.filetypes.GetAt(fpos));
            if (k.Open(HKEY_CLASSES_ROOT, keyPath, KEY_READ)
                == ERROR_SUCCESS)
            {
                // Get the default value.  Parse the first token using
                // the special Windows shell algorithm - this gives us
                // the program name.  Verify that the file exists.  If
                // all of this works, we can conclude that this
                // interpreter is installed.
                ULONG len;
                TCHAR buf[4096], *bufp = buf;
                len = sizeof(buf);
                CAtlString tok;
                if (k.QueryStringValue(_T(""), buf, &len) == ERROR_SUCCESS
                    && ParseSpecialShellToken(tok, bufp)
                    && stricmp(PathFindFileName(tok), t.exename) == 0
                    && GetFileAttributes(tok) != INVALID_FILE_ATTRIBUTES)
                {
                    // We have a winner.  Mark this as the selected
                    // interpreter - BUT mark it as possibly in need
                    // of updating, since we can't detect the version
                    // using this recognition method.
                    terpOK = true;
                    info.selectedTerp = pos;

                    // If we have an MD5 key, compute the MD5 of the
                    // interpreter executable we found and compare it
                    // to the one in the XML.  If they match, we have
                    // the current version.
                    if (MatchFileMD5(tok, t.exeMD5))
                    {
                        // we don't need to install or update a terp
                        info.needTerp = false;
                        info.terpUpdate = false;
                        info.terpVersionKnown = true;
                    }
                    else
                    {
                        // no match - we need an update
                        info.terpUpdate = true;
                        
                        // if there's no MD5, we don't actually know
                        // for sure one way or the other
                        if (t.exeMD5 == "")
                            info.terpVersionKnown = false;
                    }

                    // Set our RunGame key based on the shell\open\command
                    // value - that uses the same syntax as our RunGame,
                    // and it's set to what this version wants, so save
                    // it for our own use on the next run.  Don't do
                    // this yet, though - wait to see if they decide
                    // to keep the current version.  Just flag it for
                    // now.
                    // 
                    // Note that we have to rebuild the key somewhat: we
                    // must ensure that the first token is actually enclosed
                    // in quotes.  The Windows shell is tolerant of missing
                    // quotes in the shell\open\command string, but the
                    // ShellExecuteEx() API is not.  So rebuild the string
                    // by putting the first token in quotes, and then
                    // adding the rest of the command line.
                    newRunGameKey.Format("\"%s\" %s", tok, bufp);
                    
                    // remember our executable path
                    info.terpExe = tok;
                }
                
                // done with the key
                k.Close();
            }
            
            // if we found it on this round, we can stop looking
            if (terpOK)
                return true;
        }

        // if this interpreter doesn't appear to be installed, delete
        // any left-over keys - it might have been manually uninstalled
        // since last time we looked, in which case we don't want the
        // old keys hanging around in case the user re-installs it in
        // a different location or installs a new version that has
        // different program file names
        if (!terpOK)
            DeleteTerpKeys(t);

        // indicate whether we found an interpreter
        return terpOK;
    }

    // Translate an IF Archive URL to the selected mirror, if applicable.
    void UrlToMirror(CAtlString &url, const dlinfo &info)
    {
        // if the URL or mirror are missing, there's nothing to do
        if (url == "" || info.archiveMirror == "")
            return;

        // if the URL starts with the IF Archive prefix, translate it
        LPCTSTR prefix = _T("http://www.ifarchive.org/if-archive/");
        size_t prelen = _tcslen(prefix);
        if (_tcslen(url) > prelen
            && memcmp((LPCTSTR)url, prefix, prelen*sizeof(TCHAR)) == 0)
        {
            // it's a match - replace the prefix with the mirror prefix
            url = info.archiveMirror + ((LPCTSTR)url + prelen);
        }
    }


    // Compute a file's MD5 hash value, and compare it to the given
    // MD5, given in canonical printable notation.  Returns true if
    // we match, false if not.
    bool MatchFileMD5(LPCTSTR fname, LPCTSTR md5)
    {
        md5_state_t st;
        md5_byte_t in_digest[16], file_digest[16];
        int i;
        LPCTSTR p;
        
        // if there's no MD5, we can't match
        if (md5 == 0 || md5[0] == '\0')
            return false;

        // parse the input digest into binary format
        int acc;
        bool even;
        for (i = 0, even = true, p = md5 ; i < 32 && *p != 0 ; ++p)
        {
            TCHAR c = *p;
            int b = (c >= '0' && c <= '9' ? c - '0' :
                     c >= 'A' && c <= 'F' ? c - 'A' + 10 :
                     c >= 'a' && c <= 'f' ? c - 'a' + 10 :
                     0);

            if (even)
                acc = b << 4;
            else
                in_digest[i++] = acc + b;

            even = !even;
        }

        // initialize the MD5 calculator
        md5_init(&st);

        // open the file - if that fails, we can't compute the hash
        HANDLE hf = CreateFile(fname, GENERIC_READ, 0, 0, OPEN_ALWAYS, 0, 0);
        if (hf == INVALID_HANDLE_VALUE)
            return false;

        // read the file
        for (;;)
        {
            // read a buffer-full
            md5_byte_t buf[32*1024];
            DWORD actual;
            if (!ReadFile(hf, buf, sizeof(buf), &actual, 0))
                return false;

            // if we read nothing, we're at EOF
            if (actual == 0)
                break;

            // add this buffer to the hash
            md5_append(&st, buf, actual);
        }

        // done with the file
        CloseHandle(hf);

        // finish the computation and calculate the digest
        md5_finish(&st, file_digest);

        // compare the hashes - return true if they match
        return memcmp(in_digest, file_digest, sizeof(file_digest)) == 0;
    }


    // Do we need to update the installer?  We'll check file versions against
    // the server's current available version; if there's a newer version
    // available, we'll prompt the user for permission to update, and start
    // the process if they say yes.  We'll return 'true' if the main program
    // should abort due to the need for an update, 'false' if we should
    // proceed as normal with the current game download.
    bool NeedInstallerUpdate(const xmlnode &tags, bool isExplicit)
    {
        // if auto-update is disabled, and this isn't an explicit
        // user-initiated update, don't even check
        if (!isExplicit && !AutoUpdatesEnabled())
            return false;
        
        // Check the browser plug-in and the main installer program to
        // see if new versions are available.  We'll check both the
        // ActiveX and Mozilla-style plug-ins, and trigger an update
        // for whichever is/are present.
        if (NeedFileUpdate(tags, "IfdbPlugIn.ocx")
            || NeedFileUpdate(tags, "npIfdbMeta.dll")
            || NeedFileUpdate(tags, "IfdbInstaller.exe"))
        {
            int id;
            
            // ask the user if they want to update
            if (isExplicit)
            {
                // explicit update - the user specifically told us to check
                // for updates, so it's a little silly to offer the "don't
                // check again" option; just offer a simple yes/no
                id = MessageBox(
                    0, _T("An update is available for the IFDB installer. ")
                    _T("Do you want to install this update now?"),
                    msgbox_title, MB_YESNO | MB_ICONQUESTION);
            }
            else
            {
                // automatic update - run the full options dialog
                CUpdateDlg udlg;
                id = udlg.DoModal(0, 0);
            }

            // apply the user's selection
            switch (id)
            {
            case IDCANCEL:
                // canceling - simply tell the caller to terminate
                return true;

            case IDYES:
                // kick off the update
                StartInstallerUpdate();

                // tell the caller to terminate so that the update can
                // replace the installer's program files
                return true;

            case IDNO:
                // skip the update, but check again next time - just tell
                // the caller to continue as though no update were needed
                return false;

            case IDC_RB_NEVER:
                // They want to turn off auto-updates.  Set the registry
                // key to indicate this.
                EnableAutoUpdates(false);

                // we're not updating; proceed with the game install
                return false;
            }
        }

        // it looks like we're up to date, so tell the caller that no
        // update is needed
        return false;
    }

    // Start an installer update.  The installer update process consists of
    // downloading a ZIP file from a hard-coded URL on the IFDB server,
    // unzipping the result into a temporary directory, and running the
    // updater program from that download.  So it's basically like an
    // interpreter install, and we can use almost the same process to
    // carry it out.  The only difference is that in this case we don't
    // want to wait for the spawned updater program to finish, since we
    // need to terminate before it can overwrite our program file.
    void StartInstallerUpdate()
    {
        CAtlList<dlitem> files;
        dlfile item;
        TCHAR progDir[MAX_PATH];
        CAtlString params;

        // Get the directory containing the installer.  We need to pass
        // this information to the updater program on its command line,
        // since that's how it finds out where the programs it's updating
        // reside.
        GetModuleFileName(
            _AtlBaseModule.GetModuleInstance(), progDir, MAX_PATH);
        PathRemoveFileSpec(progDir);

        // build the full command parameters
        params.Format(" -dir \"%s\" -rerun -id %s %s%s",
                      progDir, id,
                      (mirrorID != "" ? "-mirror " : ""), mirrorID);

        // set up a description of the updater download; run the installer
        // in "detached" mode, since we can't sit around and wait for it
        // to finish - we need to terminate to let it do its work
        item.url = "http://ifdb.tads.org/plugins/windows-updater.zip";
        item.compr = "zip";
        item.comprName = "ZIP";
        item.comprPri = "IfdbUpdater.exe";
        item.action = "run";
        item.runDetached = true;
        item.runParams = params;
        item.runErrMsg = "An error occurred starting the Installer Update "
                         "program. You might want to try again, by "
                         "starting over with the download process for "
                         "the same game. If the problem persists, you can "
                         "bypass the update by selecting \"Skip the Update\" "
                         "when prompted. See the IFDB \"Contact\" page if "
                         "you want to report the problem.";
                         
        item.desc = "IFDB Installer Update";
        AddDlItem(files, item, 0);

        // download it and kick off the updater program
        MainDownloadRequest mreq(&files);
        DoNetworkRequest(0, mreq);
    }

    // check an individual installer program file to see if it need updating
    bool NeedFileUpdate(const xmlnode &tags, LPCTSTR fname)
    {
        // get the clientversions/windows-plugin group node
        const xmlnode *pnode = tags.Find("clientversions/windows-plugin");
        if (pnode == 0)
            return false;

        // scan the <file> elements for a match to the requested name
        for (int i = 0 ; ; ++i)
        {
            // get the i'th <file> element - if it's not there, we have no
            // version info for this file, so we must not need an update
            const xmlnode *fnode = pnode->GetChild("file", i);
            if (fnode == 0)
                return false;

            // check for a name match
            LPCTSTR curfname = fnode->GetValue("name");
            LPCTSTR curvsn = fnode->GetValue("version");
            if (curfname != 0 && curvsn != 0 && stricmp(fname, curfname) == 0)
            {
                int j;
                int diff;
                int serverVsn[4], clientVsn[4];
                
                // this is our file - parse the version into four ints
                for (j = 0 ; j < 4 ; ++j)
                    serverVsn[j] = ParseVsnPart(curvsn);

                // get the version information from the actual local copy
                // of the file - if the file doesn't exist locally, it must
                // not be part of our install set (it must be part of one
                // of the other plug-in types), so ignore it
                if (GetFileVersion(fname, clientVsn))
                {
                    // compare the versions
                    for (j = 0, diff = 0 ; j < 4 && diff == 0 ; ++j)
                        diff = serverVsn[j] - clientVsn[j];

                    // if the server version is newer, we need an update
                    if (diff > 0)
                        return true;
                }

                // we found this file, and it's up to date
                return false;
            }
        }
    }

    // parse a part of a version number string
    int ParseVsnPart(LPCTSTR &p)
    {
        // parse the integer at p
        DWORD ret = atoi(p);

        // move ahead to just after the next '.'
        LPCTSTR dot = strchr(p, '.');
        p = (dot != 0 ? dot + 1 : p + strlen(p));
        
        // return the result
        return ret;
    }

    // Get the embedded version information from the given file.  Returns
    // true if successful, false if the file isn't found or we can't retrieve
    // the version information.  The version is represented as four ints,
    // ordered from most significant to least significant.
    bool GetFileVersion(LPCTSTR fname, int vsn[4])
    {
        DWORD len;
        char *buf;
        DWORD hdl;
        bool ret;
        VS_FIXEDFILEINFO *info;
        UINT infoLen;

        // get the version info size and allocate space
        if ((len = GetFileVersionInfoSize(fname, &hdl)) == 0
            || (buf = new char[len]) == 0)
            return false;

        // retrieve the version information
        ret = (GetFileVersionInfo(fname, hdl, len, buf) != 0
               && VerQueryValue(buf, "\\", (LPVOID *)&info, &infoLen) != 0);

        // if we got the information, decode it
        if (ret)
        {
            vsn[0] = HIWORD(info->dwFileVersionMS);
            vsn[1] = LOWORD(info->dwFileVersionMS);
            vsn[2] = HIWORD(info->dwFileVersionLS);
            vsn[3] = LOWORD(info->dwFileVersionLS);
        }

        // clean up and return our result
        delete [] buf;
        return ret;
    }

    // add a download item
    POSITION AddDlItem(CAtlList<dlitem> &files, dlfile &f, LPCTSTR localDir)
    {
        // add a new item
        POSITION pos = files.AddTail();

        // get the item
        dlitem &dl = files.GetAt(pos);

        // set up the item
        dl.init(f, localDir);

        // return the new item's position
        return pos;
    }

    // get the Program Files directory (unfortunately, the much cleaner
    // CSIDL approach isn't implemented in older Windows versions, so we
    // use this approach for greater compatibility)
    void GetProgramFilesDir(CAtlString result)
    {
        HKEY hkey;
        DWORD typ;
        DWORD siz;
        char val[MAX_PATH];
        char expbuf[MAX_PATH];

        // as a last resort in case we can't read the registry key
        result = "C:\\Program Files";

        // open the system key containing the program files directory
        if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                         "SOFTWARE\\Microsoft\\Windows\\CurrentVersion",
                         0, KEY_QUERY_VALUE, &hkey) != ERROR_SUCCESS)
            return;
        
        // query the value
        siz = sizeof(val);
        if (RegQueryValueEx(hkey, "ProgramFilesDir", 0, &typ, (LPBYTE)val, &siz)
            == ERROR_SUCCESS)
        {
            // got it - check the type
            switch(typ)
            {
            case REG_SZ:
                // it's a simple null-terminated string result - copy it
                result = val;
                break;

            case REG_EXPAND_SZ:
                // it's an expansion string - expand it and copy the result
                ExpandEnvironmentStrings(val, expbuf, MAX_PATH);
                result = expbuf;
                break;
            }
        }
        
        // close the key
        RegCloseKey(hkey);
    }


    // perform "%n" parameter substitutions on a string
    void ExpandParams(CAtlString &dst, LPCTSTR src,
                      int paramCount, LPCTSTR *params)
    {
        LPCTSTR p, start;
        CAtlString buf;

        // run through the string looking for parameters to substitute
        for (buf = "", p = start = src ; *p != '\0' ; ++p)
        {
            // check for '%' sequences
            if (*p == '%')
            {
                LPCTSTR val = 0;
                
                // check for %n variables
                if (isdigit(*(p+1)))
                {
                    // get the variable number
                    int n = *(p+1) - '0';

                    // if the variable is in range, and it's defined,
                    // make the substitution
                    if (n < paramCount && params[n] != 0)
                        val = params[n];
                }
                else if (*(p+1) == '%')
                {
                    // it's '%%' - substitute '%'
                    val = "%";
                }

                // if we have a value make the substitution
                if (val != 0)
                {
                    // add the segment up to the %
                    if (p != start)
                        buf += CAtlString(start, p - start);

                    // skip the '%'
                    ++p;

                    // add the substitution value
                    buf += val;

                    // the next chunk starts after the sequence
                    start = p + 1;
                }
            }
        }

        // add the last chunk
        if (p != start)
            buf += CAtlString(start, p - start);

        // return the result buffer
        dst = buf;
    }

    // open the interpreter registry key
    bool OpenTerpKey(const dlterp &terp, CRegKey &k, REGSAM access)
    {
        // build this interpreter's registry key path
        CAtlString keyPath = _T("Software\\IFDB.tads.org\\")
                             _T("MetaInstaller\\Interpreters\\");
        keyPath += terp.regKey;

        // for read-only access, try HKLM first, since the terp might be
        // installed for all users; fall back on HKCU if we don't find that
        if ((access & KEY_WRITE) == 0
            && k.Open(HKEY_LOCAL_MACHINE, keyPath, access) == ERROR_SUCCESS)
            return true;

        // we either didn't find it in HKLM or didn't try; try HKCU
        if (k.Open(HKEY_CURRENT_USER, keyPath, access) == ERROR_SUCCESS)
            return true;

        // didn't find it - if write access was desired, try creating the key
        // (always create in HKCU)
        if ((access & KEY_WRITE) != 0
            && k.Create(HKEY_CURRENT_USER, keyPath, REG_NONE,
                        REG_OPTION_NON_VOLATILE, access, 0, 0))
            return true;

        // can't open or create the key
        return false;
    }

    // Delete the interpreter keys for a given interpreter.
    bool DeleteTerpKeys(const dlterp &terp)
    {
        // presume failure
        bool ok = false;
        
        // if there's no terp key, ignore this
        if (terp.regKey == "")
            return false;

        // open the parent key
        CRegKey k;
        CAtlString keyPath = _T("Software\\IFDB.tads.org\\")
                             _T("MetaInstaller\\Interpreters\\");
        if (k.Open(HKEY_CURRENT_USER, keyPath, KEY_READ | KEY_WRITE)
            == ERROR_SUCCESS)
        {
            // delete the terp-specific subkey
            ok = (k.DeleteSubKey(terp.regKey) == ERROR_SUCCESS);

            // close the parent key
            k.Close();
        }

        // return the status
        return ok;
    }

    // Get the interpreter registry key values for a given interpreter
    // definition.
    bool GetTerpKeys(const dlterp &terp, terpKeys &keys)
    {
        // clear out the keys
        keys.vsn = "";
        keys.ignoreVsn = "";
        keys.runGame = "";
        keys.runGameRestore = "";

        // look up this interpreter's IFDB keys in the registry
        CRegKey k;
        if (OpenTerpKey(terp, k, KEY_READ))
        {
            ULONG len;
            TCHAR buf[4096];

            // get the version key
            len = sizeof(buf);
            if (k.QueryStringValue(_T("Version"), buf, &len) == ERROR_SUCCESS)
                keys.vsn = buf;

            // get the "ignore version" key
            len = sizeof(buf);
            if (k.QueryStringValue(_T("IgnoreVersion"), buf, &len)
                == ERROR_SUCCESS)
                keys.ignoreVsn = buf;

            // get the RunGame key
            len = sizeof(buf);
            if (k.QueryStringValue(_T("RunGame"), buf, &len) == ERROR_SUCCESS)
                keys.runGame = buf;

            // get the RunGameRestore key
            len = sizeof(buf);
            if (k.QueryStringValue(_T("RunGameRestore"), buf, &len)
                == ERROR_SUCCESS)
                keys.runGameRestore = buf;
            
            // done with the key
            k.Close();

            // success
            return true;
        }
        else
        {
            // couldn't find the key
            return false;
        }
    }

    // Write the interpreter keys for the given interpreter.  'exepath' is
    // the full file path of the interpreter executable, if known.  'keys'
    // is a combination of WTK_xxx flags specifying which keys are to be
    // written.
    bool WriteTerpKeys(const dlterp *terp, LPCTSTR exepath, DWORD keys)
    {
        // open the intepreter registry key for the interpreter
        CRegKey k;
        if (OpenTerpKey(*terp, k, KEY_READ | KEY_WRITE))
        {
            // write the selected values
            if ((keys & WTK_VERSION) != 0)
                k.SetStringValue(_T("Version"), terp->vsn);

            if ((keys & WTK_IGNOREVERSION) != 0)
                k.SetStringValue(_T("IgnoreVersion"), terp->vsn);

            if ((keys & WTK_RUNGAME) != 0)
            {
                CAtlString runGame, runGameRestore;

                // If we have an interpreter executable path, expand the
                // "%0" parameter in the RunGame and RunGameRestore keys -
                // this parameter maps to the interpreter executable in
                // these keys.  *Only* expand %0 - leave the other parameters
                // intact as parameters, since we'll need to substitute them
                // each time the key is actually used to run a game.
                if (exepath)
                {
                    ExpandParams(runGame, terp->runGame, 1, &exepath);
                    ExpandParams(runGameRestore, terp->runGameRestore,
                                 1, &exepath);
                }
                else
                {
                    // there's no interpreter path, so we can't expand these
                    runGame = terp->runGame;
                    runGameRestore = terp->runGameRestore;
                }

                // write RunGame
                k.SetStringValue(_T("RunGame"), runGame);

                // write RunGameRestore, if it's defined
                if (runGameRestore != "")
                    k.SetStringValue(_T("RunGameRestore"), runGameRestore);
            }

            // done with the key
            k.Close();

            // success
            return true;
        }
        else
        {
            // failed to open the key
            return false;
        }
    }
    
    // validate that a compression format is one that we can handle
    int ValidateCompression(dlfile &f, int complain)
    {
        // EXTERNAL ID strings of our known formats - these are the published
        // IFDB identifiers for the formats
        static LPCTSTR fmts[] =
        {
            "zip",
            ".tar.Z",
            ".tar.gz",
            "tar",
            "gzip",
            "lzw.Z"
        };
        
        // allow no compression
        if (f.compr == "")
            return true;

        // we can currently handle zip, gzip, Unix 'compress' (.Z),
        // and tar files wrapped in gzip or .Z compression
        for (int i = 0 ; i < sizeof(fmts)/sizeof(fmts[0]) ; ++i)
        {
            // if this is a match, we have a valid format
            if (strcmp(fmts[i], f.compr) == 0)
                return true;
        }

        // we can't handle it - flag an error if desired
        if (complain)
        {
            CAtlString msg;
            msg.Format(_T("One of the files required for this game uses ")
                       _T("a compression format that the IFDB Meta ")
                       _T("Installer can't unpack.  You might still be ")
                       _T("able to download and install the game manually - ")
                       _T("go to the game's page on IFDB and click ")
                       _T("\"Show Me How\" in the Download box to see if ")
                       _T("installation instructions are available.\r\n\r\n")
                       _T("(File: %s; compression format: %s)"),
                       f.url, f.comprName);
            MessageBox(0, msg, msgbox_title, MB_OK | MB_ICONERROR);
        }

        // return failure
        return false;
    }

        // Carry out a network request.  We'll display our progress dialog,
        // then carry out the network request in a background thread.  When
        // the background thread exits, we'll close the progress dialog and
        // return.
        int DoNetworkRequest(HWND parent, NetworkRequest &req)
        {
                // run the progress dialog to do the download
                CProgressDialog dlg;
        dlg.DoModal(parent, (LPARAM)&req);

        // return the success indication from the request object
        return req.success;
        }

    // compare two version strings; returns -1 if a<b, 0 if a==b, 1 if a>b
    int CompareVersions(LPCTSTR a, LPCTSTR b)
    {
        // compare successive tokens - tokens are delimited by '.'
        for (;;)
        {
            int va = NextVersionToken(a);
            int vb = NextVersionToken(b);

            // if they differ, return the appropriate result
            if (va > vb)
                return 1;
            else if (va < vb)
                return -1;

            // if we're out of both strings at the same time, we're done
            if (*a == '\0' && *b == '\0')
                return 0;
        }
    }

    // get the next token from a version number string
    int NextVersionToken(LPCTSTR &p)
    {
        // if we're at the end of the string, just return zero as an
        // implied trailing version number
        if (*p == '\0')
            return 0;

        // get the decimal value of this version part
        int ret = atoi(p);

        // find the next period
        while (*p != '.' && *p != '\0')
            ++p;

        // skip the period
        if (*p == '.')
            ++p;

        // return the result
        return ret;
    }

    // Find the nth value for the given path in a parsed XML list
    LPCTSTR GetPathValue(CAtlList<xmltag> &tags, LPCTSTR path, int n = 0)
    {
        // scan the list for a match to the given path
        for (POSITION pos = tags.GetHeadPosition() ; pos != 0 ;
             tags.GetNext(pos))
        {
            xmltag *t;
            
            // check for a match
                        if ((t = &tags.GetAt(pos))->path == path)
            {
                // if this is the one we want, return it; otherwise just
                // decrement the index counter and keep looking
                if (n-- == 0)
                    return t->val;
            }
        }

        // didn't find it
        return 0;
    }

    // parse an XML file into a path list
    bool ParseXMLFile(CAtlList<xmltag> &tags, LPCTSTR fname)
    {
        CAtlString txt;
        
        // load the file into memory
        if (!LoadTextFile(txt, fname))
            return false;

        // parse the XML into the tag list
        return ParseXML(tags, txt);
    }

    // parse an XML file into a node tree
    bool ParseXMLFile(xmlnode &root, LPCTSTR fname)
    {
        CAtlString txt;

        // load the file into memory
        if (!LoadTextFile(txt, fname))
            return false;

        // parse the XML into the tag list
        return ParseXML(root, txt);
    }

    // load a text file into a string 
    bool LoadTextFile(CAtlString &str, LPCTSTR fname)
    {
        bool ok = false;
        
        // open the file
        HANDLE hf = CreateFile(fname, GENERIC_READ, 0, 0, OPEN_ALWAYS, 0, 0);
        if (hf == INVALID_HANDLE_VALUE)
            return false;

        // get the file size
        DWORD sz = GetFileSize(hf, 0);

        // load the file
        char *buf = new char[sz];
        DWORD actual;
        if (ReadFile(hf, buf, sz, &actual, 0) && actual == sz)
        {
            // store the string
            str = CAtlString(buf, sz);

            // set success status
            ok = true;
        }

        // clean up
        CloseHandle(hf);
        delete [] buf;

        // return the status 
        return ok;
    }

    // A very simple XML parser.  We return a list of content items.
    // Each content item contains the text content of a node and the
    // XMLPath-style ID of the node.  For example, <a><b>B</b><c>C</c></a>
    // return [a/b -> B, a/c -> C].  The XML returned by dladviser&xml
    // doesn't use attributes, and doesn't mix text with tags, so this
    // limited representation is adequate for our needs.
    bool ParseXML(CAtlList<xmltag> &tags, LPCTSTR xml)
    {
        xmlnode root;
        
        // parse the XML into a tree
        if (!ParseXML(root, xml))
            return false;

        // turn the tree into a path list
        XMLTreeToPathList(root, tags);

        // success
        return true;
    }

    // Convert an XML tree into a flat path list.
    void XMLTreeToPathList(xmlnode &root, CAtlList<xmltag> &tags)
    {
        // flatten the tree starting at the root
        root.Flatten("", tags);
    }

    // parsing tag descriptor
    struct xmltagdesc
    {
        // plain text prior to the tag
        CAtlString preTxt;

        // tag name
        CAtlString name;

        // end tag? self-closing?
        bool isEnd;
        bool isSelfClosing;
    };

    // Simple XML tree parser. 
    bool ParseXML(xmlnode &root, LPCTSTR xml)
    {
        CAtlList<xmlnode*> stack;
        xmlnode *cur = 0;
        LPCTSTR p;
        xmltagdesc tag;

        // start at the beginning
        p = xml;

        // find the first non-processing tag
        for (;;)
        {
            // find the next tag; it must not have any text preceding it,
            // since there can't be anything outside of the root tag
            if (!NextXMLTag(tag, p) || tag.preTxt != "")
                return false;

            // if it's not a processing tag, it's the root tag
            if (tag.name[0] != '?')
                break;
        }

        // set up the root tag
        root.name = tag.name;
        cur = &root;
        stack.AddTail(cur);

        // parse the contents of the root tag - keep going until we run
        // out of text or we leave the root tag
        while (*p != 0 && stack.GetCount() != 0)
        {
            // find the next tag
            if (!NextXMLTag(tag, p))
                return false;

            // add pre-tag text to the current tag
            cur->val += tag.preTxt;

            // open or close the tag as appropriate
            if (tag.isEnd)
            {
                // close tag - make sure it matches the open tag
                if (tag.name != cur->name)
                    return false;

                // pop the stack
                stack.RemoveTail();
                cur = (stack.GetCount() != 0 ? stack.GetTail() : 0);
            }
            else
            {
                // it's an open or self-closing tag - open the child
                cur->children.AddTail();
                xmlnode *chi = &cur->children.GetTail();
                chi->name = tag.name;

                // if it's not a self-closing tag, push it onto the stack
                if (!tag.isSelfClosing)
                    stack.AddTail(cur = chi);
            }
        }

        // if we ran out of text without closing the root tag, it's an error
        if (stack.GetCount() != 0)
            return false;

        // if there's anything left, it's an error
        for ( ; isSpaceOrNl(*p) ; ++p) ;
        if (*p != '\0')
            return false;

        // success
        return true;
    }

    // parse the next XML tag
    bool NextXMLTag(xmltagdesc &tag, LPCTSTR &p)
    {
        LPCTSTR start, endp;
        int qu;
        LPCTSTR closep;
        
        // initialize the tag
        tag.isEnd = tag.isSelfClosing = false;

        // skip leading whitespace
        while (*p == '\n' || *p == '\r' || isSpaceOrNl(*p))
            ++p;

        // find the next tag
        for (start = p ; *p != '\0' && *p != '<' ; ++p) ;

        // trim trailing spaces
        for (endp = p ; endp > start && isSpaceOrNl(*(endp-1)) ; --endp) ;

        // add the text to the pre-tag run
        GetXmlText(tag.preTxt, start, (int)(endp - start));

        // if we reached the end of the text, we're done
        if (*p == '\0')
            return false;
            
        // skip the '<' and any subsequent whitespace
        for (++p ; isSpaceOrNl(*p) ; ++p) ;

        // note if it's a close tag
        if (*p == '/')
        {
            tag.isEnd = true;
            ++p;
        }

        // scan the tag name
        for (start = p ;
             *p != '\0' && *p != '>' && *p != '/' && !isSpaceOrNl(*p) ;
             ++p) ;
                
        // note the length of the tag name
        size_t taglen = p - start;

        // store the name
        tag.name = CAtlString(start, taglen);
        
        // skip to the '>' - we don't do anything with attributes,
        // but we at least have to parse their lexical structure
        for (qu = 0 ; *p != '\0' ; ++p)
        {
            // if this is the end tag, we're done
            if (*p == '>' && qu == 0)
            {
                closep = ++p;
                break;
            }
            
            // check for quotes
            if (qu == 0 && (*p == '"' || *p == '\''))
            {
                // start a quoted section
                qu = *p;
            }
            else if (qu != 0 && *p == qu)
            {
                // end the quoted section
                qu = 0;
            }
        }
        
        // skip back to the last non-blank after the tag
        for (--p ; p > start + taglen && isSpaceOrNl(*(p-1)) ; --p) ;
        
        // check for a '/' at the end of the tag 
        tag.isSelfClosing = (*(p-1) == '/');

        // skip whitespace following the tag
        for (p = closep ; isSpaceOrNl(*p) ; ++p) ;
                
        // success
        return true;
    }

    // add a chunk of plain text to an XML string
    void GetXmlText(CAtlString &dst, LPCTSTR p, size_t len)
    {
        LPCTSTR start;

        // scan the string for newlines and tabs
        for (start = p, dst = "" ; len != 0 ; ++p, --len)
        {
            if (*p == '\n' || *p == '\r' || *p == '\t')
            {
                // convert these to ordinary whitespace
                dst += CAtlString(start, (int)(p - start));
                dst += ' ';
                p = start + 1;
            }
            else if (*p == '&')
            {
                // entity - look it up
                struct entmap
                {
                    LPCTSTR name;
                    int namelen;
                    char ch;
                } *ep, entities[] =
                {
                    { _T("amp"), 3, '&' },
                    { _T("quot"), 4, '"' },
                    { _T("#34"), 3, '"' },
                    { _T("#034"), 4, '"' },
                    { _T("#39"), 3, '\'' },
                    { _T("#039"), 4, '\'' },
                    { _T("lt"), 2, '<' },
                    { _T("gt"), 2, '>' },
                    { 0, 0 }
                };
                
                // find the entity in our list
                for (ep = entities ; ep->name != 0 ; ++ep)
                {
                    // check for a match
                    if (len >= ep->namelen + 2
                        && memcmp(p+1, ep->name, ep->namelen) == 0
                        && p[ep->namelen + 1] == ';')
                    {
                        // Found it - use this translation.  Add
                        // the text chunk up to the '&' first...
                        dst += CAtlString(start, (int)(p - start));
                        
                        // add the translation
                        dst += ep->ch;
                        
                        // advance to the ';'
                        p += ep->namelen + 1;
                        len -= ep->namelen + 1;
                        
                        // the next chunk starts after the ';'
                        start = p + 1;
                        
                        // no need to look any further
                        break;
                    }
                }
            }
        }

        // add the final chunk
        dst += CAtlString(start, (int)(p - start));
    }


    // append XML to a string
    void AddXmlEle(CAtlString &dst, LPCTSTR tag, LPCTSTR val, LPCTSTR indent)
    {
        // replace any '<', '>', or '&' characters in the value with
        // entities
        CAtlString qval;
        QuoteXML(qval, val);

        // build the tagged value
        CAtlString buf;
        buf.Format("%s<%s>\r\n%s  %s\r\n%s</%s>\r\n", 
                   indent, tag, indent, qval, indent, tag);

        // append the tagged value to the output
        dst += buf;
    }

    // is 'c' a space or newline character?
    bool isSpaceOrNl(TCHAR c)
    {
        return isspace(c) || c == '\n' || c == '\r';
    }

    // get the OS ID string (per the IFDB published OS list)
    bool GetOSID(CAtlString &osid)
    {
        OSVERSIONINFOEX osvi;
        SYSTEM_INFO si;
        BOOL bOsVersionInfoEx;

        // presume we won't figure this out
        osid = _T("");
        
        // get the version information from the OS
        ZeroMemory(&si, sizeof(SYSTEM_INFO));
        ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
        osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
        if(!(bOsVersionInfoEx = GetVersionEx((OSVERSIONINFO *)&osvi)))
        {
            osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
            if (!GetVersionEx((OSVERSIONINFO *)&osvi)) 
                return false;
        }

        // check the main platform ID
        switch (osvi.dwPlatformId)
        {
        case VER_PLATFORM_WIN32_NT:
            if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 1)
                osid = _T("Win7");
            if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 0)
                osid = _T("Vista");
            if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 2)
            {
                osid = _T("XP");
                // if (GetSystemMetrics(SM_SERVERR2))
                //   osid = _T("XP"); // really Server 2003 _T("R2")
                // else if( osvi.wProductType == VER_NT_WORKSTATION &&
                //   si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)
                //   osid = _T("XP"); // really XP Profession x64 Edition
                // else
                //   osid = _T("XP"); // really Server 2003
            }
            if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1)
                osid = _T("XP");
            if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0)
                osid = _T("2000");
            if (osvi.dwMajorVersion <= 4)
                osid = _T("NT4");
            break;

        case VER_PLATFORM_WIN32_WINDOWS:
            if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 0)
            {
                osid = _T("95");
                if (osvi.szCSDVersion[1]=='C' || osvi.szCSDVersion[1]=='B')
                    ; // 95 OSR2
            } 
            if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 10)
            {
                osid = (osvi.szCSDVersion[1]=='A' || osvi.szCSDVersion[1]=='B')
                       ? _T("98SE") : _T("98");
            } 
            if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 90)
                osid = _T("ME");
            break;
        }

        // we were successful only if we found something
        return osid != _T("");
    }

    // the game ID string - this is passed to us via the "-id" command
    // line parameter
    CAtlString id;

        // the mirror ID
        CAtlString mirrorID;

    // parse the command line
    bool ParseCommandLine(LPCTSTR lpCmdLine, HRESULT* pnRetCode) throw()
    {
        // inherit the default handling
        if (!CAtlExeModuleT<CIfdbInstallerModule>::ParseCommandLine(
            lpCmdLine, pnRetCode))
            return false;

        // presume success
        *pnRetCode = S_OK;

        // skip the program name token
        CAtlString tok;
        NextToken(tok, lpCmdLine);

        // scan tokens
        for (;;)
        {
            // get the next token
            if (!NextToken(tok, lpCmdLine))
                break;

            // check what we have
            if (tok == _T("-id") && NextToken(tok, lpCmdLine))
            {
                // save the ID
                id = tok;
            }
            else if (tok == _T("-mirror") && NextToken(tok, lpCmdLine))
            {
                // save the mirror
                mirrorID = tok;
            }
            else
            {
                MessageBox(0, _T("Invalid parameters"), msgbox_title, 
                    MB_ICONERROR | MB_OK);
                *pnRetCode = E_INVALIDARG;
                return false;
            }
        }

        // make sure we have an ID
        if (id == _T(""))
        {
            MessageBox(0, _T("The game ID was not specified."),
                       msgbox_title, MB_ICONERROR | MB_OK);
            *pnRetCode = E_INVALIDARG;
            return false;
        }

        // tell the caller to proceed into the main program
        return true;
    }

    // Read a token using the bizarre Windows shell heuristics for
    // the first token in a HKCR\<filetype>\shell\open\command string.
    //
    // Empirically, Windows seems to apply a weird (and undocumented)
    // heuristic to this type of key, presumably to handle cases where
    // errant installers failed to enclose the program path in quotes
    // even though that path might contain spaces.  Having spaces
    // in the program path is extremely common because of the default
    // "c:\My Programs" path on US-localized systems; even though
    // the SDK documentation says that quotes are required in such
    // a situation, the Windows programmers evidently thought better
    // of it and came up with a heuristic.  A little experimentation
    // suggests that the hueristic is as follows: if the first token
    // isn't quoted, parse ahead until we find a quoted token or a
    // token containing a forward slash or percent sign; remember the
    // last of these that contains a backslash.  Concatenate all of
    // these tokens from the first to the last containing a backslash;
    // look to see if this or this+".exe" is an existing file, and stop
    // if so; if not, concatenate one more token and repeat.
    bool ParseSpecialShellToken(CAtlString &tok, LPCTSTR &p)
    {
        // skip whitespace
        while (*p != '\0' && isspace(*p))
            ++p;

        // if we're at a quoted token, then this is straightforwardly
        // just the contents of the quotes
        if (*p == '"')
            return NextToken(tok, p);

        // if we're at the end of the line, there is no token
        if (*p == '\0')
            return false;

        // The token is unquoted, so we need to apply the special rules.
        // Note where it starts.
        LPCTSTR start = p;

        // find the end of this token
        while (*p != '\0' && !isspace(*p))
            ++p;

        // so far, this is all we've committed to
        LPCTSTR commitp = p;

        // so far, this is all we even can consider
        LPCTSTR endp = p;

        // Now scan additional tokens.  Each time we find a token containing
        // a backslash, commit that token to the result.  If we find a
        // quoted token, or a token containing a forward slash or a percent
        // sign, stop - that token isn't included.
        while (*p != '\0')
        {
            bool good, bad;
            
            // note the current token end
            LPCTSTR curEnd = p;

            // skip whitespace
            while (isspace(*p))
                ++p;

            // if we're at a quoted token or the end of the line, stop
            if (*p == '"' || *p == '\0')
                break;

            // scan this token, watching for '/' and '%'
            for (good = bad = false ; *p != '\0' && !isspace(*p) ; ++p)
            {
                switch (*p)
                {
                case '/':
                case '%':
                    // these disqualify the token
                    bad = true;
                    break;

                case '\\':
                    // this commits the token
                    good = true;
                    break;
                }
            }

            // if the token is bad, stop scanning
            if (bad)
                break;

            // this token isn't bad, so we can possibly consider it -
            // include up to its end in the potential token part
            endp = p;

            // if this token is definitely good, commit it
            if (good)
                commitp = p;
        }

        // Okay, we now have a committed part and a possible part.  Scan
        // each token after the commited part but only as far as the end
        // of the possible part.  At the first one that names a valid
        // file, either by itself or by adding ".exe", stop and take
        // that as the result.  If we can't find a valid file in any
        // of the possible strings, the result is simply the committed
        // part.
        for (p = commitp ; ; )
        {
            // scan to the start of the next token
            for ( ; isspace(*p) ; ++p) ;

            // if this puts us past the end, we're done
            if (p >= endp)
                break;

            // scan to the end of this token
            for ( ; *p != '\0' && !isspace(*p) ; ++p) ;

            // if this forms a valid file, take it
            CAtlString f = CAtlString(start, (int)(p - start));
            if (GetFileAttributes(f) != INVALID_FILE_ATTRIBUTES
                || GetFileAttributes(f + ".exe") != INVALID_FILE_ATTRIBUTES)
            {
                // commit to this stretch of text
                commitp = p;

                // we're done looking
                break;
            }
        }

        // When we get here, commitp gives the end of the committed
        // token.  Move p to this point - it's the continuation point
        // for further parsing.
        p = commitp;

        // pull out the token text
        tok = CAtlString(start, (int)(p - start));

        // success
        return true;
    }

    // Get the next token in a command line (tokens are delimited by
    // spaces; double quotes can be used to enclose tokens containing
    // spaces; to include a double quote within a double-quoted string,
    // stutter the quote or escape it with a backslash; other backslashes
    // are just backslashes).
    bool NextToken(CAtlString &tok, LPCTSTR &p)
    {
        // skip leading whitespace
        while (*p != '\0' && isspace(*p))
            ++p;

        // check for end of string
        if (*p == '\0')
            return false;

        // check for quotes
        LPCTSTR start = p;
        if (*p == '"')
        {
            // skip the open quote
            ++p, ++start;

            // empty out the result token
            tok = _T("");

            // scan for the close quote
            for (bool done = false ; !done ; ++p)
            {
                switch (*p)
                {
                case '"':
                    // close quote - append the part up to here
                    tok += CAtlString(start, p - start);

                    // if another quote immediately follows, treat it
                    // as a stuttered quote, which counts as one quote
                    // embedded in the string, and keep going; otherwise,
                    // we're done
                    if (*++p == '"')
                    {
                        // stuttered quote - just start the next chunk at 
                        // the quote, and keep going
                        start = p;
                    }
                    else
                    {
                        // that's the end of the token
                        done = true;
                    }
                    break;

                case '\\':
                    // if the next character is a quote, count this
                    // as an escape character
                    if (*(p+1) == '"')
                    {
                        // add this chunk
                        CAtlString t(start, p - start);
                        tok += t;

                        // start the next chunk at the quote, and
                        // keep going
                        start = ++p;
                    }
                    break;
                }
            }
        }
        else
        {
            // the token ends at the next space
            while (*p != '\0' && !isspace(*p))
                ++p;

            // pull out the token
            CAtlString t(start, p - start);
            tok = t;
        }

        // success
        return true;
    }
};

