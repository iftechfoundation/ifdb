// UpdateDlg.h : Declaration of the CUpdateDlg

#pragma once

#include "resource.h"       // main symbols
#include <atlhost.h>


// CUpdateDlg

class CUpdateDlg : 
	public CAxDialogImpl<CUpdateDlg>
{
public:
	CUpdateDlg()
	{
	}

	~CUpdateDlg()
	{
	}

	enum { IDD = IDD_UPDATEDLG };

BEGIN_MSG_MAP(CUpdateDlg)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOK)
	COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnClickedCancel)
	CHAIN_MSG_MAP(CAxDialogImpl<CUpdateDlg>)
END_MSG_MAP()

// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CAxDialogImpl<CUpdateDlg>::OnInitDialog(uMsg, wParam, lParam, bHandled);
		CheckDlgButton(IDYES, BST_CHECKED);
		return 1;  // Let the system set the focus
	}

	LRESULT OnClickedOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// end the dialog with the code for the selected radio button
		if (IsDlgButtonChecked(IDYES) == BST_CHECKED)
			EndDialog(IDYES);
		else if (IsDlgButtonChecked(IDNO) == BST_CHECKED)
			EndDialog(IDNO);
		else if (IsDlgButtonChecked(IDC_RB_NEVER) == BST_CHECKED)
			EndDialog(IDC_RB_NEVER);
		else
			EndDialog(wID);
		return 0;
	}

	LRESULT OnClickedCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
};


