//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IfdbInstaller.rc
//
#define IDC_BTN_BACK                    3
#define IDS_PROJNAME                    100
#define IDR_IFDBINSTALLER               101
#define IDS_TERPUPDATE1                 101
#define IDD_MAINDLG                     102
#define IDS_TERPUPDATE2                 102
#define IDS_TERPUPDATE3                 103
#define IDS_EXE_NA                      104
#define IDD_GAMEUPDATEDLG               105
#define IDD_UPDATEDLG                   106
#define IDC_RB_INSTALLIT                201
#define IDC_RB_ALREADYGOTIT             202
#define IDC_FLD_URLS                    203
#define IDC_ST_NEEDTERP                 204
#define IDC_ST_TITLE                    205
#define IDC_ST_URLS                     206
#define IDC_ST_WARN                     207
#define IDC_PROGBAR                     208
#define IDC_ST_PROGRESS                 209
#define IDB_SIDEIMAGE                   210
#define IDC_CB_PLAYERS                  210
#define IDD_PROGRESS                    211
#define IDC_ST_PLAYERS                  211
#define IDD_PLAYERDLG                   212
#define IDC_FLD_PROG                    213
#define IDC_BTN_BROWSE                  214
#define IDC_ST_INTRO                    215
#define IDC_ST_NEEDGAME                 216
#define IDC_RB_NEVER                    219
#define IDC_BUTTON1                     220
#define IDC_BTN_UPDATE                  220

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        214
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         221
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
