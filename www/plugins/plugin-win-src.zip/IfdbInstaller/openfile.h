// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

#ifndef _OPENFILE_H_
#define _OPENFILE_H_

#include "stdafx.h"
#include <windows.h>

/*
 *   OPENFILENAME structure with and without the Win 2k+ expansion.  We want
 *   our code to work on NT4/95/98/Me as well, so we need to use the larger
 *   structure on the newer systems and the smaller structure on the older
 *   systems.  The whole point of the lStructSize field is that it *should*
 *   take care of this for us automatically by letting the APIs know which
 *   version of the structure we're using, but alas, things never quite work
 *   as documented.  
 */
#if _WIN32_WINNT < 0x0500
#define OPENFILENAME_NT4  OPENFILENAME
#endif
struct OPENFILENAME5: OPENFILENAME_NT4
{
    /* the following are the NT5 extensions */
    void        *pvReserved;
    DWORD        dwReserved;
    DWORD        FlagsEx;

    OPENFILENAME5()
    {
        memset(this, 0, sizeof(*this));
        lStructSize = is_win2k_or_later()
                      ? sizeof(OPENFILENAME5) : sizeof(OPENFILENAME_NT4);
    }

    static bool is_win2k_or_later()
    {
        // get version information from Windows
        OSVERSIONINFO osver;
        memset(&osver, 0, sizeof(osver));
        osver.dwOSVersionInfoSize = sizeof(osver);
        GetVersionEx(&osver);
        
        // Win 2k is internally "NT 5"
        return (osver.dwPlatformId == VER_PLATFORM_WIN32_NT
                && osver.dwMajorVersion >= 5);
    }
};

#endif /* _OPENFILE_H_ */

