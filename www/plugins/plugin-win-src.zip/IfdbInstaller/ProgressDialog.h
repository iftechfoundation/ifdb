// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details


// ProgressDialog.h : Declaration of the CProgressDialog

#pragma once

#include "resource.h"       // main symbols
#include <atlhost.h>

#include <wininet.h>


// Base class for network request descriptor.  This type of object
// carries out a network request in a background thread while the 
// main thread displays a progress dialog.
class NetworkRequest
{
public:
    NetworkRequest()
    {
        // the user hasn't asked for cancellation yet
        cancel_ = false;
        hreq_ = 0;

        // set up our cancellation event object
        cancelEvent_ = CreateEvent(0, TRUE, FALSE, 0);

        // we haven't successfully completed yet
        success = false;

        // we haven't started downloading any files yet
        cur_file_num_ = 0;

        // presume we'll only download one file during this request
        number_of_files_ = 1;
    }

    virtual ~NetworkRequest()
    {
        CloseHandle(cancelEvent_);
    }

    // how many files are we downloading as part of this task?
    size_t number_of_files_;

    // current file we're working on
    size_t cur_file_num_;

    // get the initial message to display in the dialog
    virtual LPCTSTR GetInitMsg() const { return GetBaseMsg(); }

    // get the base message
    virtual LPCTSTR GetBaseMsg() const { return "Working..."; }

    // set the progress message text
    void SetProgressMsg(HWND dlg, LPCTSTR msg)
    {
        ::SetDlgItemText(dlg, IDC_ST_PROGRESS, msg);
    }

    // show/hide the progress bar
    void ShowProgressBar(HWND dlg, int show)
    {
        ::ShowWindow(::GetDlgItem(dlg, IDC_PROGBAR), show ? SW_SHOW : SW_HIDE);
    }

    // Get the progress message when we've downloaded 'bytes_so_far' of
    // 'file_size' bytes from 'url'.  If 'file_size' is 0, it means that
    // we don't know the actual file size.
    virtual void GetProgressMsg(
        CAtlString &msg,
        unsigned __int64 bytes_so_far, unsigned __int64 file_size,
        LPCTSTR url) const
    {
        // generate the download message
        CAtlString dl;
        if (file_size != 0)
            dl.Format("Downloading from %s...\r\n(%I64u of %I64u bytes)",
                      url, bytes_so_far, file_size);
        else
            dl.Format("Downloading from %s...\r\n(received %I64u bytes)",
                      url, bytes_so_far);

        // if there's a base message, combine it with the download message
        LPCTSTR base = GetBaseMsg();
        if (base != 0 && strlen(base) != 0)
        {
            msg = base; 
            msg += "\r\n\r\n" + dl;
        }
        else
            msg = dl;
    }

    // Carry out the task - this is invoked in a background thread
    // to perform the network request.
    virtual void DoRequest(HWND dlg) = 0;

    // Cancel the request.  The dialog calls this to tell us that
    // the user has pressed the Cancel button while we're working.
    // By default, we just set the cancel_ flag, which the background
    // thread can check from time to time to see if it should abort
    // its operation.  Subclasses can override this if they want to
    // asynchronously interrupt the current network read, if applicable.
    virtual void Cancel(HWND dlg)
    {
        // set the cancel flag
        cancel_ = true;

        // if there's a request under way, unblock it
        if (hreq_ != 0)
            InternetCloseHandle(hreq_);

        // set the progress dialog to indicate that we're canceling
        SetProgressMsg(dlg, "Canceling...");

        // set the cancel event, to break any background threads out of
        // event waits
        SetEvent(cancelEvent_);
    }

    // Cancel flag - this indicates that the user has requested
    // cancellation.  The background thread should stop what it's
    // doing as soon as possible, clean up any work it's already
    // done, and terminate.
    bool cancel_;

    // cancellation event object - when the user clicks the button, we'll
    // set this event; this allows background threads that need to wait
    // for other events to include this in their waits, so that we can
    // immediately break out of those ewaits in case of UI cancellation
    HANDLE cancelEvent_;

    // Was the request successful?
    bool success;

    // request handle - the background thread sets this when it's in a
    // blocking read, so that the foreground thread can unblock the
    // background thread by closing the handle
    HINTERNET hreq_;

    // download a file from a given URL; save it to the given filename, or
    // just return it as text in the given buffer
    bool DownloadFile(HWND dlg, CAtlString *outbuf, LPCTSTR fname,
                      LPCTSTR url)
    {
        FILE *fp = 0;
        HINTERNET hnet = 0;
        HINTERNET hfile = 0;
        unsigned __int64 total_bytes = 0;
        const char title[] = "IFDB Installer";
        CAtlString msg;

        // count the file
        cur_file_num_ += 1;

        // initialize the progress message with an unknown file size
        GetProgressMsg(msg, 0, 0, url);
        SetProgressMsg(dlg, msg);

        // open the output file, if desired
        if (fname != 0 && (fp = fopen(fname, "wb")) == 0)
        {
            msg.Format("Error creating file %s - you may be low on "
                    "disk space or you may not have permission to write "
                    "to this directory.", fname);
            ::MessageBox(dlg, msg, title,
                        MB_OK | MB_ICONEXCLAMATION);

            // give up
            goto do_cancel;
        }

        // open the internet connection
        hnet = InternetOpen(
            "IFDB Installer/1.0 (Windows)",
            INTERNET_OPEN_TYPE_PRECONFIG, 0, 0, 0);
        if (hnet == 0)
        {
            ::MessageBox(dlg,
                        "An error occurred opening a network connection. "
                        "Please check your Internet configuration. If you "
                        "have a firewall installed, you may need to set it "
                        "to allow the IFDB Installer to access the network.",
                        title, MB_OK | MB_ICONERROR);
            goto do_cancel;
        }

        // remember the request handle
        hreq_ = hnet;

        // if the user canceled while we were waiting, stop
        if (cancel_)
            goto do_cancel;

        // set the connection timeout to ensure we don't wait forever 
        // timeout = 30000;
        // InternetSetOption(hnet, INTERNET_OPTION_CONNECT_TIMEOUT,
        //                   &timeout, sizeof(timeout));

        // open the file given by the URL
        hfile = InternetOpenUrl(
            hnet, url, 0, 0, INTERNET_FLAG_EXISTING_CONNECT, (DWORD_PTR)this);

        // check for cancellation
        if (cancel_)
            goto do_cancel;

        // check the results
        if (hfile == 0)
        {
            // complain about it
            msg.Format(
                "An error occurred connecting to %s. The site might be "
                "temporarily unavailable, or the file might have been "
                "moved.", url);
            ::MessageBox(dlg, msg, title, MB_OK | MB_ICONEXCLAMATION);

            // give up
            goto do_cancel;
        }

        // get the file size, if it's a request type that allows this
        unsigned __int64 file_size = 0;
        if (memcmp(url, "http:", 5) == 0)
        {
            // http request - query the http file size
                        char buf[50];
                        DWORD buflen = sizeof(buf);
            if (HttpQueryInfo(hfile, HTTP_QUERY_CONTENT_LENGTH, &buf, &buflen, 0))
                file_size = _atoi64(buf);
        }
        else if (memcmp(url, "ftp:", 4) == 0)
        {
            // ftp request - query the ftp file size
            DWORD file_size_hi;
            file_size = FtpGetFileSize(hfile, &file_size_hi);
            file_size |= (((unsigned __int64)file_size_hi) << 32);
        }

        // if we know the file size, set the progress bar to a percentage
        // range; otherwise hide the progress bar
        HWND progbar = ::GetDlgItem(dlg, IDC_PROGBAR);
        if (file_size != 0)
        {
            SendMessage(progbar, PBM_SETRANGE, 0, MAKELPARAM(0, 100));
            SendMessage(progbar, PBM_SETPOS, 0, 0);
        }
        else
            ShowProgressBar(dlg, FALSE);

        // set the initial progress bar message to reflect that we're
        // downloading this file
        GetProgressMsg(msg, 0, file_size, url);
        SetProgressMsg(dlg, msg);

        // download the data
        for ( ;; )
        {
            char buf[4097];
            DWORD actual;
            int stat;

            // if the user canceled, stop the download
            if (cancel_)
                goto do_cancel;

            // read some more
            stat = InternetReadFile(hfile, buf, sizeof(buf) - 1, &actual);

            // check for cancellation
            if (cancel_)
                goto do_cancel;

            // check for errors
            if (!stat)
            {
                // complain about it
                msg.Format(
                    "A network error occurred reading from "
                    "%s. This might be due to a temporary "
                    "network problem or a problem with the server.", url);
                ::MessageBox(dlg, msg, title, MB_OK | MB_ICONEXCLAMATION);

                // give up
                goto do_cancel;
            }

            // if we've cancelled, give up
            if (cancel_)
                goto do_cancel;

            // if we read zero bytes, we're done 
            if (actual == 0)
                break;

            // write the data to the file 
            if (fp != 0)
            {
                if (fwrite(buf, actual, 1, fp) != 1)
                {
                    // error writing - complain 
                    msg.Format(
                        "An error occurred saving data downloaded "
                        "from %s. Check to make sure your disk has "
                        "enough available space for this download.", url);
                    ::MessageBox(dlg, msg, title,
                                MB_OK | MB_ICONEXCLAMATION);

                    // give up 
                    goto do_cancel;
                }
            }
            else
            {
                buf[actual] = '\0';
                *outbuf += buf;
            }

            // count the new chunk in the total so far
            total_bytes += actual;

            // update the progress display
            if (file_size != 0)
            {
                // Calculate the percentage.  We divide the overall bar
                // into n equal segments, where n is the number of files
                // we're fetching during this request.  This file then
                // gets its percentage of the current segment
                int pct = (int)(
                    ((((double)total_bytes / (double)file_size)
                      + ((double)cur_file_num_ - 1.0))
                     / (double)number_of_files_)
                    * 100.0);

                // set the progress bar
                SendMessage(progbar, PBM_SETPOS, pct, 0);

                // update the progress message
                GetProgressMsg(msg, total_bytes, file_size, url);
                SetProgressMsg(dlg, msg);
            }
        }

        // close the file
        if (fp != 0)
            fclose(fp);

        // close the handles
        hreq_ = 0;
        InternetCloseHandle(hnet);
        InternetCloseHandle(hfile);

        // success
        return true;

    do_cancel:
        // if we created a file, remove it
        if (fp != 0)
        {
            fclose(fp);
            remove(fname);
        }

        // close the resource and internet connection handles
        if (hfile != 0)
            InternetCloseHandle(hfile);
        if (hnet != 0)
            InternetCloseHandle(hnet);

        // indicate failure
        return false;
    }
};


// CProgressDialog

class CProgressDialog : 
        public CAxDialogImpl<CProgressDialog>
{
public:
        CProgressDialog()
        {
        }

        ~CProgressDialog()
        {
        }

        enum { IDD = IDD_PROGRESS };

BEGIN_MSG_MAP(CProgressDialog)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOK)
        COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnClickedCancel)
        CHAIN_MSG_MAP(CAxDialogImpl<CProgressDialog>)
END_MSG_MAP()

    // Handler prototypes:
    //  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    //  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
    //  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

    // the request descriptor
    NetworkRequest *req_;

    // the background thread handle
    HANDLE thread_;

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
    {
        DWORD thread_id;
        
        // do the base class work
        CAxDialogImpl<CProgressDialog>::OnInitDialog(
            uMsg, wParam, lParam, bHandled);

        // remember the request descriptor
        req_ = (NetworkRequest *)lParam;

        // set the initial progress message
        SetDlgItemText(IDC_ST_PROGRESS, req_->GetInitMsg());

        // start the background thread to carry out the network task
        thread_ = CreateThread(
            0, 0, (LPTHREAD_START_ROUTINE)&thread_main, (void *)this,
            0, &thread_id);

        // if the thread didn't start, cancel the dialog immediately
        if (thread_ == 0)
        {
            MessageBox("An error occurred starting the download "
                       "thread. The system might be low on memory.",
                       "IFDB Installer", MB_OK | MB_ICONERROR);
            EndDialog(IDCANCEL);
        }

        // let the system set the focus
        return 1;
    }

    // main background thread entrypoint
    static DWORD thread_main(void *ctx)
    {
        // the context is our 'this' pointer
        CProgressDialog *self = (CProgressDialog *)ctx;

        // run the network task
        self->req_->DoRequest(self->m_hWnd);

        // when the task ends, close the window
                ::EndDialog(self->m_hWnd, IDOK);

        // done
        return 0;
    }

    LRESULT OnClickedOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        return 0;
    }

    LRESULT OnClickedCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        // cancel the request
        req_->Cancel(m_hWnd);
        return 0;
    }
};
