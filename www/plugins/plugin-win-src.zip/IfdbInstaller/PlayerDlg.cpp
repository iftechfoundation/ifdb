// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// PlayerDlg.cpp : Implementation of CPlayerDlg

#include "stdafx.h"
#include "PlayerDlg.h"
#include "openfile.h"
#include ".\playerdlg.h"


// CPlayerDlg

LRESULT CPlayerDlg::OnCtlColorDlg(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
    // white background
    ::SetTextColor((HDC)wParam, RGB(0x00,0x00,0x00));
    return (LRESULT)bkg_brush_;
}

LRESULT CPlayerDlg::OnCtlColorStatic(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
{
    // black text; draw transparently
    HDC hdc = (HDC)wParam;
    HWND ctl = (HWND)lParam;
    ::SetTextColor(hdc, RGB(0x00,0x00,0x00));
    ::SetBkMode((HDC)wParam, TRANSPARENT);
    return (LRESULT)bkg_brush_;
}

LRESULT CPlayerDlg::OnBnClickedBtnBrowse(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    // show a file selector
    OPENFILENAME5 ofn;
    TCHAR fname[MAX_PATH];

    ofn.hwndOwner = m_hWnd;
    ofn.hInstance = _AtlBaseModule.GetResourceInstance();
    ofn.lpstrFilter = _T("Applications (*.exe)\0*.exe\0")
                      _T("All Files (*.*)\0*.*\0");
    ofn.lpstrCustomFilter = 0;
    ofn.nFilterIndex = 0;
    ofn.lpstrFile = fname;
    fname[0] = '\0';
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFileTitle = 0;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = 0;
    ofn.lpstrTitle = "Select the player application file";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST
                | OFN_NOCHANGEDIR | OFN_ENABLESIZING;
    ofn.nFileOffset = 0;
    ofn.nFileExtension = 0;
    ofn.lpstrDefExt = 0;
    ofn.lCustData = 0;
    ofn.lpfnHook = 0;
    ofn.lpTemplateName = 0;
	if (!::GetOpenFileName(&ofn))
        return 1;

    // save the new name
    exepath = fname;

    // update the UI for the new selection
    UpdateUI();

    // handled
    return 1;
}

LRESULT CPlayerDlg::OnCbnSelchangeCbPlayers(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    // update the UI on a selection change
    UpdateUI();
    return 0;
}

LRESULT CPlayerDlg::OnBnClickedBtnBack(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    // save the dialog box settings
    SaveSettings();

    // dismiss the dialog
    EndDialog(wID);
    return 0;
}
