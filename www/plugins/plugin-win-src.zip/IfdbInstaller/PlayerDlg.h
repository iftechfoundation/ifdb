// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details


// PlayerDlg.h : Declaration of the CPlayerDlg

#pragma once

#include "resource.h"       // main symbols
#include <atlhost.h>
#include "ifdbinst.h"


// CPlayerDlg

class CPlayerDlg : 
    public CAxDialogImpl<CPlayerDlg>
{
public:
    CPlayerDlg()
    {
        // set up our resources
        bkg_brush_ = ::CreateSolidBrush(RGB(0xFF,0xFF,0xFF));
    }

    ~CPlayerDlg()
    {
        // release resources
        DeleteObject(bkg_brush_);
    }

    enum { IDD = IDD_PLAYERDLG };

BEGIN_MSG_MAP(CPlayerDlg)
    MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
    COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOK)
    COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnClickedCancel)
    MESSAGE_HANDLER(WM_CTLCOLORDLG, OnCtlColorDlg)
    MESSAGE_HANDLER(WM_CTLCOLORSTATIC, OnCtlColorStatic)
        COMMAND_HANDLER(IDC_BTN_BROWSE, BN_CLICKED, OnBnClickedBtnBrowse)
        COMMAND_HANDLER(IDC_CB_PLAYERS, CBN_SELCHANGE, OnCbnSelchangeCbPlayers)
        COMMAND_HANDLER(IDC_BTN_BACK, BN_CLICKED, OnBnClickedBtnBack)
        CHAIN_MSG_MAP(CAxDialogImpl<CPlayerDlg>)
END_MSG_MAP()

// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

    // background brush
    HBRUSH bkg_brush_;

    // our main information object
    dlinfo *info;

    // the current .exe path, as entered by the user
    CAtlString exepath;

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
    {
        CAxDialogImpl<CPlayerDlg>::OnInitDialog(uMsg, wParam, lParam, bHandled);
        CAtlString str;
        TCHAR buf[256];
        int idx;

        // get the download information
        info = (dlinfo *)lParam;

        // if we've already chosen a path on a previous round, use it
        exepath = info->terpExe;

        // fill in the format name in the intro text
        GetDlgItemText(IDC_ST_INTRO, buf, sizeof(buf));
        str.Format(buf, info->fmtName);
        SetDlgItemText(IDC_ST_INTRO, str);

        // populate the interpreter combo list
        HWND cbo = GetDlgItem(IDC_CB_PLAYERS);
        for (POSITION pos = info->terps.GetHeadPosition() ; pos != 0 ;
             info->terps.GetNext(pos))
        {
            // add this item
            idx = (int)::SendMessage(
                cbo, CB_ADDSTRING, 0,
                (LPARAM)(LPCTSTR)info->terps.GetAt(pos).name);

            // the lparam is the position in the list
            ::SendMessage(cbo, CB_SETITEMDATA, idx, (LPARAM)pos);

            // if this is the initial interpreter selection, select
            // it in the combo
            if (pos == info->selectedTerp)
                ::SendMessage(cbo, CB_SETCURSEL, idx, 0);
        }

        // add the "Other" item
        idx = (int)::SendMessage(cbo, CB_ADDSTRING, 0, (LPARAM)"(Other)");
        ::SendMessage(cbo, CB_SETITEMDATA, idx, 0);

        // initialize UI dependencies
        UpdateUI();

        // Let the system set the default focus
        return 1;
    }

    void UpdateUI()
    {
        // get the selected interpreter
        HWND cbo = GetDlgItem(IDC_CB_PLAYERS);
        int idx = (int)::SendMessage(cbo, CB_GETCURSEL, 0, 0);
        POSITION pos = (POSITION)::SendMessage(cbo, CB_GETITEMDATA, idx, 0);

        // GO is enabled if an interpreter path has been entered, OR
        // the selected interpreter is "Other" (which is not in the terp
        // list, so it has a null position)
        ::EnableWindow(GetDlgItem(IDOK), (exepath[0] != 0 || pos == 0));

        // BROWSE is enabled if the interpreter path is NOT "Other" - we
        // don't select a path for "Other"
        ::EnableWindow(GetDlgItem(IDC_BTN_BROWSE), pos != 0);

        // if the interpreter is "Other", put a note in the exe path box
        // saying it's not applicable; otherwise show the current exe path
        if (pos == 0)
        {
            CAtlString txt;
            txt.LoadString(IDS_EXE_NA);
            SetDlgItemText(IDC_FLD_PROG, txt);
        }
        else
            SetDlgItemText(IDC_FLD_PROG, exepath);
    }

    // save the dialog box settings
    void SaveSettings()
    {
        // get the current selection from the combo
        HWND cbo = GetDlgItem(IDC_CB_PLAYERS);
        int selIdx = (int)::SendMessage(cbo, CB_GETCURSEL, 0, 0);

        // if we have a selection, save it in the 'info' record
        if (selIdx != -1)
        {
            // the item data object is the interpreter list POSITION
            info->selectedTerp = (POSITION)::SendMessage(
                cbo, CB_GETITEMDATA, selIdx, 0);
        }

        // save the terp executable path, if applicable
        info->terpExe = exepath;
    }

    LRESULT OnClickedOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        // save the settings from the dialog
        SaveSettings();

        // dismiss the dialog
        EndDialog(wID);
        return 0;
    }

    LRESULT OnClickedCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        // dismiss the dialog
        EndDialog(wID);
        return 0;
    }
    LRESULT OnCtlColorDlg(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
    LRESULT OnCtlColorStatic(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
        LRESULT OnBnClickedBtnBrowse(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
        LRESULT OnCbnSelchangeCbPlayers(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
        LRESULT OnBnClickedBtnBack(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
};


