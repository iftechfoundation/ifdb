// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// ProgressDialog.cpp : Implementation of CProgressDialog

#include "stdafx.h"
#include "ProgressDialog.h"


// CProgressDialog
