// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details


// MainDlg.h : Declaration of the CMainDlg

#pragma once

#include "resource.h"       // main symbols
#include <atlhost.h>
#include "ifdbinst.h"


// dialog context structure (in the dialog initializer LPARAM)
struct MainDlgCtx
{
    MainDlgCtx(dlinfo *info, class IIfdbUpdater *updater)
        : info(info), updater(updater) { }
    
    dlinfo *info;
    class IIfdbUpdater *updater;
};

// updater callback interface
class IIfdbUpdater
{
public:
    // Check for updates - if an update is needed, initiates the update and
    // returns true; otherwise returns false.  The caller should terminate
    // the program as soon as convenient if this returns true, since the
    // updater will need to be able to replace our program file.
    virtual bool CheckUpdate() = 0;
};


// CMainDlg
class CMainDlg : 
    public CAxDialogImpl<CMainDlg>
{
public:
    CMainDlg()
    {
        // set up our resources
        bkg_brush_ = ::CreateSolidBrush(RGB(0xFF,0xFF,0xFF));

        // we don't have our dialog parameters yet
        updater = 0;
        info = 0;
    }

    ~CMainDlg()
    {
        // release resources
        DeleteObject(bkg_brush_);
    }

    enum { IDD = IDD_MAINDLG };

    // dialog background color brush
    HBRUSH bkg_brush_;

    BEGIN_MSG_MAP(CMainDlg)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOK)
        COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnClickedCancel)
        COMMAND_HANDLER(IDC_RB_INSTALLIT, BN_CLICKED, OnBnClickedRbInstallit)
        COMMAND_HANDLER(IDC_RB_ALREADYGOTIT, BN_CLICKED, OnBnClickedRbAlreadygotit)
        MESSAGE_HANDLER(WM_CTLCOLORDLG, OnCtlColorDlg)
        MESSAGE_HANDLER(WM_CTLCOLORSTATIC, OnCtlColorStatic)
		COMMAND_HANDLER(IDC_BTN_UPDATE, BN_CLICKED, OnBnClickedBtnUpdate)
		CHAIN_MSG_MAP(CAxDialogImpl<CMainDlg>)
    END_MSG_MAP()

    // Handler prototypes:
    //  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    //  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
    //  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

    // download information
    dlinfo *info;

    // updater interface
    IIfdbUpdater *updater;

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
    {
        CAtlString str, rstr;
        CAxDialogImpl<CMainDlg>::OnInitDialog(uMsg, wParam, lParam, bHandled);

        // get the context information
        MainDlgCtx *ctx = (MainDlgCtx *)lParam;
        info = ctx->info;
        updater = ctx->updater;

        // set up the game download section, if we need it
        if (info->needGame)
        {
            // downloading the game - set the title and author
            str.Format("%s, by %s", info->title, info->author);
            SetDlgItemText(IDC_ST_TITLE, str);
        }
        else
        {
            // we don't need the game
            HideControls(IDC_ST_NEEDGAME, IDC_ST_TITLE);
        }

        // hide the Update Installer button if auto-updates are enabled -
        // there's no need for a manual check, since we always check
        // automatically
        if (AutoUpdatesEnabled())
			::ShowWindow(GetDlgItem(IDC_BTN_UPDATE), SW_HIDE);

        // select the appropriate radio button, depending on whether or
        // not they want an interpreter
        CheckDlgButton(
            info->installTerp ? IDC_RB_INSTALLIT : IDC_RB_ALREADYGOTIT,
            BST_CHECKED);

        // format the "need interpreter" string
        if (info->terpUpdate)
        {
            // we need an interpreter update, not a new interpreter -
            // hide the "available players" control and close the gap
            HideControls(IDC_ST_PLAYERS, IDC_CB_PLAYERS);

            // set the labels to indicate that we're updating
            rstr.LoadString(IDS_TERPUPDATE1);
            str.Format(rstr, info->fmtName,
                       info->terps.GetAt(info->selectedTerp).name);
            SetDlgItemText(IDC_ST_NEEDTERP, str);

            str.LoadString(IDS_TERPUPDATE2);
            SetDlgItemText(IDC_RB_INSTALLIT, str);

            str.LoadString(IDS_TERPUPDATE3);
            SetDlgItemText(IDC_RB_ALREADYGOTIT, str);
        }
        else if (info->needTerp)
        {
            // we need a new interpreter
            TCHAR buf[256];
            GetDlgItemText(IDC_ST_NEEDTERP, buf, sizeof(buf));
            str.Format(buf, info->fmtName);
            SetDlgItemText(IDC_ST_NEEDTERP, str);
        }
        else
        {
            // we don't need an interpreter download at all -
            // hide the items related to the interpreter install
            HideControls(IDC_ST_NEEDTERP, IDC_RB_ALREADYGOTIT);
        }

        // if there's no interpreter selected, pick the first one by default
        if (info->selectedTerp == 0)
            info->selectedTerp = info->terps.GetHeadPosition();

        // populate the interpreter combo
        HWND cbo = GetDlgItem(IDC_CB_PLAYERS);
        for (POSITION pos = info->terps.GetHeadPosition() ; pos != 0 ;
             info->terps.GetNext(pos))
        {
            // add this item
            int idx = (int)::SendMessage(
                cbo, CB_ADDSTRING, 0,
                (LPARAM)(LPCTSTR)info->terps.GetAt(pos).name);
            
            // the lparam is the position in the list
            ::SendMessage(cbo, CB_SETITEMDATA, idx, (LPARAM)pos);
            
            // if this is the initial interpreter selection, select
            // it in the combo
            if (pos == info->selectedTerp)
                ::SendMessage(cbo, CB_SETCURSEL, idx, 0);
        }

        // add the download list
        UpdateUrls();

        // Let the system set the focus
        return 1;
    }

    // Hide the controls in vertical order from 'fromCtl' to and including
    // 'toCtl'.  Shrinks the window and closes the gap left from hiding
    // the controls.
    void HideControls(int fromCtl, int toCtl)
    {
        static const int ctl_vert[] =
        {
            IDC_ST_NEEDGAME,
            IDC_ST_TITLE,
            IDC_ST_NEEDTERP,
            IDC_ST_PLAYERS,
            IDC_CB_PLAYERS,
            IDC_RB_INSTALLIT,
            IDC_RB_ALREADYGOTIT,
            IDC_ST_WARN,
            IDC_ST_URLS,
            IDC_FLD_URLS,
            IDOK,
            IDCANCEL
        };
        const int *cp;
        size_t i;
        bool inHide;

        // run through the controls, and hide the affected items
        for (inHide = false, i = 0, cp = ctl_vert ;
             i < sizeof(ctl_vert)/sizeof(ctl_vert[0]) ;
             ++i, ++cp)
        {
            // if this is the starting control, we're in the 'found' section
            if (*cp == fromCtl)
                inHide = true;

            // if we're in the hidden section, hide this control
            if (inHide)
                ::ShowWindow(GetDlgItem(*cp), SW_HIDE);

            // if this is the 'to' control, stop here
            if (*cp == toCtl)
            {
                // leave 'i' and 'cp' at the control after the gap
                ++i;
                ++cp;

                // stop scanning
                break;
            }
        }

        // get the next control after the hidden section
        int nxtCtl = *cp;

        // get the gap between the first hidden control and the first
        // remaining control
        RECT rc1, rc2;
        ::GetWindowRect(GetDlgItem(fromCtl), &rc1);
        ::GetWindowRect(GetDlgItem(nxtCtl), &rc2);
        int deltay = rc1.top - rc2.top;

        // now loop through the remaining controls and move each one up
        for ( ; i < sizeof(ctl_vert)/sizeof(ctl_vert[0]) ; ++i, ++cp)
        {
            // move this control
            MoveCtlRel(*cp, 0, deltay);
        }

        // shrink the dialog window
        GetWindowRect(&rc1);
        rc1.bottom += deltay;
        MoveWindow(&rc1, TRUE);
    }

    void UpdateUrls()
    {
        CAtlString urls;
        
        // start with the game URL
        if (info->needGame)
            urls += info->game.url + "\r\n";

        // add the terp URL only if it's set and we're going to download it
        if (info->needTerp && IsDlgButtonChecked(IDC_RB_INSTALLIT))
            urls += info->terps.GetAt(info->selectedTerp).dl.url + "\r\n";

        // set it
        SetDlgItemText(IDC_FLD_URLS, urls);
    }

    void MoveCtlRel(int id, int deltax, int deltay)
    {
        RECT rc;
        HWND ctl = GetDlgItem(id);
        ::GetClientRect(ctl, &rc);
        ::MapWindowPoints(ctl, m_hWnd, (POINT *)&rc, 2);
        ::OffsetRect(&rc, deltax, deltay);
        ::MoveWindow(ctl, rc.left, rc.top, 
                     rc.right - rc.left, rc.bottom - rc.top, TRUE);
    }

    LRESULT OnClickedOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        // set the interpreter selection based on the selected combo item
        if (info->needTerp && info->installTerp)
        {
            // find the selected combo item
            HWND cbo = GetDlgItem(IDC_CB_PLAYERS);
            int selIdx = (int)::SendMessage(cbo, CB_GETCURSEL, 0, 0);
            if (selIdx != -1)
            {
                // the item data object is the interpreter list POSITION
                info->selectedTerp = (POSITION)::SendMessage(
                    cbo, CB_GETITEMDATA, selIdx, 0);
            }
        }

        // end the dialog
        EndDialog(wID);
        return 0;
    }

    LRESULT OnClickedCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        EndDialog(wID);
        return 0;
    }
    LRESULT OnBnClickedRbInstallit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
    LRESULT OnBnClickedRbAlreadygotit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
    LRESULT OnCtlColorDlg(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
    LRESULT OnCtlColorStatic(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnBnClickedBtnUpdate(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
};


