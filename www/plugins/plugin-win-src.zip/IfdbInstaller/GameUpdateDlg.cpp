// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// GameUpdateDlg.cpp : Implementation of CGameUpdateDlg

#include "stdafx.h"
#include "GameUpdateDlg.h"
#include ".\gameupdatedlg.h"


// CGameUpdateDlg
