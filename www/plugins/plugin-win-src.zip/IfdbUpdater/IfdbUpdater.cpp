// IfdbUpdater.cpp : Implementation of WinMain

#include "stdafx.h"
#include "resource.h"

static LPCTSTR msgbox_title = _T("IFDB Installer Update");

// The module attribute causes WinMain to be automatically implemented for you
[ module(EXE, uuid = "{0D0553B8-F395-4D35-998C-62051846EF25}", 
                 name = "IfdbUpdater", 
                 helpstring = "IfdbUpdater 1.0 Type Library",
                 resource_name = "IDR_IFDBUPDATER") ]
class CIfdbUpdaterModule
{
public:
    // install directory - we get this via our command-line parameters
    CAtlString installDir;

    // re-run parameters - once we finish, we'll re-invoke the installer
    // with the same parameters to complete whatever game install was
    // under way originally
    CAtlString rerunParams;

    // parse the command line
    bool ParseCommandLine(LPCTSTR cmd, HRESULT *ret) throw()
    {
        CAtlString tok;

        // inherit the default handling
        if (!CAtlExeModuleT<CIfdbUpdaterModule>::ParseCommandLine(cmd, ret))
            return false;

        // presume success
        *ret = S_OK;

        // skip the program name token
        NextToken(tok, cmd);

        // parse the command tokens
        for (;;)
        {
            // get the next token
            if (!NextToken(tok, cmd))
                break;

            // check what we have
            if (tok == "-dir" && NextToken(tok, cmd))
            {
                // save the installer directory
                installDir = tok;
            }
            else if (tok == "-rerun")
            {
                // the rest of the line is the command line for the
                // repeat run of the installer, after we finish the
                // update
                rerunParams = cmd;

                // that consumes the whole rest of the line, so we're done
                break;
            }
            else
            {
                MessageBox(0, _T("Invalid parameters"), msgbox_title,
                           MB_OK | MB_ICONERROR);
                *ret = E_INVALIDARG;
                return false;
            }
        }

        // make sure we have a directory name
        if (installDir == "")
        {
            MessageBox(0, _T("Missing install directory"), msgbox_title,
                       MB_OK | MB_ICONERROR);
            *ret = E_INVALIDARG;
            return false;
        }

        // success
        return true;
    }
    
    // carry out the main program action
    HRESULT Run(int nShowCmd)
    {
        LPCTSTR msg;
        
        // Determine whether we need to update the browser plug-in part.
        // If we do, we need to tell the user to close browser windows,
        // to free up the plug-in DLL so that we can overwrite it.
        // Otherwise, we just need the user to close any running
        // installers.
        if (NeedFileUpdate("IfdbPlugIn.ocx", true)
            || NeedFileUpdate("npIfdbMeta.dll", true))
        {
            // we need to update a plug-in DLL
            msg = "Before the update can proceed, you must close ALL "
                  "BROWSER WINDOWS. This is required because the Updater "
                  "needs to overwrite the plug-in files with new "
                  "versions, which can't be done while the browser is "
                  "open."
                  "\r\n\r\n"
                  "Please ALSO close all IFDB Installer windows, since "
                  "the Installer program files will be updated as well."
                  "\r\n\r\n"
                  "When you've closed all browser windows and all "
                  "IFDB Installer windows, click OK to proceed with "
                  "the update.";
        }
        else
        {
            msg = "Before the update can proceed, you must close all "
                  "IFDB Installer windows. This is required because "
                  "the Updater needs to overwrite the Installer's program "
                  "files with new versions - this can't be done while "
                  "the program is running."
                  "\r\n\r\n"
                  "When you've closed all IFDB Installer windows, "
                  "click OK to proceed with the update.";
        }

        // show the prompt
        switch (MessageBox(0, msg, msgbox_title,
                           MB_OKCANCEL | MB_ICONINFORMATION))
        {
        case IDCANCEL:
            // canceled - re-run the installer and terminate
            ReRunInstaller();
            return S_OK;

        case IDOK:
            // proceed
            break;
        }

    tryUpdates:
        // copy the files that need updating
        UpdateFile("IfdbPlugIn.ocx", true);
        UpdateFile("npIfdbMeta.dll", true);
        UpdateFile("IfdbInstaller.exe", false);

        // if anything went wrong, tell them about it
        if (errorList != "")
        {
            CAtlString str;
            str.Format(
                _T("The Updater was unable to update one or more files ")
                _T("(%s). This might prevent your Installer from working ")
                _T("properly. If you still have any browser or Installer ")
                _T("windows open, please close them and try again. ")
                _T("If retrying doesn't fix the problem, you might need ")
                _T("to remove and re-install the IFDB Installer.")
                _T("\r\n\r\n")
                _T("Would you like to try again?"), errorList);
            if (MessageBox(0, str, msgbox_title, MB_YESNO | MB_ICONERROR)
                == IDYES)
            {
                // clear the message list for another round
                errorList = "";

                // go back for another try
                goto tryUpdates;
            }
        }

        // re-run the original install, and we're done
        ReRunInstaller();
        return S_OK;
    }

    // list of files causing errors on update
    CAtlString errorList;

    // Check a file to determine if needs to be updated.
    bool NeedFileUpdate(LPCTSTR fname, bool updateOnly)
    {
        TCHAR path[MAX_PATH];
        int oldVsn[4], newVsn[4];

        // build the full file path to the existing copy
        PathCombine(path, installDir, fname);

        // if the old file doesn't exist, it needs to be updated
        // only if we're NOT in update-only mode - in update-only
        // mode, files are only updated when they already exist
        if (GetFileAttributes(path) == INVALID_FILE_ATTRIBUTES)
            return !updateOnly;
        
        // if the files have version information, and the existing
        // installed file is up to date, we don't need to copy it
        if (GetFileVersion(fname, newVsn)
            && GetFileVersion(path, oldVsn)
            && CompareVersions(oldVsn, newVsn) >= 0)
            return false;

        // there's no version information, so assume we need to
        // update the file
        return true;
    }

    // Update a file if necessary.  If updateOnly is true, we'll only
    // update the file if it already exists; otherwise we'll update
    // the file if it's out of date or if it's entirely new.
    void UpdateFile(LPCTSTR fname, bool updateOnly)
    {
        TCHAR path[MAX_PATH];
        int oldVsn[4], newVsn[4];

        // if the file doesn't need to be updated, there's nothing to do
        if (!NeedFileUpdate(fname, updateOnly))
            return;

        // build the full file path to the existing copy
        PathCombine(path, installDir, fname);

        // copy the file
        if (!CopyFile(fname, path, FALSE))
            errorList += fname;
    }

    // add a file to the error list
    void AddErrorList(LPCTSTR fname)
    {
        // add a separator if there's anything in the list already
        if (errorList != "")
            errorList += "; ";

        // add this file
        errorList += fname;
    }

    // compare version numbers
    int CompareVersions(int a[4], int b[4])
    {
        for (int i = 0 ; i < 4 ; ++i)
        {
            int diff;
            if ((diff = a[i] - b[i]) != 0)
                return diff;
        }
        return 0;
    }

    // Get the embedded version information from the given file.  Returns
    // true if successful, false if the file isn't found or we can't retrieve
    // the version information.  The version is represented as four ints,
    // ordered from most significant to least significant.
    bool GetFileVersion(LPCTSTR fname, int vsn[4])
    {
        DWORD len;
        char *buf;
        DWORD hdl;
        bool ret;
        VS_FIXEDFILEINFO *info;
        UINT infoLen;

        // get the version info size and allocate space
        if ((len = GetFileVersionInfoSize(fname, &hdl)) == 0
            || (buf = new char[len]) == 0)
            return false;

        // retrieve the version information
        ret = (GetFileVersionInfo(fname, hdl, len, buf) != 0
               && VerQueryValue(buf, "\\", (LPVOID *)&info, &infoLen) != 0);

        // if we got the information, decode it
        if (ret)
        {
            vsn[0] = HIWORD(info->dwFileVersionMS);
            vsn[1] = LOWORD(info->dwFileVersionMS);
            vsn[2] = HIWORD(info->dwFileVersionLS);
            vsn[3] = LOWORD(info->dwFileVersionLS);
        }

        // clean up and return our result
        delete [] buf;
        return ret;
    }

    // Re-run the installer.  This fires up the install program again
    // with its original parameters, so that we complete the game
    // installation that was interrupted by the update attempt.
    void ReRunInstaller()
    {
        TCHAR prog[MAX_PATH], params[MAX_PATH + 128];

        // if we don't have an installation directory or original
        // command parameters, this won't work
        if (installDir == "" || rerunParams == "")
            return;
            
        // build the install program name and commandline
        PathCombine(prog, installDir, _T("IfdbInstaller.exe"));
        _sntprintf(params, sizeof(params), _T("\"%s\" %s"),
                   prog, rerunParams);

        // run the program
        STARTUPINFO si;
        PROCESS_INFORMATION pi;
        memset(&si, 0, sizeof(si));
        si.cb = sizeof(si);
        if (CreateProcess(
            prog, params, 0, 0, FALSE, 0, 0, installDir, &si, &pi))
        {
            // success - we don't need the handles after launch
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
        }
        else
        {
            MessageBox(
                0, _T("An error occurred re-starting the Installer. ")
                _T("Please try starting the game download again ")
                _T("manually from the game's page on IFDB."),
                msgbox_title, MB_OK | MB_ICONERROR);
        }
    }

    // Get the next token in a command line (tokens are delimited by
    // spaces; double quotes can be used to enclose tokens containing
    // spaces; to include a double quote within a double-quoted string,
    // stutter the quote or escape it with a backslash; other backslashes
    // are just backslashes).
    bool NextToken(CAtlString &tok, LPCTSTR &p)
    {
        // skip leading whitespace
        while (*p != '\0' && isspace(*p))
            ++p;

        // check for end of string
        if (*p == '\0')
            return false;

        // check for quotes
        LPCTSTR start = p;
        if (*p == '"')
        {
            // skip the open quote
            ++p, ++start;

            // scan for the close quote
            for ( ; ; ++p)
            {
                // if it's a close quote, we're done
                if (*p == '"')
                {
                    // the token is the part between the quotes
                    tok = CAtlString(start, p - start);

                    // move past the quote
                    ++p;

                    // we're done
                    return true;
                }
            }
        }
        else
        {
            // no quotes - the token ends at the next space
            while (*p != '\0' && !isspace(*p))
                ++p;
            
            // pull out the token
            CAtlString t(start, p - start);
            tok = t;
        }

        // success
        return true;
    }
};

