// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

#pragma once

// IFDBPlugIn.h : main header file for IFDBPlugIn.DLL

#if !defined( __AFXCTL_H__ )
#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols


// CIFDBPlugInApp : See IFDBPlugIn.cpp for implementation.

class CIFDBPlugInApp : public COleControlModule
{
public:
        BOOL InitInstance();
        int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

