// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// IFDBPlugInPropPage.cpp : Implementation of the CIFDBPlugInPropPage property page class.

#include "stdafx.h"
#include "IFDBPlugIn.h"
#include "IFDBPlugInPropPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_DYNCREATE(CIFDBPlugInPropPage, COlePropertyPage)



// Message map

BEGIN_MESSAGE_MAP(CIFDBPlugInPropPage, COlePropertyPage)
END_MESSAGE_MAP()



// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CIFDBPlugInPropPage, "IFDBPLUGIN.IFDBPlugInPropPage.1",
        0xa9054cd1, 0xe218, 0x4def, 0x81, 0x6c, 0xe1, 0xd1, 0xe2, 0xad, 0xb7, 0x92)



// CIFDBPlugInPropPage::CIFDBPlugInPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CIFDBPlugInPropPage

BOOL CIFDBPlugInPropPage::CIFDBPlugInPropPageFactory::UpdateRegistry(BOOL bRegister)
{
        if (bRegister)
                return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
                        m_clsid, IDS_IFDBPLUGIN_PPG);
        else
                return AfxOleUnregisterClass(m_clsid, NULL);
}



// CIFDBPlugInPropPage::CIFDBPlugInPropPage - Constructor

CIFDBPlugInPropPage::CIFDBPlugInPropPage() :
        COlePropertyPage(IDD, IDS_IFDBPLUGIN_PPG_CAPTION)
{
}



// CIFDBPlugInPropPage::DoDataExchange - Moves data between page and properties

void CIFDBPlugInPropPage::DoDataExchange(CDataExchange* pDX)
{
        DDP_PostProcessing(pDX);
}



// CIFDBPlugInPropPage message handlers
