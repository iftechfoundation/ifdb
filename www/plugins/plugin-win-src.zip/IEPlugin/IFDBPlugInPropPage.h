// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

#pragma once

// IFDBPlugInPropPage.h : Declaration of the CIFDBPlugInPropPage property page class.


// CIFDBPlugInPropPage : See IFDBPlugInPropPage.cpp for implementation.

class CIFDBPlugInPropPage : public COlePropertyPage
{
        DECLARE_DYNCREATE(CIFDBPlugInPropPage)
        DECLARE_OLECREATE_EX(CIFDBPlugInPropPage)

// Constructor
public:
        CIFDBPlugInPropPage();

// Dialog Data
        enum { IDD = IDD_PROPPAGE_IFDBPLUGIN };

// Implementation
protected:
        virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
        DECLARE_MESSAGE_MAP()
};

