// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

// stdafx.cpp : source file that includes just the standard includes
//  IFDBPlugIn.pch will be the pre-compiled header
//  stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
