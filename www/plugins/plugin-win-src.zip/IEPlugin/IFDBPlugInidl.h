

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Tue Oct 09 19:31:45 2007
 */
/* Compiler settings for .\IFDBPlugIn.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__


#ifndef __IFDBPlugInidl_h__
#define __IFDBPlugInidl_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef ___DIFDBPlugIn_FWD_DEFINED__
#define ___DIFDBPlugIn_FWD_DEFINED__
typedef interface _DIFDBPlugIn _DIFDBPlugIn;
#endif 	/* ___DIFDBPlugIn_FWD_DEFINED__ */


#ifndef ___DIFDBPlugInEvents_FWD_DEFINED__
#define ___DIFDBPlugInEvents_FWD_DEFINED__
typedef interface _DIFDBPlugInEvents _DIFDBPlugInEvents;
#endif 	/* ___DIFDBPlugInEvents_FWD_DEFINED__ */


#ifndef __IFDBPlugIn_FWD_DEFINED__
#define __IFDBPlugIn_FWD_DEFINED__

#ifdef __cplusplus
typedef class IFDBPlugIn IFDBPlugIn;
#else
typedef struct IFDBPlugIn IFDBPlugIn;
#endif /* __cplusplus */

#endif 	/* __IFDBPlugIn_FWD_DEFINED__ */


#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 


#ifndef __IFDBPlugInLib_LIBRARY_DEFINED__
#define __IFDBPlugInLib_LIBRARY_DEFINED__

/* library IFDBPlugInLib */
/* [control][helpstring][helpfile][version][uuid] */ 


EXTERN_C const IID LIBID_IFDBPlugInLib;

#ifndef ___DIFDBPlugIn_DISPINTERFACE_DEFINED__
#define ___DIFDBPlugIn_DISPINTERFACE_DEFINED__

/* dispinterface _DIFDBPlugIn */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__DIFDBPlugIn;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("3F4CE99C-1AA7-4C8F-9C83-2A0A0F39AF98")
    _DIFDBPlugIn : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _DIFDBPlugInVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _DIFDBPlugIn * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _DIFDBPlugIn * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _DIFDBPlugIn * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _DIFDBPlugIn * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _DIFDBPlugIn * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _DIFDBPlugIn * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _DIFDBPlugIn * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _DIFDBPlugInVtbl;

    interface _DIFDBPlugIn
    {
        CONST_VTBL struct _DIFDBPlugInVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _DIFDBPlugIn_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _DIFDBPlugIn_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _DIFDBPlugIn_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _DIFDBPlugIn_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _DIFDBPlugIn_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _DIFDBPlugIn_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _DIFDBPlugIn_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___DIFDBPlugIn_DISPINTERFACE_DEFINED__ */


#ifndef ___DIFDBPlugInEvents_DISPINTERFACE_DEFINED__
#define ___DIFDBPlugInEvents_DISPINTERFACE_DEFINED__

/* dispinterface _DIFDBPlugInEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__DIFDBPlugInEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("0CEEDD58-C04D-4FEB-8DA0-9184A1B4C5F0")
    _DIFDBPlugInEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _DIFDBPlugInEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _DIFDBPlugInEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _DIFDBPlugInEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _DIFDBPlugInEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _DIFDBPlugInEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _DIFDBPlugInEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _DIFDBPlugInEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _DIFDBPlugInEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _DIFDBPlugInEventsVtbl;

    interface _DIFDBPlugInEvents
    {
        CONST_VTBL struct _DIFDBPlugInEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _DIFDBPlugInEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _DIFDBPlugInEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _DIFDBPlugInEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _DIFDBPlugInEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _DIFDBPlugInEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _DIFDBPlugInEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _DIFDBPlugInEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___DIFDBPlugInEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_IFDBPlugIn;

#ifdef __cplusplus

class DECLSPEC_UUID("67BAF0C9-D511-4925-A796-3F7BB19726EE")
IFDBPlugIn;
#endif
#endif /* __IFDBPlugInLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


