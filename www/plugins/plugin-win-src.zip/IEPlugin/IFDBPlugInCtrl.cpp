// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details


// IFDBPlugInCtrl.cpp : Implementation of the CIFDBPlugInCtrl ActiveX Control class.

#include "stdafx.h"
#include "IFDBPlugIn.h"
#include "IFDBPlugInCtrl.h"
#include "IFDBPlugInPropPage.h"
#include ".\ifdbpluginctrl.h"
#include <shlobj.h>
#include <shlwapi.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_DYNCREATE(CIFDBPlugInCtrl, COleControl)



// Message map

BEGIN_MESSAGE_MAP(CIFDBPlugInCtrl, COleControl)
        ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()



// Dispatch map

BEGIN_DISPATCH_MAP(CIFDBPlugInCtrl, COleControl)
        DISP_FUNCTION_ID(CIFDBPlugInCtrl, "doDownload", dispiddoDownload, doDownload, VT_EMPTY, VTS_NONE)
        DISP_PROPERTY_NOTIFY_ID(CIFDBPlugInCtrl, "gameID", dispidgameID, m_gameID, OngameIDChanged, VT_BSTR)
                DISP_PROPERTY_NOTIFY_ID(CIFDBPlugInCtrl, "mirrorID", dispidmirrorID, m_mirrorID, OnmirrorIDChanged, VT_BSTR)
END_DISPATCH_MAP()



// Event map

BEGIN_EVENT_MAP(CIFDBPlugInCtrl, COleControl)
END_EVENT_MAP()



// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CIFDBPlugInCtrl, 1)
        PROPPAGEID(CIFDBPlugInPropPage::guid)
END_PROPPAGEIDS(CIFDBPlugInCtrl)



// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CIFDBPlugInCtrl, "IfdbTadsOrg.IfdbMetaInstaller.1",
        0x67baf0c9, 0xd511, 0x4925, 0xa7, 0x96, 0x3f, 0x7b, 0xb1, 0x97, 0x26, 0xee)



// Type library ID and version

IMPLEMENT_OLETYPELIB(CIFDBPlugInCtrl, _tlid, _wVerMajor, _wVerMinor)



// Interface IDs

const IID BASED_CODE IID_DIFDBPlugIn =
                { 0x3F4CE99C, 0x1AA7, 0x4C8F, { 0x9C, 0x83, 0x2A, 0xA, 0xF, 0x39, 0xAF, 0x98 } };
const IID BASED_CODE IID_DIFDBPlugInEvents =
                { 0xCEEDD58, 0xC04D, 0x4FEB, { 0x8D, 0xA0, 0x91, 0x84, 0xA1, 0xB4, 0xC5, 0xF0 } };



// Control type information

static const DWORD BASED_CODE _dwIFDBPlugInOleMisc =
        OLEMISC_ACTIVATEWHENVISIBLE |
        OLEMISC_SETCLIENTSITEFIRST |
        OLEMISC_INSIDEOUT |
        OLEMISC_CANTLINKINSIDE |
        OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CIFDBPlugInCtrl, IDS_IFDBPLUGIN, _dwIFDBPlugInOleMisc)



// CIFDBPlugInCtrl::CIFDBPlugInCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CIFDBPlugInCtrl

BOOL CIFDBPlugInCtrl::CIFDBPlugInCtrlFactory::UpdateRegistry(BOOL bRegister)
{
        // TODO: Verify that your control follows apartment-model threading rules.
        // Refer to MFC TechNote 64 for more information.
        // If your control does not conform to the apartment-model rules, then
        // you must modify the code below, changing the 6th parameter from
        // afxRegApartmentThreading to 0.

        if (bRegister)
                return AfxOleRegisterControlClass(
                        AfxGetInstanceHandle(),
                        m_clsid,
                        m_lpszProgID,
                        IDS_IFDBPLUGIN,
                        IDB_IFDBPLUGIN,
                        afxRegApartmentThreading,
                        _dwIFDBPlugInOleMisc,
                        _tlid,
                        _wVerMajor,
                        _wVerMinor);
        else
                return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}



// CIFDBPlugInCtrl::CIFDBPlugInCtrl - Constructor

CIFDBPlugInCtrl::CIFDBPlugInCtrl()
{
        InitializeIIDs(&IID_DIFDBPlugIn, &IID_DIFDBPlugInEvents);
        // TODO: Initialize your control's instance data here.
}



// CIFDBPlugInCtrl::~CIFDBPlugInCtrl - Destructor

CIFDBPlugInCtrl::~CIFDBPlugInCtrl()
{
        // TODO: Cleanup your control's instance data here.
}



// CIFDBPlugInCtrl::OnDraw - Drawing function

void CIFDBPlugInCtrl::OnDraw(
                        CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
        if (!pdc)
                return;

        // TODO: Replace the following code with your own drawing code.
        pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(LTGRAY_BRUSH)));
}



// CIFDBPlugInCtrl::DoPropExchange - Persistence support

void CIFDBPlugInCtrl::DoPropExchange(CPropExchange* pPX)
{
        ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
        COleControl::DoPropExchange(pPX);

        // TODO: Call PX_ functions for each persistent custom property.
        PX_String(pPX, _T("gameID"), m_gameID);
                PX_String(pPX, _T("mirrorID"), m_mirrorID);
}



// CIFDBPlugInCtrl::OnResetState - Reset control to default state

void CIFDBPlugInCtrl::OnResetState()
{
        COleControl::OnResetState();  // Resets defaults found in DoPropExchange

        // TODO: Reset any other control state here.
}



// CIFDBPlugInCtrl message handlers





void CIFDBPlugInCtrl::doDownload(void)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
        
    // get the directory containing the plug-in code
    TCHAR dir[MAX_PATH];
    GetModuleFileName(_AtlBaseModule.GetModuleInstance(), dir, sizeof(dir));
    PathRemoveFileSpec(dir);
    
    // build the command line for the installer program
    TCHAR prog[MAX_PATH], cmd[MAX_PATH + 128];
    PathCombine(prog, dir, _T("IfdbInstaller.exe"));
    _sntprintf(cmd, sizeof(cmd), _T("\"%s\" -id %s %s%s"),
               prog, m_gameID, 
               _tcslen(m_mirrorID) != 0 ? _T("-mirror ") : _T(""), m_mirrorID);
    
    // launch it
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    if (CreateProcess(prog, cmd, 0, 0, FALSE, 0, 0, dir, &si, &pi))
    {
        // we don't need the handles after launch
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
    else
    {
        ::MessageBox(
            0, _T("An error occurred launching the IFDB Installer. ")
            _T("You might need to reinstall the plug-in."), 
            _T("IFDB Plug-In"), MB_OK | MB_ICONERROR);
    }
}

void CIFDBPlugInCtrl::OngameIDChanged(void)
{
        AFX_MANAGE_STATE(AfxGetStaticModuleState());

        // TODO: Add your property handler code here

        SetModifiedFlag();
}

void CIFDBPlugInCtrl::OnmirrorIDChanged(void)
{
        AFX_MANAGE_STATE(AfxGetStaticModuleState());

        // TODO: Add your property handler code here

        SetModifiedFlag();
}
