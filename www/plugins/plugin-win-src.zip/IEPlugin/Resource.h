// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IFDBPlugIn.rc
//

#define IDS_IFDBPLUGIN               1
#define IDS_IFDBPLUGIN_PPG           2

#define IDS_IFDBPLUGIN_PPG_CAPTION   200

#define IDD_PROPPAGE_IFDBPLUGIN      200


#define IDB_IFDBPLUGIN               1


#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#define _APS_NEXT_COMMAND_VALUE         32768
