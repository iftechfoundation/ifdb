// Copyright 2007 Michael J Roberts
// Distributed under a GNU Public License - see COPYING for details

#pragma once

// IFDBPlugInCtrl.h : Declaration of the CIFDBPlugInCtrl ActiveX Control class.


// CIFDBPlugInCtrl : See IFDBPlugInCtrl.cpp for implementation.

class CIFDBPlugInCtrl : public COleControl
{
        DECLARE_DYNCREATE(CIFDBPlugInCtrl)

// Constructor
public:
        CIFDBPlugInCtrl();

// Overrides
public:
        virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
        virtual void DoPropExchange(CPropExchange* pPX);
        virtual void OnResetState();

// Implementation
protected:
        ~CIFDBPlugInCtrl();

        DECLARE_OLECREATE_EX(CIFDBPlugInCtrl)    // Class factory and guid
        DECLARE_OLETYPELIB(CIFDBPlugInCtrl)      // GetTypeInfo
        DECLARE_PROPPAGEIDS(CIFDBPlugInCtrl)     // Property page IDs
        DECLARE_OLECTLTYPE(CIFDBPlugInCtrl)             // Type name and misc status

// Message maps
        DECLARE_MESSAGE_MAP()

// Dispatch maps
        DECLARE_DISPATCH_MAP()

// Event maps
        DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
        enum {
			dispidmirrorID = 3,                dispidgameID = 2,               dispiddoDownload = 1L
        };
protected:
        void doDownload(void);
        void OngameIDChanged(void);
        CString m_gameID;

public:
protected:
	void OnmirrorIDChanged(void);
	CString m_mirrorID;
};

