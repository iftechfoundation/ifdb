This is the Windows Mozilla Firefox plug-in for the IFDB Meta Installer.
To build this, you need:

 - Microsoft Visual C++ (I used v7.1 aka MS Visual Studio .NET 2003)
 - the Mozilla GeckoSDK for Win32 (see http://www.mozilla.org/projects/plugins/;
   my copy came from http://ftp.mozilla.org/pub/mozilla.org/mozilla/nightly/latest/gecko-sdk-i586-pc-msvc.zip)

