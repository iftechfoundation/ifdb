/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM c:\website\ifdb\MetaInstaller\Windows\MozillaPlugin\windows\ifdbmetaScriptable.idl
 */

#ifndef __gen_ifdbmetaScriptable_h__
#define __gen_ifdbmetaScriptable_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    ifdbPlugIn */
#define IFDBPLUGIN_IID_STR "90908169-34b2-f24f-dffe-e2ed12b1e337"

#define IFDBPLUGIN_IID \
  {0x90908169, 0x34b2, 0xf24f, \
    { 0xdf, 0xfe, 0xe2, 0xed, 0x12, 0xb1, 0xe3, 0x37 }}

class NS_NO_VTABLE ifdbPlugIn : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IFDBPLUGIN_IID)

  /* void doInstall (in string gameID, in string mirrorID); */
  NS_IMETHOD DoInstall(const char *gameID, const char *mirrorID) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IFDBPLUGIN \
  NS_IMETHOD DoInstall(const char *gameID, const char *mirrorID); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IFDBPLUGIN(_to) \
  NS_IMETHOD DoInstall(const char *gameID, const char *mirrorID) { return _to DoInstall(gameID, mirrorID); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IFDBPLUGIN(_to) \
  NS_IMETHOD DoInstall(const char *gameID, const char *mirrorID) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoInstall(gameID, mirrorID); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public ifdbPlugIn
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IFDBPLUGIN

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, ifdbPlugIn)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* void doInstall (in string gameID, in string mirrorID); */
NS_IMETHODIMP _MYCLASS_::DoInstall(const char *gameID, const char *mirrorID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_ifdbmetaScriptable_h__ */
